# Swift／iOS 開發切片

## IOS-V2-ASSET-01 — 当前Swift／SwiftUI接線Slice

2026-10-09 Owner正式双軌：本Agent負責程式与實機；另一Visual Agent負責美術／动画素材，不继续静態比较稿。SW1及SW2已有工程交付（原生7／9、選角、三職、雙人、勝負、復原），下方早期SW2待實作条目为历史原型狀態，不能覆蓋IOS-PLAY-A0-01。Windows／LinuxSwift執行及Owner新美術／完整無障礙驗收仍未據此通過。

本片交付TacticalGoVisuals素材規格validator、原生GameVisualAssets整包載入／fallback、SwiftBoard可選板面陰影／黑白單位／Token、人物卡接線。现有V1資訊基準保留，正常畫面仍A0原圖；Debug重用原圖fixture驗證真接線，不生成美術／动画或改Core。共用規格V2_ASSET_CONTRACT.md，程式／測試／实际原生截图见artifacts/ios/v2-asset-interface-v01/REPORT.md。接線候選完成不等於V2新美術／Owner／真機Gate通過。

## V1-A0-UI-01 — 目前授權的資訊／尺寸設計交付

2026-10-09：Owner支持UI擴展，先交付三完整狀態390／320對照，不將第二技能／動畫綁入。一般、法師推動預覽、主將1氣危險皆由原預設Core產生；7／9共12張HTML/SVG靜態稿，未整合原生App。另一Agent在做棋盤／Token美術，板面僅是布局占位。规格 `V1_A0_UI_SPEC.md`，證據 `artifacts/ios/v1-a0-ui/VALIDATION.md`。後續V2為原生素材与資訊層級整合；第二技能只Draft，不新增假按钮。iPad已授權安裝、待連接。


## 最新 Slice：IOS-PLAY-A0-01（2026-10-09）

Owner 已玩過 Windows，要求先做 iOS。交付範圍：原始 B-v02 選角／資訊、A Token 木質 2.5D 棋盤、7×7／9×9 本機雙人、三職技能、目標預覽確認取消、完整復原、勝負與玩法練習。Swift Magic Hand 規則以 Windows gameplay 分支 54deef97 為基準，原 main 封印測資保留比較。驗證與真機狀態見 `artifacts/ios/playable-a0-v01/REPORT.md`。不重啟任何 3D 或拆層動畫工作。下方舊 Slice 屬歷史，不改其驗收為通過。

2026-10-09 · Owner 核准 V1＋SW1 並行；正式產品主線為 iOS，Windows 保留規則與玩法驗證。此表取代舊文件的 Windows 動畫先行、等規則 Accepted 才開始移植的執行順序。規則仍為 Draft，移植不代表平衡核准。

## 邊界與驗證計畫

本輪是核心領域移植（L2）。規格來源為 `docs/RULES_DRAFT.md`、Owner 決策與手寫 `tests/golden/*.json`。C# 是參考實作；Golden 證明與既定案例一致，C#／Swift transcript 比較證明兩份實作一致，兩者都不能替代玩家規則驗收。

- Domain：`swift/TacticalGoCore`，純 Swift 值型別，不依賴 Apple UI、檔案、網路或時間。`GameState + GameAction → ActionOutcome(state, events, reason)`；拒絕時完整狀態與歷史不變，事件為空。
- Application：iOS `GameStore` 在 main actor 持有 session、選點與預覽；只有確認或換手才 commit；undo 恢復完整快照。
- Presentation：SwiftUI 處理玩家介面；SwiftUI／SpriteKit 比較候選共用 `BoardProjection` 與引擎狀態。棋盤負責座標映射與畫面，事件決定結果。
- Test adapter：共用 JSON runner、C# exporter、transcript comparator。有成功、失敗、邊界與多步序列；比較事件順序及 payload、資源、英雄旗標、封印、盤面、勝負。不可把 exporter 輸出改成 Golden 預期。

## 切片與 Gate

「已實作」只描述程式交付；「待驗收」保留 Owner 的視覺、操作與玩法決定權。

| Slice | 可獨立檢查的交付 | 驗收／依賴 | 本輪狀態 |
|---|---|---|---|
| SW1-01 | Swift Package、落子、棋串／氣、提子、原子拒絕、superko、回合／勝負 | 手寫 Golden；核心無 UI import | 已實作 |
| SW1-02 | 召喚、築壘、封印、換位；結構化事件與錯誤碼 | 三職成功／失敗、到期、資源與事件對照 | 已實作 |
| SW1-03 | 同一批 Golden 在 C#／Swift 執行；完整逐步 transcript 比較 | 不只最終盤面；錯誤結果及事件 payload 等價 | 已實作 |
| SW1-04 | 7×7／9×9、復原包含歷史；CLI 與手動 CI | Swift 本機可編譯執行；Windows／Linux 分別跑同指令 | macOS 已驗證；Windows／Linux 尚未執行 |
| V1-01 | iPhone 比例的一般、技能預覽、危險三種完整候選 | 7×7／9×9；棋盤、卡片、資源、技能同屏可讀 | 原生候選與模擬器截圖已交付；待 Owner 核准 |
| V1-02 | 相機、anchor、圖層、素材配置規格 | 替換素材不改規則及 hit target | 規格已交付；三職全身候選已接棋盤，正式 token／視覺核准仍待驗收 |
| V1-03 | Owner 審三畫面與小螢幕可讀性 | **V1 視覺 Gate**：三畫面整體核准，單張素材不算通過 | 待驗收 |
| SW2a-01 | 同一 iPhone App 切換 SwiftUI／SpriteKit，接純 Swift 核心 | 點選→預覽→確認；非法理由、復原；同座標結果一致 | 已實作並有模擬器互動測試 |
| SW2a-02 | 小螢幕精準選點、9×9 放大／定位候選、VoiceOver／大字級 | 邊角不誤觸；密集棋盤仍能選目標；控制不遮盤 | 格點清單、原生1.6倍放大／拖曳／置中已實作，兩尺寸原生方向／資源／選點回歸通過；真機手指、大字級與完整無障礙待驗收 |
| SW2a-03 | 真機操作、效能、遮擋與生命週期比較 | **下一個技術 Gate**：真 iPhone 正確操作後選定渲染技術 | 待執行；Owner真3D方向後RealityKit為目前原型預設，真機Gate前不宣稱正式選型通過 |
| SW2b-01 | 開局雙方選戰士／法師／盜賊、重開對戰 | 職業、成本、召喚位置取自核心 | 待實作；原型新對戰暫固定戰士 vs 法師 |
| SW2b-02 | 三職完整技能流程、可用理由、可選範圍、提子結果預覽 | 築壘兩點取消／改選、封印到期、換位禁止主將／英雄 | 原型接線已有；逐職 UI 驗收仍待完成 |
| SW2b-03 | 教學 1 次→2 次行動、盜賊技能組合 | 沿用既有驗證局面；新手試玩可完成 | 待實作 |
| SW2b-04 | 本機雙人完整對戰／勝負／重開 | **玩法 Gate**：主線完整對戰＋真人策略驗證 | 原型可輪流；完整產品流程與真人驗收待完成 |
| V2 | 核准視覺整合、9×9 縮放定位、真機驗收 | V1、SW1、SW2a／SW2b 通過 | 待執行 |
| A1–A5 | 基礎動畫、三職技能、勝負回饋 | 原 `ANIMATION_DIRECTION.md` 範圍保留，執行平台改 iOS；逐職及完整對戰驗收 | Owner 最新截圖指示改為先實作模型與動畫；候選進度見 OVERNIGHT_WORK，逐職與真機 Gate 保留 |

執行順序：**V1 ∥ SW1 → SW2a → SW2b → V2 → A1–A5**。SW2a-01 的最小比較原型本輪已提前落地，讓 V1 用真正的 Swift 畫面呈現；不據此宣稱整個 SW2a 已通過。

2026-10-09 早期2D比較候選接線紀錄：三職既有全身候選導入兩渲染器；當時人物卡保留B-v02、士兵／主將採棋石。最新3D主線已改同模型卡片與原創士兵／主將mesh，見OVERNIGHT_WORK與unit-compaction-v01。保留底座、腳底 anchor、角色逐列分層與獨立提示。來源及原生畫面見 `artifacts/ios/art-integration/`，未新增角色生成或動畫。

## Owner 最新建模方向的切片

Owner 明確要求皇室戰爭式的真正卡通建模，V1 增加下面三片；原本 2D 插畫整合保留為比較候選。

| Slice | 交付 | Gate／状态 |
|---|---|---|
| V1-3D-01 | 三職真實網格、PBR 材質、光照、棋盤／近距離共用、前後旋轉檢視 | 目前三職原創mesh／11骨工程可執行；Owner於09:13明確否決外觀，改先重做單一雕塑大形並審實際3D畫面，V1品質未通過 |
| A-IDLE-01 | 模型檢視 opt-in 三職 3.4秒骨架待機、103幀可編輯工程與獨立USDZ | 兩尺寸native pose／啟停與還原、實際錄影影格候選通過；遊戲預設與v08技能資源保持，Owner／真機待辦 |
| SW2a-3D-01 | RealityKit nonAR 棋盤、原生投影選點、7×7／9×9、預覽與復原 | 本輪已接線；模擬器操作證據見 `artifacts/ios/models-3d/`；真機 Gate 待辦 |
| V1-3D-02 | 精修三職面部／輪廓／裝備、角色卡統一、正式模型資源與效能預算 | 已交付三職v08可編輯.blend/USDZ、UV材質、11骨／肩袖／披風有限蒙皮及同模型卡片，普通單位v02已原生驗證，完整organic rig／Owner品質與真機待驗收 |

## 規則疑慮獨立驗收

保留 `docs/RULES_DRAFT.md` §8：先手補償、superko、主將起始位置、資源成本、回合上限、封印細節仍是 Draft／候選。另觀察戰士同回合三子是否過強、英雄是否值得召喚、英雄早死是否失去職業差異、最佳策略是否與職業無關。任何 Golden PASS 均不會將它們升級為 Accepted。

視覺草稿的「魔法之手」與現行核心「封印」不同；本輪遵循已有規則與 Golden，不把美術示意當作規則核准。

## 2026-10-09 09:50 — Owner 要求回到原角色身份

Owner 追加「至少要有這樣的程度」並提供 Plants on Fire 手機畫面，隨後明確要求「按照之前設計的圖片來建模」。身份依據固定為 character-style 三職 v01 全身圖與 VIS-FEEL-01 的 B-v02 卡片：戰士栗髮／無頭盔／奶油衣／青綠披風／左盾右劍；法師年輕紫髮／紫帽奶油邊／右手晶杖；盜賊銅髮／靛藍開臉兜帽／苔綠背心／赭圍巾／右短刀。所有六張已逐一看圖，v01 SHA 已核對。皇室戰爭與 Plants on Fire 是完成品質、體積光影與手機可讀性的標準，不能據此換角色。

v09 與 v10 騎士雕塑均不算視覺通過；新河流城堡場景僅保留為獨立構圖研究。官方 KayKit Adventurers 2.0 FREE 實際下載、CC0 許可已讀，僅可作拓撲／骨架／動畫做法與合法施工基底，不可原樣換入新人物或宣稱全原創。原設計 v01 與 B-v02 仍 candidate，並未擅自升格 exact-file production approval。

切片：ID-M1 戰士原設計的臉／髮／衣／左右裝備重建及正側背對照 → ID-M2 法師與盜賊一致性 → ID-A1 相容骨架動作與原生載入／還原 → ID-V1 iPhone 三種完整畫面。先看模型是否像原图，再做整合。第一輪戰士 source 渲染仍有浮眼、硬髮、姿態偏差，保留失敗圖並修正，不替換 main bundle、不宣稱品質 Gate。期限 11:09:54 不變，無 commit/push/發布，模擬器不替代真機。


## 2026-10-09 11:06 — 原圖身份候選與原生動作證據（品質尚未通過）

ID-M1／M2 已有三職原圖身份候選：栗髮左盾右劍戰士、紫髮紫帽晶杖法師、銅髮開臉靛帽苔綠衣盜賊。最新 source 為 ios-identity-motion-v05，各有可編輯 .blend、23骨、43幀自編造型動作與 strict USDZ；KayKit CC0 僅施工基底，不替代身份，不宣稱全原創。iOS 模型檢視可 opt-in 原圖候選與原全身縮圖對照；主棋盤仍 v09/11骨，23骨 gameplay adapter 未做。首 source 烘焙／staff零權重選取／native後腦透眼失敗均保留，五個實際 mesh 的法師 staff 修正 pass/fail regression 通過；最新補閉合頭與內袖後，原生眼睛透後腦消除，但袖口縫、握持、背髮帽殼與平板披風仍存在。

v05 build-for-testing與12 USD流程步驟exit0；SE/iOS18 focused UI 1/1 PASS。17六正背截圖與六動作的十二對齊影格全部人工看過，max clock誤差 .0166秒，6 controller完成18 joint samples，31,301,946-byte native movie。Warrior importer片段1.2s而source1.4s未定位原因；兩資源是global/subtree重複入口，非兩套獨立動畫。最新17 UI／SE正面像素補驗正在收尾，另以 final evidence 結果為準。Core本輪未改，模擬器不等於真機，不宣稱品質Gate。ID-V1三種完整局面、7/9新模型比例及規則技能／落子／提子／勝負完整整合尚未完成。證據 artifacts/ios/identity-model-v01/REVIEW.md、VALIDATION.md。

11:09:54期限維持；到期停止新切片，整理既有結果及Owner待決，不commit/push/發布，不將候選升格完成。

11:08 收尾補驗：最新17／SE focused UI各1/1 PASS，SE3職正面也人工看過；9張静止＋12動作影格。final-input-consistency.json 核對源工程／USD／包／bundle／installed17及原圖bytes一致。美術與完整場景仍未通過，見 identity-model-v01/REVIEW.md、VALIDATION.md。

11:09:54窗口到期：停止新增切片。三職原圖模型與造型動作仍為候選，所有美術／完整場景／真機 Gate 保持未通過；可檢查交付與待修項見 identity-model-v01/REVIEW.md、VALIDATION.md、window-end.json。無commit/push/發布。


## 2026-10-09 — Owner 戰士 B-v02 頭胸像限定修正

Owner新一輪明確要求唯一身份基準B-warrior-v02、只做靜態頭胸像、固定光源並排/3quarter/side/128/64檢查；Owner核准前不做下半身與動畫。不是恢復已到期十小時全角色/場景任務，也不調整Gameplay/Domain/G0–G4。實際前版為Blender可編輯mesh、CC0頭四肢施工base、23骨與USDZ、iOS實際渲染，不是AI圖片；前版混用v01+B-v02並誤讀盾徽為castle，身份失真成立。

本機僅512B-v02衍生PNG，源provenance記載1254原圖但實際檔與本機/ZIP搜尋未找到；已更正早先以metadata誤稱找到高解析原檔。先以同一B-v02 identity的實際PNG製作可逆靜態mesh候選，reference SHA50885855dc9faee8966558ea854f99d24bd0ffd0ed93c03bb6b87c8643d42298。原圖gold component內區域描邊為分岔浮雕，非新造城牆icon；新造眉角/almond lids/下顎/外翹栗髮、silver shoulder rim、厚teal folds/gold roundclasp、連續手部劍柄護手寬刃。不得靠更多細節或換light報identity完成。

可檢查工程在 assets/candidates/warrior-bust-bv02-v01，計畫 artifacts/ios/warrior-bust-bv02-v01/PLAN.md。沒有替換现有bundle/角色卡；原圖未定義的側背深度只candidate。高解析master回補與Owner同角色核准待驗證。


戰士B-v02靜態頭胸像首輪交付：warrior-bust-bv02-v02可編輯.blend/靜態USD/七張fixed视角與native尺寸render、並排QA，artifact path warrior-bust-bv02-v01/REVIEW.md、VALIDATION.md。v01浮眼/端口/盾邊問題保留，v02單件mesh0非流形0退化、101物件106132vertices、0rig/actions/lowerbody，USD strict PASS。main app資源/binary12 SHA與本輪前一致，Gameplay/Domain/G0–G4未改。所有实际png與原圖並排人工看過；P0身份修正仍FAIL/PENDING：oversize curl/頭髮剪影、臉部氣質仍偏差，不因engineeringPASS升格。唯一B-v02身份reference是現存512衍生圖，1254原檔缺失；Owner需先看頭胸像且回補master，未核准前不延伸全身或動畫。本輪沒有commit/push/發布。

## ID-H1 — Warrior Identity Recovery（Owner 新授權，頭部限定）

先研究 reference-to-3d／validator 與 Blender Studio 公開頭雕流程；用同一B-v02的可見輪廓和五官配準做獨立頭部粗胚，原畫／3D／50%overlay／灰階輪廓與推定側面交付。最新head-v02、前版head-v01及失敗頭胸像都保留。可審查候選完成，身份Gate未通過；主要偏差是硬葉片髮塊、簡化眼耳頰、未知側背粗胚。鏡頭與深度為单圖推定，輪廓IoU不是身份證明。詳見 artifacts/ios/warrior-identity-head-v02/REVIEW.md 與VALIDATION.md。

本片停在Owner評估；不處理新裝備、髮絲細節、下半身、骨架、動畫、USD/LOD，也不修改Gameplay/Domain/G0–G4。未安裝第三方MCP，未commit/push/merge。已到期十小時排程仍停用。

ID-H1正式Owner審查（2026-10-09）：研究成果接受，Identity Gate不通過，正式模型不接受。停止此Mesh方法及所有後續素材，不再開修髮片。不建立新框架。下輪A/B只提出成本可行性比較，docs/ios/CHARACTER_PRODUCTION_ROUTES.md；推薦A0，但路線仍待Owner選擇，沒有啟動A或B。G0–G4保持原路線。
