import XCTest

@MainActor final class CombatFeelTests: XCTestCase {
    private func launch(_ args: [String] = ["--combat-demo"]) -> XCUIApplication {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = args; app.launch()
        XCTAssertTrue(app.otherElements["playArena"].waitForExistence(timeout: 10))
        return app
    }
    private func tap(_ app: XCUIApplication, _ x: Int, _ y: Int, size: Int = 7) {
        let arena = app.otherElements["playArena"]
        let row = Double(y) / Double(size - 1), inset = 0.13 - 0.06 * row
        arena.coordinate(withNormalizedOffset: CGVector(dx: inset + (1 - 2 * inset) * Double(x) / Double(size - 1), dy: 0.18 + 0.65 * row)).tap()
    }
    private func screenshot(_ app: XCUIApplication, _ name: String) {
        let shot = XCTAttachment(screenshot: app.screenshot()); shot.name = name; shot.lifetime = .keepAlways; add(shot)
    }
    private func waitSettled(_ app: XCUIApplication) {
        let status = app.staticTexts["feedbackStatus"]
        expectation(for: NSPredicate(format: "value == %@", "settled"), evaluatedWith: status)
        waitForExpectations(timeout: 6)
    }
    private func prepare(_ app: XCUIApplication, size: Int = 7) {
        tap(app, 4, 3, size: size)
        XCTAssertFalse(app.buttons["playConfirm"].isEnabled)
        XCTAssertFalse(app.buttons["push-Left"].isEnabled)
        app.buttons["push-Up"].tap()
        XCTAssertTrue(app.buttons["playConfirm"].isEnabled)
        XCTAssertTrue(app.staticTexts["2 AP"].exists)
        XCTAssertTrue(app.staticTexts.containing(NSPredicate(format: "label CONTAINS %@", "能量 4/6")).count > 0)
    }
    func testPreviewCancelCommitVictoryUndoAndReplay() {
        let app = launch()
        tap(app, 3, 2) // Commander is not a valid push target.
        XCTAssertFalse(app.buttons["playConfirm"].isEnabled)
        XCTAssertEqual(app.staticTexts["feedbackStatus"].value as? String, "idle")
        app.buttons["undoOrCancel"].tap()
        prepare(app); screenshot(app, "Combat-preview-7")
        XCTAssertFalse(app.staticTexts["黑方獲勝"].exists)
        app.buttons["undoOrCancel"].tap()
        XCTAssertTrue(app.staticTexts["2 AP"].exists)
        prepare(app); app.buttons["playConfirm"].tap(); waitSettled(app)
        XCTAssertTrue(app.staticTexts["黑方獲勝"].exists)
        XCTAssertTrue(app.staticTexts["1 AP"].exists)
        XCTAssertTrue(app.staticTexts.containing(NSPredicate(format: "label CONTAINS %@", "能量 2/6")).count > 0)
        screenshot(app, "Combat-victory-7")
        app.buttons["undoOrCancel"].tap()
        XCTAssertFalse(app.staticTexts["黑方獲勝"].exists)
        XCTAssertTrue(app.staticTexts["2 AP"].exists)
        prepare(app); app.buttons["playConfirm"].tap(); waitSettled(app)
        XCTAssertTrue(app.staticTexts["黑方獲勝"].exists)
        app.buttons["重播示範"].tap()
        XCTAssertFalse(app.staticTexts["黑方獲勝"].exists)
        XCTAssertEqual(app.staticTexts["feedbackStatus"].value as? String, "idle")
        XCTAssertTrue(app.staticTexts["2 AP"].exists)
    }
    func testReducedMotionNineBoardAndBackgroundDoesNotReplayReceipt() {
        let app = launch(["--combat-demo", "--combat-nine", "--combat-reduced-motion"])
        XCTAssertEqual(app.otherElements["playArena"].label, "9乘9棋盤")
        prepare(app, size: 9); screenshot(app, "Combat-preview-9-reduced")
        app.buttons["playConfirm"].tap()
        XCUIDevice.shared.press(.home)
        app.activate()
        let status = app.staticTexts["feedbackStatus"]
        XCTAssertNotEqual(status.value as? String, "playing")
        XCTAssertTrue(app.staticTexts["黑方獲勝"].exists)
        screenshot(app, "Combat-background-return-9-reduced")
        app.buttons["undoOrCancel"].tap()
        XCTAssertTrue(app.staticTexts["2 AP"].exists)
        prepare(app, size: 9); app.buttons["playConfirm"].tap(); waitSettled(app)
        XCTAssertTrue(app.staticTexts["黑方獲勝"].exists)
    }
    func testSoundSettingsPersistAndLeavingMatchCancelsPlayback() {
        let app = launch()
        app.buttons["對戰選單"].tap(); app.buttons["聲音設定"].tap()
        let toggle = app.switches["audioMute"]
        XCTAssertTrue(toggle.waitForExistence(timeout: 5))
        let before = toggle.value as? String
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.92, dy: 0.5)).tap()
        let after = toggle.value as? String
        XCTAssertNotEqual(before, after)
        app.sliders["sfxVolume"].adjust(toNormalizedSliderPosition: 0.25)
        app.sliders["musicVolume"].adjust(toNormalizedSliderPosition: 0.15)
        screenshot(app, "Combat-sound-settings")
        app.buttons["audioSettingsDone"].tap()
        app.terminate(); app.launch()
        XCTAssertTrue(app.otherElements["playArena"].waitForExistence(timeout: 10))
        app.buttons["對戰選單"].tap(); app.buttons["聲音設定"].tap()
        XCTAssertEqual(app.switches["audioMute"].value as? String, after)
        app.switches["audioMute"].coordinate(withNormalizedOffset: CGVector(dx: 0.92, dy: 0.5)).tap() // Restore the original preference.
        app.buttons["audioSettingsDone"].tap()
        prepare(app); app.buttons["playConfirm"].tap()
        app.buttons["chevron.left"].tap()
        app.sheets["離開目前對戰？"].buttons["返回選角"].tap()
        XCTAssertTrue(app.buttons["combatDemo"].waitForExistence(timeout: 5))
        app.buttons["combatDemo"].tap()
        XCTAssertEqual(app.staticTexts["feedbackStatus"].value as? String, "idle")
        XCTAssertTrue(app.staticTexts["2 AP"].exists)
        XCTAssertFalse(app.staticTexts["黑方獲勝"].exists)
    }
    func testRecordedMagicHandShowcase() {
        let app = launch()
        app.buttons["對戰選單"].tap(); app.buttons["聲音設定"].tap()
        if app.switches["audioMute"].value as? String == "1" { app.switches["audioMute"].coordinate(withNormalizedOffset: CGVector(dx: 0.92, dy: 0.5)).tap() }
        app.sliders["sfxVolume"].adjust(toNormalizedSliderPosition: 0.65)
        app.sliders["musicVolume"].adjust(toNormalizedSliderPosition: 0.30)
        app.buttons["audioSettingsDone"].tap()
        Thread.sleep(forTimeInterval: 3)
        tap(app, 4, 3); Thread.sleep(forTimeInterval: 3)
        app.buttons["push-Up"].tap(); screenshot(app, "Showcase-magic-preview")
        Thread.sleep(forTimeInterval: 3)
        app.buttons["playConfirm"].tap(); waitSettled(app)
        screenshot(app, "Showcase-magic-victory"); Thread.sleep(forTimeInterval: 4)
        app.buttons["undoOrCancel"].tap(); Thread.sleep(forTimeInterval: 2)
        prepare(app); app.buttons["playConfirm"].tap(); waitSettled(app)
        Thread.sleep(forTimeInterval: 4)
    }
    func testNativeMidPlaybackCancellationAudit() {
        let app = launch(["--combat-demo", "--combat-audit"])
        let result = app.staticTexts["auditStatus"]
        expectation(for: NSPredicate(format: "label == %@", "PASS"), evaluatedWith: result)
        waitForExpectations(timeout: 15)
        screenshot(app, "Combat-native-cancellation-audit")
    }
    func testNativeAudioPoolCompletionAndCancellationAudit() {
        let app = launch(["--combat-demo", "--combat-audio-audit"])
        expectation(for: NSPredicate(format: "label == %@", "PASS"), evaluatedWith: app.staticTexts["auditStatus"])
        waitForExpectations(timeout: 15)
        screenshot(app, "Combat-native-audio-pool-audit")
    }
}
