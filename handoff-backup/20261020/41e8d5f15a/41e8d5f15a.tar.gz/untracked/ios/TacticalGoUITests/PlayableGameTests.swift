import XCTest

@MainActor final class PlayableGameTests: XCTestCase {
    private func app(_ args: [String] = []) -> XCUIApplication {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = args; app.launch(); return app
    }
    private func tap(_ app: XCUIApplication, _ x: Int, _ y: Int, size: Int = 7) {
        let arena = app.otherElements["playArena"]
        XCTAssertTrue(arena.waitForExistence(timeout: 10))
        // Independent published trapezoid projection, not production helper calls.
        let row = Double(y) / Double(size - 1)
        let inset = 0.13 - 0.06 * row
        let px = inset + (1 - inset * 2) * Double(x) / Double(size - 1)
        let py = 0.18 + 0.65 * row
        arena.coordinate(withNormalizedOffset: CGVector(dx: px, dy: py)).tap()
    }
    private func shot(_ app: XCUIApplication, _ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot()); attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }
    func testVisualPackConnectionPreservesPreviewCancelCommitAndUndo() {
        let app = app(["--visual-pack-fixture"])
        XCTAssertTrue(app.buttons["startMatch"].waitForExistence(timeout: 10))
        app.buttons["startMatch"].tap()
        XCTAssertEqual(app.staticTexts["visualPackStatus"].label, "素材接線：a0-interface-fixture")
        app.buttons["mode-summon"].tap(); tap(app, 3, 4)
        XCTAssertTrue(app.buttons["playConfirm"].isEnabled)
        XCTAssertEqual(app.staticTexts["currentTurn"].label, "輪到黑方戰士")
        shot(app, "V2-interface-summon-preview")
        app.buttons["undoOrCancel"].tap()
        XCTAssertFalse(app.buttons["playConfirm"].isEnabled)
        tap(app, 3, 4); app.buttons["playConfirm"].tap()
        XCTAssertEqual(app.staticTexts["currentTurn"].label, "輪到白方法師")
        shot(app, "V2-interface-committed")
        app.buttons["undoOrCancel"].tap()
        XCTAssertEqual(app.staticTexts["currentTurn"].label, "輪到黑方戰士")
        tap(app, 3, 4); XCTAssertTrue(app.buttons["playConfirm"].isEnabled)
    }
    func testMissingVisualAssetRejectsWholePackAndGameRemainsPlayable() {
        let app = app(["--visual-pack-invalid-fixture"])
        XCTAssertTrue(app.buttons["startMatch"].waitForExistence(timeout: 10))
        app.buttons["startMatch"].tap()
        XCTAssertEqual(app.staticTexts["visualPackStatus"].label, "素材拒絕，保留原圖")
        tap(app, 3, 4); XCTAssertTrue(app.buttons["playConfirm"].isEnabled)
        app.buttons["playConfirm"].tap()
        XCTAssertEqual(app.staticTexts["currentTurn"].label, "輪到白方法師")
        shot(app, "V2-interface-rejected-pack-original-fallback")
    }
    func testChooseClassesSummonBothSidesPreviewCancelAndUndo() {
        let app = app()
        XCTAssertTrue(app.buttons["startMatch"].waitForExistence(timeout: 10))
        shot(app, "A0-class-picker")
        app.buttons["choose-rogue"].tap()
        app.segmentedControls["choosingTeam"].buttons["白方 ○"].tap()
        app.buttons["choose-mage"].tap()
        app.buttons["startMatch"].tap()
        XCTAssertTrue(app.staticTexts["盜賊 · 換位"].exists)
        XCTAssertEqual(app.staticTexts["currentTurn"].label, "輪到黑方盜賊")
        app.buttons["mode-summon"].tap()
        tap(app, 3, 4)
        XCTAssertTrue(app.buttons["playConfirm"].isEnabled)
        XCTAssertTrue(app.staticTexts["1 AP"].exists)
        XCTAssertEqual(app.staticTexts["currentTurn"].label, "輪到黑方盜賊")
        shot(app, "A0-summon-preview")
        app.buttons["undoOrCancel"].tap()
        XCTAssertFalse(app.buttons["playConfirm"].isEnabled)
        tap(app, 3, 4); app.buttons["playConfirm"].tap()
        XCTAssertTrue(app.staticTexts["法師 · 魔法之手"].exists)
        XCTAssertEqual(app.staticTexts["currentTurn"].label, "輪到白方法師")
        XCTAssertTrue(app.staticTexts["行動中"].exists)
        XCTAssertTrue(app.staticTexts["等待"].exists)
        XCTAssertTrue(app.staticTexts["2 AP"].exists)
        app.buttons["mode-summon"].tap(); tap(app, 3, 2); app.buttons["playConfirm"].tap()
        XCTAssertTrue(app.staticTexts["1 AP"].exists)
        shot(app, "A0-two-heroes-match")
        app.buttons["undoOrCancel"].tap()
        XCTAssertTrue(app.staticTexts["2 AP"].exists)
        XCTAssertEqual(app.staticTexts["currentTurn"].label, "輪到白方法師")
        app.buttons["mode-soldier"].tap(); tap(app, 3, 1)
        XCTAssertFalse(app.buttons["playConfirm"].isEnabled)
        XCTAssertEqual(app.staticTexts["playMessage"].label, "這裡已有棋子。")
        app.buttons["undoOrCancel"].tap()
        app.buttons["playEndTurn"].tap()
        XCTAssertTrue(app.staticTexts["盜賊 · 換位"].exists)
        XCTAssertEqual(app.staticTexts["currentTurn"].label, "輪到黑方盜賊")
    }
    func testSameClassHeroesStillIdentifyBlackAndWhite() {
        let app = app()
        XCTAssertTrue(app.buttons["startMatch"].waitForExistence(timeout: 10))
        app.buttons["choose-mage"].tap() // both sides are Mage
        app.buttons["startMatch"].tap()
        XCTAssertEqual(app.staticTexts["currentTurn"].label, "輪到黑方法師")
        app.buttons["mode-summon"].tap(); tap(app, 3, 4); app.buttons["playConfirm"].tap()
        XCTAssertEqual(app.staticTexts["currentTurn"].label, "輪到白方法師")
        app.buttons["mode-summon"].tap(); tap(app, 3, 2); app.buttons["playConfirm"].tap()
        shot(app, "A0-black-white-same-mage")
        app.buttons["以格點清單操作棋盤"].tap()
        let white = app.buttons["cell-3-2"]
        for _ in 0..<8 { if white.exists { break }; app.swipeUp() }
        XCTAssertTrue(white.waitForExistence(timeout: 5))
        XCTAssertTrue(white.label.contains("白方 法師"))
        // Grid labels are backed by actual ownership, even with identical source art.
        let black = app.buttons["cell-3-4"]
        for _ in 0..<8 { if black.exists { break }; app.swipeUp() }
        XCTAssertTrue(black.waitForExistence(timeout: 5))
        XCTAssertTrue(black.label.contains("黑方 法師"))
    }
    func testCompleteMatchFromNewGameAndWinningMoveUndo() {
        let app = app()
        XCTAssertTrue(app.buttons["startMatch"].waitForExistence(timeout: 10))
        app.buttons["startMatch"].tap()
        // Independent cooperative match: cover all four liberties of red D2.
        // Red spends each intervening turn away from its commander.
        for (x, y) in [(3,0), (0,6), (1,6), (2,1), (4,1), (0,5), (1,5), (3,2)] {
            tap(app, x, y)
            XCTAssertTrue(app.buttons["playConfirm"].isEnabled)
            app.buttons["playConfirm"].tap()
        }
        XCTAssertTrue(app.staticTexts["黑方獲勝"].waitForExistence(timeout: 5))
        XCTAssertEqual(app.staticTexts["currentTurn"].label, "對戰結束")
        XCTAssertFalse(app.buttons["playEndTurn"].isEnabled)
        shot(app, "A0-complete-match-real-new-game")
        app.buttons["undoOrCancel"].tap()
        XCTAssertFalse(app.staticTexts["黑方獲勝"].exists)
        tap(app, 3, 2)
        XCTAssertTrue(app.buttons["playConfirm"].isEnabled)
        app.buttons["playConfirm"].tap()
        XCTAssertTrue(app.staticTexts["黑方獲勝"].waitForExistence(timeout: 5))
        XCTAssertEqual(app.staticTexts["currentTurn"].label, "對戰結束")
    }
    func testFourPlayablePracticeLessonsAndUndo() {
        for name in ["包圍與提子", "戰士築壘", "法師魔法之手", "盜賊換位"] {
            let app = app(["--practice", name])
            XCTAssertTrue(app.otherElements["playArena"].waitForExistence(timeout: 10))
            XCTAssertFalse(app.buttons["playConfirm"].isEnabled)
            switch name {
            case "包圍與提子": tap(app, 3, 3)
            case "戰士築壘":
                tap(app, 2, 3); XCTAssertFalse(app.buttons["playConfirm"].isEnabled); tap(app, 4, 3)
            case "法師魔法之手":
                tap(app, 4, 3); XCTAssertFalse(app.buttons["playConfirm"].isEnabled)
                XCTAssertFalse(app.buttons["push-Left"].isEnabled)
                app.buttons["push-Up"].tap()
            default: tap(app, 4, 3)
            }
            XCTAssertTrue(app.buttons["playConfirm"].isEnabled)
            XCTAssertTrue(app.staticTexts["2 AP"].exists)
            shot(app, "A0-" + name + "-preview")
            app.buttons["playConfirm"].tap()
            XCTAssertTrue(app.staticTexts["練習完成"].waitForExistence(timeout: 5))
            shot(app, "A0-" + name + "-completed")
            app.buttons["undoOrCancel"].tap()
            XCTAssertFalse(app.staticTexts["練習完成"].exists)
            XCTAssertTrue(app.staticTexts["2 AP"].exists)
            app.terminate()
        }
    }
    func testNineBoardAccessibleGridWinAndDraw() {
        let nine = app(["--play-nine"])
        XCTAssertTrue(nine.otherElements["playArena"].waitForExistence(timeout: 10))
        XCTAssertEqual(nine.otherElements["playArena"].label, "9乘9棋盤")
        tap(nine, 4, 6, size: 9)
        XCTAssertTrue(nine.buttons["playConfirm"].isEnabled)
        shot(nine, "A0-nine-board-preview")
        nine.buttons["playConfirm"].tap()
        XCTAssertTrue(nine.staticTexts["2 AP"].exists)
        nine.buttons["以格點清單操作棋盤"].tap()
        XCTAssertTrue(nine.buttons["cell-0-0"].waitForExistence(timeout: 5))
        nine.buttons["cell-0-0"].tap()
        XCTAssertTrue(nine.buttons["playConfirm"].isEnabled)
        nine.terminate()
        let win = app(["--play-win"])
        tap(win, 3, 3); win.buttons["playConfirm"].tap()
        XCTAssertTrue(win.staticTexts["黑方獲勝"].waitForExistence(timeout: 5))
        XCTAssertFalse(win.buttons["playEndTurn"].isEnabled)
        shot(win, "A0-win")
        win.buttons["undoOrCancel"].tap()
        XCTAssertFalse(win.staticTexts["黑方獲勝"].exists)
        win.terminate()
        let draw = app(["--play-draw"])
        XCTAssertTrue(draw.buttons["playEndTurn"].waitForExistence(timeout: 10))
        draw.buttons["playEndTurn"].tap()
        XCTAssertTrue(draw.staticTexts["和局"].waitForExistence(timeout: 5))
        XCTAssertFalse(draw.buttons["playEndTurn"].isEnabled)
        shot(draw, "A0-draw")
        draw.buttons["再玩一局"].tap()
        XCTAssertFalse(draw.staticTexts["和局"].exists)
        XCTAssertTrue(draw.staticTexts["1 AP"].exists)
    }
}
