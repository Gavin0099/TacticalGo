import SwiftUI
import TacticalGoCore
import TacticalGoMotion

@MainActor @Observable final class GameStore {
    enum Review: String, CaseIterable { case normal = "一般", skill = "技能預覽", danger = "危險" }
    enum Mode: String, CaseIterable { case soldier = "放士兵", summon = "召喚英雄", skill = "使用技能" }
    var session: GameSession
    var playback: BoardPlayback?
    let audio = CombatAudio()
    private(set) var feedbackStatus = "idle"
    var isFeedbackPlaying: Bool { feedbackStatus == "playing" }
    private(set) var reducedMotion = false
    private var feedbackActive = false
    private var sceneActive = true
    @ObservationIgnored private var feedbackTask: Task<Void, Never>?
    @ObservationIgnored private var feedbackGeneration = UUID()

    /// The receipt only describes a Domain-confirmed result. Cancelling its
    /// presentation never rolls back or resolves any game rules.
    func cancelFeedback() {
        feedbackGeneration = UUID()
        feedbackTask?.cancel(); feedbackTask = nil
        audio.cancelEffects(); playback = nil
        if isFeedbackPlaying { feedbackStatus = "cancelled" }
    }
    func setMatchActive(_ active: Bool) {
        feedbackActive = active
        if !active { cancelFeedback() }
        audio.setMatchActive(active)
    }
    func setSceneActive(_ active: Bool) {
        sceneActive = active
        if !active { cancelFeedback() }
        audio.setSceneActive(active)
    }
    func setReducedMotion(_ value: Bool) {
        guard reducedMotion != value else { return }
        cancelFeedback(); reducedMotion = value
    }
    private func present(before: GameState, action: GameAction, outcome: ActionOutcome) {
        cancelFeedback()
        playback = BoardPlayback(before: before, action: action, outcome: outcome)
        guard feedbackActive, sceneActive else { return }
        let plan = CombatFeedbackPlan.make(before: before, action: action, outcome: outcome, reducedMotion: reducedMotion)
        let generation = feedbackGeneration
        feedbackStatus = "playing"
        #if DEBUG
        traceEvent("confirmed", key: String(describing: action))
        print("COMBAT_FEEDBACK confirmed \(Date().timeIntervalSince1970) \(action)")
        #endif
        feedbackTask = Task { [weak self] in
            var elapsed = 0.0
            for cue in plan.cues {
                do { try await Task.sleep(for: .seconds(max(0, cue.start - elapsed))) }
                catch { return }
                guard let self, self.feedbackGeneration == generation, !Task.isCancelled else { return }
                self.traceEvent("sound", key: cue.key)
                self.audio.play(cue.key)
                #if DEBUG
                print("COMBAT_FEEDBACK sound \(Date().timeIntervalSince1970) \(cue.key)")
                #endif
                elapsed = cue.start
            }
            do { try await Task.sleep(for: .seconds(max(0, plan.duration - elapsed))) }
            catch { return }
            guard let self, self.feedbackGeneration == generation, !Task.isCancelled else { return }
            self.playback = nil; self.feedbackStatus = "settled"; self.feedbackTask = nil
        }
    }
    #if DEBUG
    @ObservationIgnored private var traceEnabled = false
    @ObservationIgnored private var traceEvents: [[String: Any]] = []
    func enableCombatTrace() { traceEnabled = true; traceEvents = []; traceEvent("session", key: "demo") }
    #endif
    private func traceEvent(_ kind: String, key: String) {
        #if DEBUG
        guard traceEnabled else { return }
        traceEvents.append(["timestamp": Date().timeIntervalSince1970, "kind": kind, "key": key,
                            "muted": audio.muted, "sfxVolume": audio.sfxVolume, "musicVolume": audio.musicVolume])
        if let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first,
           let data = try? JSONSerialization.data(withJSONObject: traceEvents, options: [.prettyPrinted, .sortedKeys]) {
            try? data.write(to: directory.appendingPathComponent("combat-trace.json"), options: .atomic)
        }
        #endif
    }
    var review: Review = .normal
    var mode: Mode = .soldier
    var selected: [Point] = []
    var pushDirection: PushDirection?
    var message = "點棋盤預覽，再按確認。"
    enum Renderer: String, CaseIterable { case models = "3D", swiftUI = "SwiftUI", spriteKit = "SpriteKit" }
    var renderer: Renderer = .models
    var size = 7
    var state: GameState { session.state }
    var selectedAction: GameAction? {
        guard let p = selected.first else { return nil }
        switch mode {
        case .soldier: return .placeSoldier(p)
        case .summon: return .summonHero(p)
        case .skill:
            switch state.heroClass(of: state.current) {
            case .warrior: return selected.count == 2 ? .castBastion(selected[0], selected[1]) : nil
            case .mage:
                if state.config.mageSkill == .seal { return .castSeal(p) }
                return pushDirection.map { .castMagicHand(p, $0) }
            case .rogue: return .castSwap(p)
            case .none: return nil
            }
        }
    }
    var preview: ActionOutcome? { selectedAction.map { GameEngine.apply(state, $0) } }
    var legalTargets: Set<Point> {
        let actions = GameEngine.legalActions(state)
        return Set(actions.flatMap { action -> [Point] in
            switch (mode, action) {
            case (.soldier, .placeSoldier(let p)), (.summon, .summonHero(let p)): return [p]
            case (.skill, .castSeal(let p)), (.skill, .castSwap(let p)): return [p]
            case (.skill, .castMagicHand(let p, _)): return [p]
            case (.skill, .castBastion(let a, let b)):
                if let first = selected.first { return a == first || b == first ? [a, b] : [] }
                return [a, b]
            default: return []
            }
        })
    }
    init() {
        session = GameSession(Self.scenario(size: 7, review: .normal))
        audio.onInterruption = { [weak self] in self?.cancelFeedback() }
    }
    func load(_ review: Review? = nil, size: Int? = nil) {
        cancelFeedback(); feedbackStatus = "idle"
        if let review { self.review = review }
        if let size { self.size = size }
        session = GameSession(Self.scenario(size: self.size, review: self.review))
        playback = nil
        mode = self.review == .skill ? .skill : .soldier
        selected = self.review == .skill ? [Point(4, 3)] : []
        message = self.review == .danger ? "主將棋串只剩 1 個生存空格。" : "點棋盤預覽，再按確認。"
    }
    func select(_ p: Point) {
        guard !isFeedbackPlaying else { return }
        if feedbackActive && sceneActive { traceEvent("selection", key: "selection"); audio.play("selection") }
        if mode == .skill && state.heroClass(of: state.current) == .warrior {
            if selected.count != 1 || selected[0] == p { selected = [p] } else { selected.append(p) }
        } else { selected = [p]; pushDirection = nil }
        if let preview { message = preview.success ? "預覽不扣資源；確認後才生效。" : Self.reason(preview.reason) }
        else { message = state.heroClass(of: state.current) == .mage ? "魔法之手：選擇推動方向。" : "築壘：再選另一個相鄰空點。" }
    }
    func changeMode(_ value: Mode) { cancelFeedback(); mode = value; selected = []; pushDirection = nil; message = "選擇目標後再確認。" }
    func confirm() {
        guard !isFeedbackPlaying, (!feedbackActive || sceneActive), let action = selectedAction else { return }
        let before = state
        let o = session.apply(action)
        if o.success {
            present(before: before, action: action, outcome: o)
            selected = []; pushDirection = nil
            if before.current != state.current { mode = .soldier }
            let actor = (state.current == .one ? "黑方" : "白方") + state.heroClass(of: state.current).title
            message = terminalMessage ?? (before.current != state.current ? "已換手，輪到" + actor + "，\(state.apRemaining) AP。" : actor + "還能行動 \(state.apRemaining) 次。")
        } else { message = Self.reason(o.reason) }
    }
    func undo() { cancelFeedback(); if session.undo() { playback = nil; selected = []; pushDirection = nil; message = "已復原；輪到\(state.current == .one ? "黑方" : "白方")\(state.heroClass(of: state.current).title)。" } }
    func endTurn() {
        guard !isFeedbackPlaying, (!feedbackActive || sceneActive) else { return }
        let before = state, outcome = session.apply(.endTurn)
        guard outcome.success else { message = Self.reason(outcome.reason); return }
        present(before: before, action: .endTurn, outcome: outcome)
        selected = []; pushDirection = nil; mode = .soldier; message = terminalMessage ?? "已換手，輪到\(state.current == .one ? "黑方" : "白方")\(state.heroClass(of: state.current).title)，\(state.apRemaining) AP。"
    }
    var resultTitle: String? {
        switch state.status {
        case .ongoing: nil
        case .won: "\(state.winner == .one ? "黑方" : "白方")獲勝"
        case .drawn: "和局"
        }
    }
    var terminalMessage: String? {
        switch state.status {
        case .ongoing: nil
        case .won: "\(state.winner == .one ? "黑方" : "白方")獲勝！主將已被包圍。"
        case .drawn: "已達 \(state.config.maxPlies) 回合上限，對戰以和局結束。"
        }
    }
    #if DEBUG
    func loadWinningTurn() {
        cancelFeedback(); feedbackStatus = "idle"
        size = 7; review = .normal
        session = GameSession(try! MotionExample.victory.initialState())
        playback = nil; selected = []; mode = .soldier
        message = "主將只剩一個生存空格：在中央落子檢查勝負回饋。"
    }
    func loadLastTurn() {
        cancelFeedback(); feedbackStatus = "idle"
        let initial = Self.scenario(size: size, review: .normal)
        session = GameSession(try! GameSetup.fromDiagram(config: initial.config, diagram: initial.board.diagram,
            classOne: initial.heroClass(of: .one), classTwo: initial.heroClass(of: .two),
            manaOne: initial.mana(of: .one), manaTwo: initial.mana(of: .two), ap: 1, ply: initial.config.maxPlies))
        playback = nil; selected = []; mode = .soldier; message = "最後一回合：結束後依既有規則判定和局。"
    }
    #endif
    func newMatch(classOne: HeroClass = .warrior, classTwo: HeroClass = .mage) {
        cancelFeedback(); feedbackStatus = "idle"
        session = GameSession(try! GameSetup.newGame(config: .board(size: size), classOne: classOne, classTwo: classTwo))
        playback = nil; review = .normal
        selected = []; pushDirection = nil; mode = .soldier; message = "本機雙人：黑方先手，首回合 1 次行動。"
    }
    static func scenario(size: Int, review: Review) -> GameState {
        var rows = Array(repeating: Array(repeating: Character("."), count: size), count: size)
        rows[1][size / 2] = "O"; rows[size - 2][size / 2] = "X"
        rows[3][3] = "H"; rows[2][2] = "o"; rows[2][3] = "o"; rows[3][2] = "x"; rows[4][2] = "x"
        rows[1][size / 2 + 1] = "Q"
        if review == .danger {
            let y = size - 2, x = size / 2
            rows[y - 1][x] = "o"; rows[y][x - 1] = "o"; rows[y][x + 1] = "o"
        }
        var config = RuleConfig.board(size: size); config.mageSkill = .seal
        return try! GameSetup.fromDiagram(config: config, diagram: rows.map { String($0) }.joined(separator: "\n"),
            classOne: .mage, classTwo: .rogue, manaOne: 4, manaTwo: 3, ap: 2)
    }
    func cancelSelection() { cancelFeedback(); selected = []; pushDirection = nil; message = "已取消預覽，沒有扣除資源。" }
    func chooseDirection(_ direction: PushDirection) {
        guard !isFeedbackPlaying else { return }
        if feedbackActive && sceneActive { traceEvent("selection", key: "selection"); audio.play("selection") }
        pushDirection = direction
        if let preview { message = preview.success ? "預覽不扣資源；確認後才生效。" : Self.reason(preview.reason) }
    }
    var availableDirections: Set<PushDirection> {
        guard let p = selected.first else { return [] }
        return Set(PushDirection.allCases.filter { GameEngine.validate(state, .castMagicHand(p, $0)) == .none })
    }
    func startPractice(_ lesson: PracticeLesson) {
        cancelFeedback(); feedbackStatus = "idle"
        size = 7; session = GameSession(lesson.initialState)
        playback = nil; selected = []; pushDirection = nil
        mode = lesson == .capture ? .soldier : .skill; message = lesson.instruction
    }
    func startCombatDemo(size: Int = 7) {
        cancelFeedback(); feedbackStatus = "idle"
        self.size = size; review = .normal
        session = GameSession(try! CombatDemo.initialState(size: size))
        selected = []; pushDirection = nil; mode = .skill
        message = "選 E4 的己方士兵，再選「上」並確認。"
    }
    static func reason(_ r: IllegalReason) -> String {
        switch r {
        case .skillNotSelected: "這個法師技能未啟用。"
        case .invalidDirection: "請選擇上、右、下或左。"
        case .none: "合法"
        case .gameOver: "對戰已結束。"
        case .noActionPoints: "本回合沒有行動次數。"
        case .outOfBounds: "目標在棋盤外。"
        case .occupied: "這裡已有棋子。"
        case .sealed: "這個點本回合被封印。"
        case .suicide: "行動後己方棋串會沒有生存空格。"
        case .ko: "不能重複先前的盤面。"
        case .notEnoughMana: "能量不足。"
        case .noHeroClass: "請先選擇職業。"
        case .heroAlreadyOnBoard: "英雄已在棋盤上。"
        case .heroAlreadySummoned: "英雄已退場，本局不能重召。"
        case .notAdjacentToFriend: "英雄必須召喚在己方棋子旁。"
        case .wrongClass: "這不是目前職業的技能。"
        case .noHeroOnBoard: "先召喚英雄才能使用技能。"
        case .skillAlreadyUsed: "本回合已使用技能。"
        case .outOfRange: "超出英雄的施放範圍。"
        case .invalidTarget: "請選擇符合技能條件的目標。"
        case .duplicateTarget: "築壘需要兩個不同的空點。"
        }
    }
}
