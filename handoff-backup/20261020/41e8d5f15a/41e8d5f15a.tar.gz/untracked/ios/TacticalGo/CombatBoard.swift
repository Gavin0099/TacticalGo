import SwiftUI
import TacticalGoCore

/// A0 presentation of an already committed receipt. No rules or resource decisions live here.
struct CombatBoard: View {
    let presentation: BoardPresentation
    let visuals: GameVisualAssets
    let playback: BoardPlayback?
    let reducedMotion: Bool
    let select: (Point) -> Void

    @State private var clockID: UUID?
    @State private var started = Date()
    @State private var finished = false

    private struct Push {
        let caster: Player
        let from: Point
        let to: Point
        let piece: Piece
    }
    private func push(in outcome: ActionOutcome) -> Push? {
        guard outcome.success else { return nil }
        for event in outcome.events {
            if case .piecePushed(let caster, let from, let to, let piece) = event {
                return Push(caster: caster, from: from, to: to, piece: piece)
            }
        }
        return nil
    }
    private var receipt: BoardPlayback? {
        guard let playback, playback.outcome.success,
              playback.outcome.state == presentation.state,
              case .castMagicHand = playback.action,
              push(in: playback.outcome) != nil else { return nil }
        return playback
    }
    private var animating: Bool { receipt.map { clockID != $0.id || !finished } ?? false }

    var body: some View {
        GeometryReader { geo in
            TimelineView(.animation(minimumInterval: 1 / 60, paused: !animating)) { context in
                let current = receipt
                let running = current != nil && animating
                // New receipts show their before board on the first frame, before .task starts.
                let elapsed = clockID == current?.id ? max(0, context.date.timeIntervalSince(started)) : 0
                layers(size: geo.size, receipt: running ? current : nil, elapsed: elapsed)
            }
            .contentShape(Rectangle())
            .gesture(SpatialTapGesture().onEnded { tap in
                guard geo.size.width > 0, geo.size.height > 0 else { return }
                if let point = BoardProjection(size: presentation.state.board.size).hit(
                    x: tap.location.x / geo.size.width, y: tap.location.y / geo.size.height) { select(point) }
            })
        }
        .task(id: playback?.id) {
            clockID = playback?.id; started = Date(); finished = false
            guard receipt != nil else { finished = true; return }
            do { try await Task.sleep(for: .seconds(1.55)) } catch { return }
            guard !Task.isCancelled else { return }
            finished = true
        }
    }

    @ViewBuilder private func layers(size: CGSize, receipt: BoardPlayback?, elapsed: Double) -> some View {
        let movement = receipt.flatMap { push(in: $0.outcome) }
        let previewPush = receipt == nil ? presentation.preview.flatMap { push(in: $0) } : nil
        let usingBefore = receipt != nil && elapsed < 0.56 && !reducedMotion
        let visibleBoard = usingBefore ? receipt!.before.board :
            (receipt == nil && presentation.preview?.success == true ? presentation.preview!.state.board : presentation.state.board)
        let captures = receipt?.outcome.events.flatMap { event -> [CapturedPiece] in
            if case .piecesCaptured(_, let pieces) = event { return pieces }; return []
        } ?? []
        let mage = movement.flatMap { receipt?.before.board.find($0.caster, .hero) }
        let radius = presentation.radius(Point(0, 0), size)
        ZStack {
            ground(size: size)
            ArenaGrid(boardSize: presentation.state.board.size).stroke(Color.ink.opacity(0.32), lineWidth: 1.2)
            ForEach(presentation.state.board.points, id: \.self) { point in
                let excluded = usingBefore && point == movement?.from
                ZStack {
                    if presentation.legal.contains(point) { Circle().fill(.white.opacity(0.28)).frame(width: radius * 0.5) }
                    if presentation.state.seals.contains(where: { $0.at == point }) {
                        Circle().stroke(.purple, lineWidth: 3).frame(width: radius * 1.8)
                    }
                    if !excluded, let piece = visibleBoard[point] {
                        token(piece, radius: radius)
                            .opacity(receipt == nil && presentation.preview?.success == true && piece != presentation.state.board[point] ? 0.68 : 1)
                    }
                    if receipt == nil, presentation.captures.contains(point), let old = presentation.state.board[point] {
                        token(old, radius: radius).opacity(0.3)
                    } else if receipt == nil, point == previewPush?.from, let old = presentation.state.board[point] {
                        token(old, radius: radius).opacity(0.3)
                    }
                }
                .position(presentation.center(point, size)).zIndex(Double(point.y) * 10 + 10)
            }
            if let movement, usingBefore {
                let progress = smooth((elapsed - 0.22) / 0.34)
                let from = presentation.center(movement.from, size), to = presentation.center(movement.to, size)
                token(movement.piece, radius: radius)
                    .position(x: from.x + (to.x - from.x) * progress, y: from.y + (to.y - from.y) * progress)
                    .zIndex(Double(movement.from.y) * 10 + Double(movement.to.y - movement.from.y) * 10 * progress + 11)
            }
            if receipt != nil, (reducedMotion || elapsed >= 0.56), elapsed < 0.90 {
                ForEach(captures, id: \.at) { captured in
                    let opacity = 1 - smooth((elapsed - 0.62) / 0.28)
                    token(captured.piece, radius: radius).opacity(opacity)
                        .scaleEffect(reducedMotion ? 1 : 1 - 0.15 * (1 - opacity))
                        .position(presentation.center(captured.at, size)).zIndex(Double(captured.at.y) * 10 + 12)
                }
            }
            coordinates(size: size)
            // Hint rings stay above every effect and never change their tactical meaning.
            if let previewPush {
                PushArrow(from: presentation.center(previewPush.from, size), to: presentation.center(previewPush.to, size), inset: radius * 0.85)
                    .stroke(Color.gold, style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round, dash: [4, 3]))
                    .zIndex(190)
                Circle().stroke(Color.gold.opacity(0.85), lineWidth: 2).frame(width: radius * 2.6)
                    .position(presentation.center(previewPush.to, size)).zIndex(190)
            }
            if let mage, elapsed < 0.40 {
                let phase = min(1, elapsed / 0.22)
                Ellipse().stroke(Color.cyan.opacity((1 - min(1, elapsed / 0.40)) * 0.85), lineWidth: 2)
                    .frame(width: radius * (reducedMotion ? 2.8 : 2.2 + phase * 0.6), height: radius * 1.8)
                    .position(presentation.center(mage, size)).zIndex(195)
                if !reducedMotion {
                    Circle().fill(Color.cyan.opacity(0.4 * sin(phase * .pi)))
                        .frame(width: radius * 0.6).offset(y: -radius * 1.35)
                        .position(presentation.center(mage, size)).zIndex(195)
                }
            }
            if let movement, elapsed >= 0.56, elapsed < 0.76 {
                let fade = 1 - (elapsed - 0.56) / 0.20
                Ellipse().stroke(Color.cyan.opacity(fade * 0.9), lineWidth: 2)
                    .frame(width: radius * (reducedMotion ? 2.7 : 2.2 + (1 - fade) * 0.5), height: radius * 1.7)
                    .position(presentation.center(movement.to, size)).zIndex(195)
            }
            if let receipt, elapsed >= 0.96, let winner = winner(in: receipt.outcome) {
                ArenaGround().stroke((winner == .one ? Color.blueTeam : Color.redTeam).opacity(max(0, 1 - (elapsed - 0.96) / 0.59)), lineWidth: 3)
                    .zIndex(195)
            }
            ForEach(presentation.state.board.points, id: \.self) { point in
                ZStack {
                    if presentation.danger.contains(point) || presentation.captures.contains(point) {
                        Circle().stroke(Color.redTeam, style: StrokeStyle(lineWidth: 3, dash: [3, 2])).frame(width: radius * 2.5)
                    }
                    if presentation.selected.contains(point) { Circle().stroke(Color.gold, lineWidth: 3).frame(width: radius * 2.7) }
                }.position(presentation.center(point, size)).zIndex(200)
            }
        }
    }

    private func token(_ piece: Piece, radius: CGFloat) -> some View {
        A0PieceToken(visuals: visuals, piece: piece, heroClass: presentation.state.heroClass(of: piece.owner), radius: radius)
    }
    private func smooth(_ value: Double) -> Double {
        let t = min(1, max(0, value)); return t * t * (3 - 2 * t)
    }
    private func winner(in outcome: ActionOutcome) -> Player? {
        for event in outcome.events { if case .gameWon(let player) = event { return player } }; return nil
    }
    @ViewBuilder private func ground(size: CGSize) -> some View {
        if let asset = visuals.pack.boardShadow {
            Image(uiImage: visuals.image(asset)).resizable().frame(width: size.width, height: size.height)
        } else { ArenaGround().fill(Color(red: 0.26, green: 0.13, blue: 0.08)).offset(y: 10) }
        if let asset = visuals.pack.boardSurface {
            Image(uiImage: visuals.image(asset)).resizable().frame(width: size.width, height: size.height)
        } else {
            ArenaGround().fill(LinearGradient(colors: [Color(red: 0.80, green: 0.61, blue: 0.35), Color(red: 0.60, green: 0.39, blue: 0.20)], startPoint: .top, endPoint: .bottom))
                .overlay(ArenaGround().stroke(Color.gold.opacity(0.65), lineWidth: 4))
            WoodGrain().stroke(Color(red: 0.3, green: 0.15, blue: 0.06).opacity(0.13), lineWidth: 1).clipShape(ArenaGround())
        }
    }
    private func coordinates(size: CGSize) -> some View {
        ForEach(0..<presentation.state.board.size, id: \.self) { n in
            let x = presentation.center(Point(n, presentation.state.board.size - 1), size)
            let y = presentation.center(Point(0, n), size)
            Text(String(UnicodeScalar(65 + n)!)).font(.system(size: 10, weight: .bold)).foregroundStyle(Color.ink).position(x: x.x, y: size.height * 0.885)
            Text(String(n + 1)).font(.system(size: 10, weight: .bold)).foregroundStyle(Color.ink).position(x: y.x - 16, y: y.y)
        }
    }
}

private struct PushArrow: Shape {
    let from: CGPoint
    let to: CGPoint
    let inset: CGFloat
    func path(in rect: CGRect) -> Path {
        let dx = to.x - from.x, dy = to.y - from.y, length = hypot(dx, dy)
        guard length > 0 else { return Path() }
        let ux = dx / length, uy = dy / length
        let trim = min(inset, length * 0.25)
        let start = CGPoint(x: from.x + ux * trim, y: from.y + uy * trim)
        let end = CGPoint(x: to.x - ux * trim, y: to.y - uy * trim)
        return Path { path in
            path.move(to: start); path.addLine(to: end)
            path.move(to: CGPoint(x: end.x - ux * 6 - uy * 4, y: end.y - uy * 6 + ux * 4))
            path.addLine(to: end)
            path.addLine(to: CGPoint(x: end.x - ux * 6 + uy * 4, y: end.y - uy * 6 - ux * 4))
        }
    }
}
