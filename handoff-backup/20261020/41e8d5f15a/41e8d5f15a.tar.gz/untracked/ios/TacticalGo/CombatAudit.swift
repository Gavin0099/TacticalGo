#if DEBUG
import Foundation
import TacticalGoCore
import TacticalGoMotion

/// Native regression harness: invokes the actual store while its scheduler is
/// running, without XCUI's automatic wait for animations to finish.
@MainActor enum CombatAudit {
    private struct Check: Codable {
        let name: String
        let passed: Bool
        let detail: String
    }
    private struct Report: Codable {
        let generatedAt: Double
        let status: String
        let checks: [Check]
    }

    static func runAudioPool() async -> String {
        let suiteName = "TacticalGo.AudioPoolAudit.\(UUID().uuidString)"
        guard let defaults = UserDefaults(suiteName: suiteName) else { return "FAIL" }
        let audio = CombatAudio(defaults: defaults)
        audio.muted = false; audio.musicVolume = 0; audio.sfxVolume = 0.35
        audio.setMatchActive(true); audio.setSceneActive(true)
        defer { audio.setMatchActive(false); defaults.removePersistentDomain(forName: suiteName) }
        let keys = ["selection", "mage", "place", "capture", "victory"]
        var played = false
        for _ in 0..<8 {
            for key in keys {
                audio.play(key)
                played = played || audio.activeEffectCount > 0
                try? await Task.sleep(for: .milliseconds(60))
            }
        }
        audio.cancelEffects()
        let stopped = audio.activeEffectCount == 0
        try? await Task.sleep(for: .milliseconds(300))
        let noRevival = audio.activeEffectCount == 0
        audio.play("victory")
        let restarted = audio.activeEffectCount > 0
        try? await Task.sleep(for: .milliseconds(2500))
        let checks = [
            Check(name: "native_player_started", passed: played && restarted && audio.lastError == nil,
                  detail: "Actual AVAudioPlayer voices started during 40 requests and after cancellation; no decode/session/play error."),
            Check(name: "cancel_stops_without_revival", passed: stopped && noRevival,
                  detail: "Cancellation stops native voices immediately and they remain stopped after 300ms."),
            Check(name: "completed_players_retained", passed: audio.cachedEffectCount == keys.count && audio.activeEffectCount == 0,
                  detail: "The five exercised cue players remain retained after completion; active voices finish within 2.5s.")
        ]
        let status = checks.allSatisfy(\.passed) ? "PASS" : "FAIL"
        do {
            let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            try encoder.encode(Report(generatedAt: Date().timeIntervalSince1970, status: status, checks: checks))
                .write(to: directory.appendingPathComponent("combat-audio-audit.json"), options: .atomic)
        } catch { return "FAIL" }
        return status
    }

    static func run() async -> String {
        let store = GameStore()
        let savedMute = store.audio.muted
        store.audio.muted = true
        defer { store.setMatchActive(false); store.audio.muted = savedMute }
        store.setSceneActive(true)
        store.setMatchActive(true)
        var checks: [Check] = []
        func record(_ name: String, _ passed: Bool, _ detail: String) {
            checks.append(Check(name: name, passed: passed, detail: detail))
        }
        func prepare() {
            store.startCombatDemo()
            store.select(Point(4, 3))
            store.chooseDirection(.up)
        }
        func pauseBeforeCancellation() async {
            try? await Task.sleep(for: .milliseconds(30))
        }
        func waitPastReceipt() async {
            // The committed demo ends at 1.55 seconds; this crosses that boundary.
            try? await Task.sleep(for: .milliseconds(1700))
        }

        prepare()
        let initial = try! CombatDemo.initialState()
        store.confirm()
        let committed = store.state
        record("confirmed_success", store.isFeedbackPlaying && store.playback != nil &&
               committed.apRemaining == 1 && committed.mana(of: .one) == 2 &&
               committed.board[Point(4, 2)] == Piece(.one, .soldier) &&
               committed.board.find(.two, .commander) == nil && committed.winner == .one &&
               committed.status == .won,
               "Fixture expects E4→E3, captured D3 commander, black victory, 1 AP and 2 Mana.")
        store.startPractice(.mage)
        store.select(Point(4, 3)); store.chooseDirection(.up); store.confirm()
        let rapidState = store.state, receiptID = store.playback?.id
        // Emulate a queued, otherwise legal action. These presentation inputs
        // intentionally bypass the view's disabled controls to exercise confirm.
        store.mode = .soldier; store.selected = [Point(0, 0)]
        let nextActionIsLegal = store.preview?.success == true
        store.confirm()
        record("rapid_confirm_ignored", nextActionIsLegal && store.state == rapidState &&
               store.playback?.id == receiptID && store.isFeedbackPlaying,
               "A queued soldier action is independently legal, but confirm during the Magic Hand receipt keeps all Domain state and the original receipt.")
        prepare(); store.confirm()
        await pauseBeforeCancellation()
        store.undo()
        record("undo_during_receipt", store.state == initial && !store.session.canUndo &&
               store.playback == nil && store.feedbackStatus == "cancelled",
               "Undo at 30 ms restores the full initial GameState and clears the active receipt.")
        await waitPastReceipt()
        record("undo_no_revival", store.state == initial && store.playback == nil && store.feedbackStatus == "cancelled",
               "After 1.7 seconds the cancelled scheduler must not publish settled or revive playback.")

        prepare(); store.confirm()
        await pauseBeforeCancellation()
        store.startCombatDemo()
        record("restart_during_receipt", store.state == initial && store.playback == nil && store.feedbackStatus == "idle",
               "Restart at 30 ms restores the fixture and returns presentation to idle.")
        await waitPastReceipt()
        record("restart_no_revival", store.state == initial && store.playback == nil && store.feedbackStatus == "idle",
               "The previous receipt cannot change presentation after restart.")

        prepare(); store.confirm()
        let beforeBackground = store.state
        await pauseBeforeCancellation()
        store.setSceneActive(false)
        store.setSceneActive(true)
        record("scene_cancel", store.state == beforeBackground && store.playback == nil && store.feedbackStatus == "cancelled",
               "Background cancels presentation; foreground keeps the already committed Domain result.")
        await waitPastReceipt()
        record("scene_no_revival", store.state == beforeBackground && store.playback == nil && store.feedbackStatus == "cancelled",
               "Foreground does not restart a stale receipt or delayed completion.")

        store.startCombatDemo()
        store.select(Point(0, 0)); store.chooseDirection(.up)
        let invalidPreview = store.preview
        store.confirm()
        record("invalid_no_success_feedback", invalidPreview?.success == false && store.state == initial &&
               !store.session.canUndo && store.playback == nil && !store.isFeedbackPlaying,
               "An invalid Magic Hand target cannot spend resources, add history, or create success playback.")

        let suiteName = "TacticalGo.CombatAudit.\(UUID().uuidString)"
        if let defaults = UserDefaults(suiteName: suiteName) {
            defer { defaults.removePersistentDomain(forName: suiteName) }
            let first = CombatAudio(defaults: defaults)
            first.muted = true; first.sfxVolume = 0.27; first.musicVolume = 0.18
            let second = CombatAudio(defaults: defaults)
            record("audio_settings_persistence", second.muted && second.sfxVolume == 0.27 && second.musicVolume == 0.18,
                   "A second audio instance reads mute and both independently chosen volume values from an isolated defaults suite.")
        } else {
            record("audio_settings_persistence", false, "Could not create the isolated UserDefaults suite.")
        }
        let status = checks.allSatisfy(\.passed) ? "PASS" : "FAIL"
        let report = Report(generatedAt: Date().timeIntervalSince1970, status: status, checks: checks)
        do {
            guard let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return "FAIL" }
            let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            try encoder.encode(report).write(to: directory.appendingPathComponent("combat-audit.json"), options: .atomic)
        } catch {
            print("COMBAT_AUDIT report failed: \(error)")
            return "FAIL"
        }
        print("COMBAT_AUDIT \(status) \(checks.count) checks")
        return status
    }
}
#endif
