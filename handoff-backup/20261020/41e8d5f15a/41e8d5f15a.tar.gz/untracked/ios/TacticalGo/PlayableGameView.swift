import SwiftUI
import TacticalGoCore

extension HeroClass {
    var title: String { switch self { case .warrior: "戰士"; case .mage: "法師"; case .rogue: "盜賊"; case .none: "無職業" } }
    var art: String { rawValue.lowercased() }
    var skillTitle: String { switch self { case .warrior: "築壘"; case .mage: "魔法之手"; case .rogue: "換位"; case .none: "技能" } }
    var skillHelp: String {
        switch self {
        case .warrior: "英雄相鄰的兩個空點，同時放士兵。"
        case .mage: "距離 2 內的任一士兵，推往相鄰空點。"
        case .rogue: "與相鄰敵方士兵交換位置。"
        case .none: "請先選擇職業。"
        }
    }
    var summonCost: Int { self == .mage ? 3 : 2 }
}
extension PushDirection {
    var title: String { switch self { case .up: "上"; case .right: "右"; case .down: "下"; case .left: "左"; case .invalid: "？" } }
    var symbol: String { switch self { case .up: "arrow.up"; case .right: "arrow.right"; case .down: "arrow.down"; case .left: "arrow.left"; case .invalid: "questionmark" } }
}

enum PracticeLesson: String, CaseIterable, Identifiable {
    case capture = "包圍與提子", warrior = "戰士築壘", mage = "法師魔法之手", rogue = "盜賊換位"
    var id: String { rawValue }
    var instruction: String {
        switch self {
        case .capture: "在 D4 落子，封住敵兵最後一氣，再按確認。"
        case .warrior: "選 C4 與 E4，預覽兩顆士兵，再按確認。"
        case .mage: "選 E4 的敵兵，再選「上」並確認。"
        case .rogue: "選 E4 的敵兵，預覽換位，再按確認。"
        }
    }
    var initialState: GameState {
        var rows = [".......", "...O...", ".......", "...H...", ".......", "...X...", "......."]
        let hero: HeroClass
        switch self {
        case .capture:
            rows = ["...O...", "...x...", "..xox..", ".......", ".......", "...X...", "......."]; hero = .warrior
        case .warrior: hero = .warrior
        case .mage: rows[3] = "...Ho.."; hero = .mage
        case .rogue: rows[3] = "...Ho.."; hero = .rogue
        }
        return try! GameSetup.fromDiagram(config: .board(size: 7), diagram: rows.joined(separator: "\n"),
            classOne: hero, classTwo: .warrior, manaOne: 6, manaTwo: 6, ap: 2)
    }
    func isComplete(_ state: GameState) -> Bool {
        switch self {
        case .capture: state.board[Point(3, 2)] == nil && state.board[Point(3, 3)] == Piece(.one, .soldier)
        case .warrior: state.board[Point(2, 3)] == Piece(.one, .soldier) && state.board[Point(4, 3)] == Piece(.one, .soldier)
        case .mage: state.board[Point(4, 3)] == nil && state.board[Point(4, 2)] == Piece(.two, .soldier)
        case .rogue: state.board[Point(4, 3)] == Piece(.one, .hero) && state.board[Point(3, 3)] == Piece(.two, .soldier)
        }
    }
}

/// A0 playable product entry. Original cards/tokens; no 3D resource loading.
struct PlayableGameView: View {
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var systemReducedMotion
    @State private var store = GameStore()
    @State private var visuals = GameVisualAssets.original
    @State private var visualFixture = false
    @State private var inMatch = false
    @State private var one: HeroClass = .warrior
    @State private var two: HeroClass = .mage
    @State private var choosing: Player = .one
    @State private var boardSize = 7
    @State private var lesson: PracticeLesson?
    @State private var showRules = false
    @State private var showGrid = false
    @State private var confirmExit = false
    @State private var showSoundSettings = false
    @State private var combatDemo = false
    @State private var forceReducedMotion = false
    #if DEBUG
    @State private var auditStatus: String?
    #endif
    private var reducedMotion: Bool { systemReducedMotion || forceReducedMotion }
    
    private let heroes: [HeroClass] = [.warrior, .mage, .rogue]
    private var side: String { store.state.current == .one ? "黑方" : "白方" }
    private var turnTitle: String { store.state.status == .ongoing ? "輪到" + side + hero.title : "對戰結束" }
    private var hero: HeroClass { store.state.heroClass(of: store.state.current) }
    private var complete: Bool { lesson?.isComplete(store.state) == true }
    private var showsResult: Bool { store.resultTitle != nil && !store.isFeedbackPlaying }
    private var showsPracticeComplete: Bool { complete && !store.isFeedbackPlaying }
    private var feedbackHero: HeroClass {
        guard store.isFeedbackPlaying, let receipt = store.playback,
              case .castMagicHand = receipt.action else { return hero }
        return receipt.before.heroClass(of: receipt.before.current)
    }
    private var feedbackHelp: String {
        guard store.isFeedbackPlaying, let receipt = store.playback,
              case .castMagicHand = receipt.action else { return modeHelp }
        return feedbackHero.skillHelp
    }
    var body: some View {
        GeometryReader { geo in
            Group { if inMatch { match(size: geo.size) } else { lobby } }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .background(LinearGradient(colors: [Color(red: 0.12, green: 0.18, blue: 0.21), Color(red: 0.20, green: 0.28, blue: 0.28)], startPoint: .top, endPoint: .bottom).ignoresSafeArea())
        .foregroundStyle(.white).preferredColorScheme(.dark)
        .overlay(alignment: .bottomLeading) {
            #if DEBUG
            if let auditStatus {
                Text(auditStatus).font(.caption).padding(4)
                    .accessibilityIdentifier("auditStatus")
            }
            #endif
        }
        .sheet(isPresented: $showRules) { rules }
        .sheet(isPresented: $showGrid) { accessibleGrid }
        .sheet(isPresented: $showSoundSettings) { CombatSoundSettings(audio: store.audio) }
        .confirmationDialog("離開目前對戰？", isPresented: $confirmExit, titleVisibility: .visible) {
            Button("返回選角", role: .destructive, action: leaveMatch)
        }
        .onChange(of: inMatch) { _, active in store.setMatchActive(active) }
        .onChange(of: scenePhase) { _, phase in store.setSceneActive(phase == .active) }
        .onChange(of: reducedMotion) { _, value in store.setReducedMotion(value) }
        .onDisappear { store.setMatchActive(false) }
        .onChange(of: store.state.current) { _, _ in
            UIAccessibility.post(notification: .announcement, argument: turnTitle)
        }
        .onAppear {
            #if DEBUG
            let args = ProcessInfo.processInfo.arguments
            if args.contains("--combat-audit"), auditStatus == nil {
                auditStatus = "RUNNING"
                Task { @MainActor in auditStatus = await CombatAudit.run() }
            }
            if args.contains("--combat-audio-audit"), auditStatus == nil {
                auditStatus = "RUNNING"
                Task { @MainActor in auditStatus = await CombatAudit.runAudioPool() }
            }
            forceReducedMotion = args.contains("--combat-reduced-motion")
            if args.contains("--visual-pack-fixture") || args.contains("--visual-pack-invalid-fixture") {
                visualFixture = true
                visuals = .connectionFixture(invalid: args.contains("--visual-pack-invalid-fixture"))
            }
            if let i = args.firstIndex(of: "--practice"), args.indices.contains(i + 1), let value = PracticeLesson.allCases.first(where: { $0.rawValue == args[i + 1] }) { startPractice(value) }
            if args.contains("--play-nine") { boardSize = 9; startMatch() }
            if args.contains("--play-win") { startMatch(); store.loadWinningTurn() }
            if args.contains("--play-draw") { startMatch(); store.loadLastTurn() }
            if args.contains("--combat-nine") { boardSize = 9 }
            if args.contains("--combat-demo") { store.enableCombatTrace(); startCombatDemo() }
            #endif
            store.setReducedMotion(reducedMotion)
            store.setSceneActive(scenePhase == .active)
            store.setMatchActive(inMatch)
        }
    }
    private var lobby: some View {
        ScrollView {
            VStack(spacing: 18) {
                VStack(spacing: 5) {
                    Text("TACTICAL GO").font(.system(size: 29, weight: .black, design: .rounded)).foregroundStyle(Color.gold)
                    Text("選擇英雄 · 包圍主將 · 一局決勝").font(.system(size: 14)).foregroundStyle(.white.opacity(0.75))
                }.padding(.top, 14)
                Picker("選擇哪一方", selection: $choosing) {
                    Text("黑方 ●").tag(Player.one); Text("白方 ○").tag(Player.two)
                }.pickerStyle(.segmented).accessibilityIdentifier("choosingTeam")
                HStack(spacing: 8) {
                    ForEach(heroes, id: \.self) { h in
                        let selected = (choosing == .one ? one : two) == h
                        Button {
                            if choosing == .one { one = h } else { two = h }; store.audio.play("selection")
                        } label: {
                            VStack(spacing: 7) {
                                Image(uiImage: visuals.portrait(h.art)).resizable().scaledToFit().frame(height: 125)
                                Text(h.title).font(.system(size: 17, weight: .bold))
                                Text(h.skillTitle).font(.system(size: 12, weight: .semibold)).lineLimit(1)
                            }.frame(maxWidth: .infinity).padding(.vertical, 12)
                                .background(selected ? Color.gold.opacity(0.19) : .white.opacity(0.05), in: RoundedRectangle(cornerRadius: 18))
                                .overlay(RoundedRectangle(cornerRadius: 18).stroke(selected ? Color.gold : .white.opacity(0.15), lineWidth: selected ? 2 : 1))
                        }.buttonStyle(.plain).accessibilityIdentifier("choose-" + h.art)
                            .accessibilityLabel(h.title + "，" + h.skillTitle).accessibilityAddTraits(selected ? [.isSelected] : [])
                    }
                }
                let choice = choosing == .one ? one : two
                VStack(spacing: 6) {
                    Text(choice.skillHelp).font(.system(size: 14))
                    Text("召喚 \(choice.summonCost) 能量 · 技能 1 AP＋2 能量 · 每回合一次").font(.system(size: 11)).foregroundStyle(Color.gold)
                }.frame(minHeight: 45)
                HStack {
                    Text("黑方 · \(one.title)").foregroundStyle(Color.gold)
                    Spacer(); Text("VS").font(.caption.bold()).foregroundStyle(.secondary); Spacer()
                    Text("白方 · \(two.title)").foregroundStyle(.white)
                }.font(.system(size: 14, weight: .bold)).accessibilityIdentifier("matchClasses")
                Picker("棋盤", selection: $boardSize) { Text("7 × 7").tag(7); Text("9 × 9").tag(9) }.pickerStyle(.segmented).accessibilityIdentifier("playBoardSize")
                Button(action: startMatch) { Label("開始本機雙人對戰", systemImage: "play.fill").frame(maxWidth: .infinity).frame(minHeight: 46) }
                    .buttonStyle(.borderedProminent).tint(Color.gold).foregroundStyle(Color.ink).font(.system(size: 16, weight: .bold)).accessibilityIdentifier("startMatch")
                Button(action: startCombatDemo) {
                    Label("魔法之手聲畫示範", systemImage: "sparkles").frame(maxWidth: .infinity, minHeight: 42)
                }.buttonStyle(.bordered).tint(Color.gold).accessibilityIdentifier("combatDemo")
                HStack {
                    Menu {
                        ForEach(PracticeLesson.allCases) { value in Button(value.rawValue) { startPractice(value) } }
                    } label: { Label("玩法練習", systemImage: "graduationcap") }
                    Spacer(); Button { showSoundSettings = true } label: { Image(systemName: "speaker.wave.2") }
                        .accessibilityLabel("聲音設定").accessibilityIdentifier("audioSettings")
                    Button("遊戲規則") { showRules = true }
                }.font(.system(size: 14)).frame(minHeight: 44)
                Text("兩人共用一台手機，黑方先手。\n首回合 1 AP，之後每回合 2 AP。")
                    .multilineTextAlignment(.center).font(.system(size: 12)).foregroundStyle(.white.opacity(0.55))
            }.padding(18).frame(maxWidth: 650)
        }
    }
    private func match(size: CGSize) -> some View {
        VStack(spacing: 6) {
            HStack {
                Button { confirmExit = true } label: { Image(systemName: "chevron.left").font(.system(size: 20, weight: .bold)).frame(width: 38, height: 36) }.accessibilityLabel("返回選角")
                VStack(alignment: .leading, spacing: 2) {
                    Text(turnTitle).font(.system(size: 22, weight: .heavy, design: .rounded))
                        .foregroundStyle(store.state.current == .one ? Color.gold : Color.white)
                        .accessibilityIdentifier("currentTurn")
                    Text(combatDemo ? "魔法之手聲畫示範" : (lesson?.rawValue ?? "第 \(store.state.ply) 回合 · 本機雙人"))
                        .font(.system(size: 11)).foregroundStyle(.white.opacity(0.65))
                }
                Spacer()
                Menu {
                    Button("復原", action: store.undo).disabled(!store.session.canUndo)
                    Button("格點清單") { showGrid = true }
                    Button("遊戲規則") { showRules = true }
                    Button("聲音設定") { showSoundSettings = true }.accessibilityIdentifier("audioSettings")
                    Button("重新開始") { if combatDemo { startCombatDemo() } else if let lesson { startPractice(lesson) } else { startMatch() } }
                } label: { Image(systemName: "ellipsis.circle").font(.system(size: 20)).frame(width: 38, height: 36) }.accessibilityLabel("對戰選單")
            }
            HStack(spacing: 8) {
                playerStrip(.one); playerStrip(.two)
            }
            if showsResult, let title = store.resultTitle {
                HStack { Image(systemName: "crown.fill"); Text(title).font(.system(size: 16, weight: .bold)); Spacer(); Button(combatDemo ? "重播示範" : "再玩一局") { if combatDemo { startCombatDemo() } else { startMatch() } } }
                    .padding(9).background(Color.gold.opacity(0.18), in: RoundedRectangle(cornerRadius: 10)).accessibilityIdentifier("matchResult")
            }
            if showsPracticeComplete {
                HStack { Image(systemName: "checkmark.circle.fill"); Text("練習完成").bold(); Spacer(); Button("回到選角", action: leaveMatch) }
                    .font(.system(size: 14)).padding(8).background(Color.green.opacity(0.25), in: RoundedRectangle(cornerRadius: 10)).accessibilityIdentifier("practiceComplete")
            }
            board.frame(height: min(size.width * 0.92, max(170, size.height - (!showsResult && !showsPracticeComplete ? 410 : 456))))
            Group {
                HStack(spacing: 9) {
                    CombatHeroPortrait(image: visuals.portrait(feedbackHero.art), playback: store.playback, reducedMotion: reducedMotion).frame(width: 48, height: 48)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(feedbackHero.title + " · " + feedbackHero.skillTitle).font(.system(size: 14, weight: .bold)).lineLimit(1)
                        Text(feedbackHelp).font(.system(size: 12)).foregroundStyle(.white.opacity(0.75)).fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer(minLength: 0)
                }.frame(minHeight: 50)
            }
            Text(store.isFeedbackPlaying ? "施法 → 士兵落定 → 提子 → 勝利" : complete ? "已完成目標；可以復原重試或回到選角。" : store.message)
                .font(.system(size: 12)).foregroundStyle(Color.gold).frame(maxWidth: .infinity, minHeight: 28, alignment: .leading)
                .accessibilityIdentifier("playMessage")
            #if DEBUG
            Text(store.feedbackStatus).font(.system(size: 1)).frame(height: 1)
                .accessibilityIdentifier("feedbackStatus")
                .accessibilityLabel(store.feedbackStatus).accessibilityValue(store.feedbackStatus)
            #endif
            if store.mode == .skill && hero == .mage && store.selected.first != nil {
                HStack(spacing: 6) {
                    ForEach(PushDirection.allCases, id: \.self) { direction in
                        Button { store.chooseDirection(direction) } label: {
                            Label(direction.title, systemImage: direction.symbol).frame(maxWidth: .infinity).frame(minHeight: 38)
                        }.buttonStyle(.bordered).tint(store.pushDirection == direction ? .gold : .white)
                            .disabled(store.isFeedbackPlaying || !store.availableDirections.contains(direction)).accessibilityIdentifier("push-" + direction.rawValue)
                    }
                }
            } else {
                HStack(spacing: 6) {
                    ForEach(GameStore.Mode.allCases, id: \.self) { mode in
                        Button { store.changeMode(mode) } label: {
                            Text(mode == .skill ? hero.skillTitle : mode.rawValue).font(.system(size: 13, weight: .bold)).frame(maxWidth: .infinity).frame(minHeight: 38)
                        }.buttonStyle(.bordered).tint(store.mode == mode ? .gold : .white)
                            .disabled(store.state.status != .ongoing).accessibilityIdentifier("mode-" + String(describing: mode))
                    }
                }
            }
            HStack(spacing: 8) {
                Button { if store.selected.isEmpty { store.undo() } else { store.cancelSelection() } } label: {
                    Text(store.selected.isEmpty ? "復原" : "取消").frame(minWidth: 48, minHeight: 40)
                }.buttonStyle(.bordered).disabled(store.selected.isEmpty && !store.session.canUndo).accessibilityIdentifier("undoOrCancel")
                Button(action: store.confirm) { Text("確認").bold().frame(maxWidth: .infinity, minHeight: 40) }
                    .buttonStyle(.borderedProminent).tint(Color.gold).foregroundStyle(Color.ink)
                    .disabled(store.isFeedbackPlaying || store.preview?.success != true).accessibilityIdentifier("playConfirm")
                Button(action: store.endTurn) { Text("結束回合").frame(minHeight: 40) }.buttonStyle(.bordered)
                    .disabled(store.isFeedbackPlaying || store.state.status != .ongoing || lesson != nil || combatDemo).accessibilityIdentifier("playEndTurn")
            }
        }.font(.system(size: 14)).padding(.horizontal, 12).padding(.vertical, 6).frame(maxWidth: 650)
    }
    private func playerStrip(_ player: Player) -> some View {
        let state = store.state, active = state.current == player
        let commander = state.board.find(player, .commander)
        let liberties = commander.map { state.board.liberties(at: $0).count } ?? 0
        return VStack(alignment: .leading, spacing: 3) {
            HStack(spacing: 4) {
                Text((player == .one ? "● 黑方 " : "○ 白方 ") + state.heroClass(of: player).title).fontWeight(.bold)
                Spacer(minLength: 0)
                Text(state.status == .ongoing ? (active ? "行動中" : "等待") : "已結束")
                    .font(.system(size: 10, weight: .bold)).foregroundStyle(active ? Color.gold : .white.opacity(0.5))
            }
            HStack(spacing: 4) {
                Text("能量 \(state.mana(of: player))/\(state.config.manaCap) · \(liberties) 氣")
                    .font(.system(size: 11)).foregroundStyle(liberties <= 1 ? Color.redTeam : .white.opacity(0.65))
                Spacer(minLength: 0)
                if active { Text("\(state.apRemaining) AP").font(.system(size: 11, weight: .bold)) }
            }
        }.font(.system(size: 12)).padding(8)
            .background(active ? Color.white.opacity(0.10) : .white.opacity(0.04), in: RoundedRectangle(cornerRadius: 10))
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(active ? Color.gold : .clear, lineWidth: 1))
            .accessibilityIdentifier(player == .one ? "blueResources" : "redResources")
    }
    private var board: some View {
        let data = BoardPresentation(state: store.state, selected: store.selected, legal: store.legalTargets, preview: store.preview)
        return ZStack(alignment: .topTrailing) {
            CombatBoard(presentation: data, visuals: visuals, playback: store.playback, reducedMotion: reducedMotion, select: store.select)
                .accessibilityElement(children: .ignore).accessibilityIdentifier("playArena")
                .accessibilityLabel("\(store.size)乘\(store.size)棋盤")
                .accessibilityValue(store.selected.map(coordinate).joined(separator: ","))
            if visualFixture {
                Text(visuals.diagnostic == nil ? "素材接線：" + visuals.pack.id : "素材拒絕，保留原圖")
                    .font(.system(size: 10)).padding(5).background(Color.ink)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading)
                    .accessibilityIdentifier("visualPackStatus").allowsHitTesting(false)
            }
            Button { showGrid = true } label: { Image(systemName: "square.grid.3x3").font(.system(size: 16)).padding(10) }
                .accessibilityLabel("以格點清單操作棋盤")
        }
    }
    private var modeHelp: String {
        if combatDemo { return "選 E4 己方士兵 → 上 → 確認，包圍 D3 主將。" }
        if let lesson { return lesson.instruction }
        switch store.mode {
        case .soldier: return "點空格放士兵 · 1 AP · 先預覽再確認"
        case .summon: return "選己方棋子旁的空點 · 1 AP＋\(hero.summonCost) 能量"
        case .skill: return hero.skillHelp + " 1 AP＋2 能量"
        }
    }
    private var accessibleGrid: some View {
        NavigationStack {
            List(store.state.board.points, id: \.self) { point in
                Button {
                    store.select(point); showGrid = false
                } label: {
                    HStack { Text(coordinate(point)); Text(cellDescription(point)); Spacer(); if store.legalTargets.contains(point) { Text("可選").foregroundStyle(.green) } }
                }.accessibilityIdentifier("cell-\(point.x)-\(point.y)")
            }.navigationTitle("選擇棋盤格點")
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { showGrid = false } } }
        }
    }
    private var rules: some View {
        NavigationStack {
            List {
                Section("勝利") { Text("包圍敵方主將所在的棋串，使它沒有相鄰空點（氣），提走主將即可獲勝。斜角不算相鄰。") }
                Section("回合與資源") { Text("首回合 1 AP，其後 2 AP。每次行動 1 AP；耗盡 AP 自動換手。每回合增加 1 能量，上限 6。也可提早結束回合。100 回合未分勝負則和局。") }
                Section("英雄") { Text("召喚在任一己方棋子相鄰空點。戰士與盜賊需 2 能量，法師需 3。英雄被提走後，本局不能再召喚。") }
                ForEach(heroes, id: \.self) { h in Section(h.title + " · " + h.skillTitle) { Text(h.skillHelp + "\n技能需 1 AP＋2 能量，每回合只能使用一次。") } }
                Section("合法行動") { Text("先處理敵方提子，再檢查己方是否無氣。禁止自殺與重複任何先前盤面。預覽不扣資源；復原會還原完整盤面、回合、資源與歷史。") }
            }.navigationTitle("遊戲規則").toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { showRules = false } } }
        }
    }
    private func coordinate(_ p: Point) -> String { String(UnicodeScalar(65 + p.x)!) + String(p.y + 1) }
    private func cellDescription(_ p: Point) -> String {
        guard let piece = store.state.board[p] else { return "空點" }
        return (piece.owner == .one ? "黑方 " : "白方 ") + (piece.kind == .hero ? store.state.heroClass(of: piece.owner).title : piece.kind == .commander ? "主將" : "士兵")
    }
    private func startMatch() {
        store.size = boardSize; store.newMatch(classOne: one, classTwo: two)
        lesson = nil; combatDemo = false; inMatch = true; store.setMatchActive(true)
    }
    private func startPractice(_ value: PracticeLesson) { lesson = value; combatDemo = false; store.startPractice(value); inMatch = true; store.setMatchActive(true) }
    private func startCombatDemo() { lesson = nil; combatDemo = true; store.startCombatDemo(size: boardSize); inMatch = true; store.setMatchActive(true) }
    private func leaveMatch() { store.setMatchActive(false); inMatch = false; lesson = nil; combatDemo = false }
}

private struct CombatSoundSettings: View {
    @Bindable var audio: CombatAudio
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            Form {
                Toggle("靜音", isOn: $audio.muted).accessibilityIdentifier("audioMute")
                Section("音效音量") {
                    Slider(value: $audio.sfxVolume, in: 0...1).accessibilityIdentifier("sfxVolume")
                    Text("\(Int(audio.sfxVolume * 100))%")
                }
                Section("音樂音量") {
                    Slider(value: $audio.musicVolume, in: 0...1).accessibilityIdentifier("musicVolume")
                    Text("\(Int(audio.musicVolume * 100))%")
                }
                Section {
                    Text("聲音設定會保留。系統開啟「減少動態效果」時，使用靜態光環與結果提示。")
                }
            }.navigationTitle("聲音設定")
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() }.accessibilityIdentifier("audioSettingsDone") } }
        }
    }
}


/// A brief card cue follows the same receipt as the board, with no rule authority.
private struct CombatHeroPortrait: View {
    let image: UIImage
    let playback: BoardPlayback?
    let reducedMotion: Bool
    @State private var started = Date()
    private var isCasting: Bool {
        guard let playback else { return false }
        if case .castMagicHand = playback.action { return true }
        return false
    }
    var body: some View {
        TimelineView(.animation(minimumInterval: 1 / 30, paused: !isCasting)) { context in
            let elapsed = context.date.timeIntervalSince(started)
            let glow = isCasting && elapsed < 0.22
            Image(uiImage: image).resizable().scaledToFit()
                .background(Circle().fill(Color.cyan.opacity(glow ? 0.18 : 0)))
                .shadow(color: .cyan.opacity(glow ? 0.8 : 0), radius: reducedMotion ? 3 : 8)
        }
        .onChange(of: playback?.id) { _, _ in started = Date() }
    }
}
