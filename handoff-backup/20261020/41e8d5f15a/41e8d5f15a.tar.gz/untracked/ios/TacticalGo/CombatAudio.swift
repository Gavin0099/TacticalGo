import AVFoundation
import Foundation
import Observation

/// Presentation only. The store decides whether a Domain event succeeded and when each cue fires.
@MainActor @Observable final class CombatAudio {
    var muted: Bool {
        didSet { defaults.set(muted, forKey: "combatAudio.muted"); if muted { cancelEffects() }; reconcileMusic() }
    }
    var sfxVolume: Double {
        didSet {
            let value = Self.clamp(sfxVolume)
            if value != sfxVolume { sfxVolume = value }
            defaults.set(value, forKey: "combatAudio.sfxVolume")
            effects.values.forEach { $0.volume = Float(value) }
            if value == 0 { cancelEffects() }
        }
    }
    var musicVolume: Double {
        didSet {
            let value = Self.clamp(musicVolume)
            if value != musicVolume { musicVolume = value }
            defaults.set(value, forKey: "combatAudio.musicVolume")
            reconcileMusic()
        }
    }
    private(set) var lastError: String?
    /// Allows the presentation owner to invalidate delayed cues as soon as system audio is interrupted.
    @ObservationIgnored var onInterruption: (() -> Void)?

    @ObservationIgnored private let defaults: UserDefaults
    @ObservationIgnored private let bundle: Bundle
    @ObservationIgnored private var matchActive = false
    @ObservationIgnored private var sceneActive = false
    @ObservationIgnored private var interrupted = false
    @ObservationIgnored private var sessionActive = false
    @ObservationIgnored private var music: AVAudioPlayer?
    // Keep cue players alive for this audio owner's lifetime. isPlaying can
    // become false before AVFoundation delivers its queued finishedPlaying
    // callback; dropping that player at the next cue caused a native crash.
    @ObservationIgnored private var effects: [String: AVAudioPlayer] = [:]
    @ObservationIgnored private var lastSelectionTime = -Double.infinity
    @ObservationIgnored nonisolated(unsafe) private var interruptionObserver: (any NSObjectProtocol)?
    private static let effectKeys: Set<String> = ["selection", "place", "capture", "summon", "mage", "warrior", "rogue", "danger", "victory", "defeat", "draw"]

    init(defaults: UserDefaults = .standard, bundle: Bundle = .main) {
        self.defaults = defaults
        self.bundle = bundle
        muted = defaults.bool(forKey: "combatAudio.muted")
        sfxVolume = Self.clamp(defaults.object(forKey: "combatAudio.sfxVolume") as? Double ?? 0.65)
        musicVolume = Self.clamp(defaults.object(forKey: "combatAudio.musicVolume") as? Double ?? 0.30)
        interruptionObserver = NotificationCenter.default.addObserver(
            forName: AVAudioSession.interruptionNotification, object: nil, queue: .main
        ) { [weak self] notification in
            guard let typeRaw = notification.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
                  let type = AVAudioSession.InterruptionType(rawValue: typeRaw) else { return }
            let began = type == .began
            let rawOptions = notification.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0
            let mayResume = AVAudioSession.InterruptionOptions(rawValue: rawOptions).contains(.shouldResume)
            Task { @MainActor [weak self] in
                guard let self else { return }
                self.interrupted = began || !mayResume
                if began {
                    self.cancelEffects()
                    self.sessionActive = false
                    self.onInterruption?()
                }
                self.reconcileMusic()
            }
        }
    }

    deinit {
        if let interruptionObserver { NotificationCenter.default.removeObserver(interruptionObserver) }
    }

    func setMatchActive(_ active: Bool) {
        matchActive = active
        if !active {
            cancelEffects()
            music?.stop()
            music?.currentTime = 0
        }
        reconcileMusic()
    }

    func setSceneActive(_ active: Bool) {
        let returningToForeground = active && !sceneActive
        sceneActive = active
        if returningToForeground { interrupted = false }
        if !active { cancelEffects() }
        reconcileMusic()
    }

    /// This starts one cue immediately; no timers, game rules or outcome inference live here.
    func play(_ key: String) {
        guard Self.effectKeys.contains(key), matchActive, sceneActive, !interrupted, !muted, sfxVolume > 0 else { return }
        if key == "selection" {
            let now = ProcessInfo.processInfo.systemUptime
            guard now - lastSelectionTime >= 0.08 else { return }
            lastSelectionTime = now
        }
        guard activateSession() else { return }
        if effects[key] == nil { effects[key] = makePlayer(key) }
        guard let player = effects[key] else { return }
        // Reuse one retained voice per cue. Repeated cues restart rather than
        // accumulating old voices; the cache is bounded by the known 11 keys.
        if effects.values.filter({ $0.isPlaying }).count >= 8,
           let other = effects.first(where: { $0.key != key && $0.value.isPlaying })?.value { other.stop() }
        player.stop(); player.currentTime = 0
        player.volume = Float(sfxVolume)
        if !player.play() { lastError = "音效無法播放：\(key)" }
    }

    func cancelEffects() {
        effects.values.forEach { $0.stop() }
        lastSelectionTime = -Double.infinity
    }

    #if DEBUG
    var cachedEffectCount: Int { effects.count }
    var activeEffectCount: Int { effects.values.filter { $0.isPlaying }.count }
    #endif

    private func reconcileMusic() {
        guard matchActive, sceneActive, !interrupted, !muted, musicVolume > 0 else {
            music?.pause()
            if !sceneActive || !matchActive || muted {
                if sessionActive {
                    try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
                    sessionActive = false
                }
            }
            return
        }
        guard activateSession() else { return }
        if music == nil {
            music = makePlayer("tabletop-loop")
            music?.numberOfLoops = -1
        }
        music?.volume = Float(musicVolume)
        if let music, !music.isPlaying, !music.play() { lastError = "背景音樂無法播放。" }
    }

    private func activateSession() -> Bool {
        if sessionActive { return true }
        do {
            // Ambient respects the iPhone silent switch and mixes with the owner's existing audio.
            try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            sessionActive = true
            return true
        } catch {
            lastError = "音訊工作階段啟動失敗：\(error.localizedDescription)"
            return false
        }
    }

    private func makePlayer(_ name: String) -> AVAudioPlayer? {
        guard let url = bundle.url(forResource: name, withExtension: "wav", subdirectory: "Audio")
            ?? bundle.url(forResource: name, withExtension: "wav") else {
            lastError = "找不到音訊素材：\(name).wav"
            return nil
        }
        do {
            let player = try AVAudioPlayer(contentsOf: url)
            player.prepareToPlay()
            return player
        } catch {
            lastError = "無法讀取音訊素材 \(name)：\(error.localizedDescription)"
            return nil
        }
    }

    private static func clamp(_ value: Double) -> Double { value.isFinite ? min(1, max(0, value)) : 0 }
}
