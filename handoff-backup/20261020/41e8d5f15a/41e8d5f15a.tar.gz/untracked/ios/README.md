# TacticalGo iOS A0 可玩候選

Owner 2026-10-09 已玩過 Windows，要求直接做 iOS。正常啟動為 SwiftUI 選角／新對戰；不載入或展示未通過 Identity Gate 的 3D 人物。

- 雙方獨立選戰士、法師、盜賊，7×7／9×9 本機輪流對戰。
- 原始 B-v02 PNG 用於選角與人物資訊；原始 A Token 用於木質 2.5D 棋盤。三張 B 卡與三張 A Token 保持來源檔位元一致。
- 士兵落子、鄰接任一友軍召喚英雄、戰士築壘、法師魔法之手（可推任一方士兵）、盜賊換位。
- 預覽呈現操作後盤面與將被提走的棋子；確認才扣 AP／能量。魔法之手先選士兵，再選方向。
- 取消、完整復原、提早結束回合、自動換手、主將氣數、勝利／100 回合和局、重開。
- 棋盤上方常駐「輪到黑方／白方＋職業」，資訊卡明示行動中／等待；預覽不換人，確認、自動換手、結束回合與復原才依實際狀態更新。
- 雙方統一稱黑方／白方，與士兵色一致；主將與英雄用黑白底座及黑／白字牌識別，雙方同職也不依賴角色圖的顏色。
- 小螢幕棋盤高度保留操作區；棋盤 HUD 採固定可讀字級避免系統超大字溢出，規則與格點清單維持可滾動的系統字級。
- 四個可操作練習：提子、築壘、魔法之手、換位。練習完成以實際規則狀態判斷；可復原重試。
- 棋盤右上格點清單提供可讀座標與棋子名稱，支援 VoiceOver／小尺寸精確選格；真機 VoiceOver 人工操作仍待檢查。

`TacticalGoCore` 是不依賴 SwiftUI／UIKit 的純 Swift Package。Magic Hand 的移植基準為 Windows `codex/gameplay-g1-g4` @ `54deef97e0fb7157b0025a7282fc2c0a448d4fb9`，不是本機 main 的舊版 Seal 引擎。沒有合併、更改 C# production Domain 或宣稱 Windows main 已同步。

## 開啟與驗證

在 Xcode 開啟 `ios/TacticalGo.xcodeproj`，scheme `TacticalGo`，選 iPhone Simulator 或已配對 iPhone。部署最低 iOS 17，直向 iPhone。

```sh
swift test --package-path swift/TacticalGoCore
# SDK 9 required; use installed dotnet or point to an existing isolated SDK.
TACTICALGO_DOTNET=/tmp/tacticalgo-dotnet/dotnet python3 scripts/verify-ios-parity.py
# Historical main Seal fixtures remain unchanged and use the explicit baseline:
swift run --package-path swift/TacticalGoCore tacticalgo-golden tests/golden /tmp/legacy-swift.json --legacy-seal
xcodebuild -project ios/TacticalGo.xcodeproj -scheme TacticalGo \
  -destination 'platform=iOS Simulator,name=iPhone 17' CODE_SIGNING_ALLOWED=NO \
  -only-testing:TacticalGoUITests/PlayableGameTests test
```

基準 exporter 只在暫存目錄讀取指定 Git revision 的 C# source；先逐檔檢查 fixtures 與該 revision 相同，再比較完整状态、錯誤與有序事件 payload。測試預期來自既有手寫 Golden，不由 C# output 自動產生。等價測試不能證明原玩法設計正確或平衡。

本輪可检查交付、截圖、Xcode result bundles、真機安裝與驗證邊界見 `artifacts/ios/playable-a0-v01/REPORT.md`。

## 保留的研究入口

舊 RealityKit／SpriteKit／SwiftUI 比較及 3D 模型回放只在 Debug 加 `--review-controls` 時進入。相關幾何、模型、原畫與歷史驗證保留研究用途；本輪不新增 Mesh、骨架、全身、拆層 Sprite 或角色動畫。Release 不提供該入口。

新流程的 Debug 測試入口：`--practice <包圍與提子|戰士築壘|法師魔法之手|盜賊換位>`、`--play-nine`、`--play-win`、`--play-draw`。正常對戰從規則初始狀態開始；Debug 勝負位置不能替代完整對戰驗證。

尚未提供網路多人、AI 對手、背景存局／恢復。AUDIO-01／COMBAT-FEEL-01 已另提供音樂、音效與魔法之手聲畫候選，見下方；完整技能演出與正式動畫仍待驗收。本輪是本機可玩候選；沒有 App Store／TestFlight 發布，也不將候選素材升格為正式發布素材。

## V2素材接線

素材規格見 `../docs/ios/V2_ASSET_CONTRACT.md`，原A0六張圖片metadata見 `../docs/ios/visual-pack-original-a0.json`。正常App仍選原圖；候選檔案不会自動載入或視為Owner核准。Debug `--visual-pack-fixture`只重用原圖，`--visual-pack-invalid-fixture`驗證整包拒絕與fallback。独立 `TacticalGoVisuals`不依賴Apple或規則核心，metadata pass/fail測試随Swift Package執行。

## AUDIO-01 / COMBAT-FEEL-01：魔法之手聲畫候選

此版本保存在獨立 `codex/audio-combat-magic-hand` 工作樹；不是原主工作目錄已合併的版本。啟動後點「魔法之手聲畫示範」，選 E4 己方士兵 → 上 → 確認。既有 Domain 把士兵推到 E3、提走 D3 敵主將，正式結果為黑方勝利、1 AP、2 能量；聲畫依成功事件播放，復原可完整重試。

候選包含 21.333 秒原創程序合成 BGM、11 個短音效、法師光環／一格滑動／落定／提子／勝利演出、原生聲音設定及 Reduce Motion 替代。音樂只在 active 對局播放；背景、離場、復原與重开都取消過期效果。其他技能目前只有基本声音候選，没有擴展完整角色演出。

Debug：`--combat-demo`、`--combat-nine`、`--combat-reduced-motion`；`--combat-audit` 直接執行播放中取消與資源回歸，輸出 `Documents/combat-audit.json`；`--combat-audio-audit` 執行實際 AVAudioPlayer 連播／取消／重播，輸出 `Documents/combat-audio-audit.json`。正常對戰不使用示範盤面。來源／生成方式在 `Audio/manifest.json`，正式發布權利與真機聽感尚待驗收。

```sh
python3 scripts/generate-combat-audio.py --check
swift test --package-path swift/TacticalGoCore
```

演出時間表：`../docs/ios/COMBAT_FEEL_01_TIMING.md`；音訊規格：`../docs/ios/AUDIO_01_SPEC.md`；完整驗證與 25 秒展示：`../artifacts/ios/audio-combat-magic-hand/REPORT.md`。
