#!/usr/bin/env python3
"""Run fresh actual native hero import/pose/restoration checks on a named simulator."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--device', required=True)
parser.add_argument('--resources', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--app', type=Path, default=Path('ios/Build/Products/Debug-iphonesimulator/TacticalGo.app'))
args = parser.parse_args()
if args.output.exists() and any(args.output.iterdir()): raise SystemExit('Use a new directory; preserve previous attempts')
args.output.mkdir(parents=True, exist_ok=True)
bundle = 'com.tacticalgo.prototype'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs = lambda app: {'librarySHA256': sha(app / 'TacticalGo.debug.dylib'),
                     'modelSHA256': {p.name: sha(p) for p in (app / 'Models').glob('*.usdz')}}
original = inputs(args.app)
for hero in ['warrior', 'mage', 'rogue']:
    if sha(args.resources / (hero + '-rig.usdz')) != original['modelSHA256'].get(hero + '.usdz'):
        raise SystemExit('Requested hero resource must equal the bundled candidate for gameplay restoration checks')
subprocess.run(['xcrun', 'simctl', 'terminate', args.device, bundle], capture_output=True)
subprocess.run(['xcrun', 'simctl', 'install', args.device, str(args.app)], check=True)
container = Path(subprocess.check_output(['xcrun', 'simctl', 'get_app_container', args.device, bundle, 'data'], text=True).strip())
installed = Path(subprocess.check_output(['xcrun', 'simctl', 'get_app_container', args.device, bundle, 'app'], text=True).strip())
if inputs(installed) != original: raise SystemExit('Installed app differs from requested build')
documents = container / 'Documents'
for hero in ['warrior', 'mage', 'rogue']:
    p = args.resources / (hero + '-rig.usdz'); shutil.copy2(p, documents / p.name)
names = ['rig-import-verification.json', 'leg-pose-verification.json', 'cape-pose-verification.json',
         'socket-verification.json', 'playback-restoration-verification.json']
for name in names:
    p = documents / name
    if p.exists():
        prior = args.output / 'prior'; prior.mkdir(exist_ok=True)
        shutil.copy2(p, prior / name); p.unlink()
flags = ['--verify-rigs', '--verify-leg-poses', '--verify-cape-poses', '--verify-sockets', '--verify-playback-restoration']
started = time.time()
launch = subprocess.check_output(['xcrun', 'simctl', 'launch', args.device, bundle, *flags], text=True)
pid = int(launch.rsplit(':', 1)[1])
receipt = {'startedAtUnix': started, 'pid': pid, 'device': args.device, 'launchArguments': flags,
           'inputs': original, 'documentsResources': {h: sha(documents / (h + '-rig.usdz')) for h in ['warrior', 'mage', 'rogue']}}
(args.output / 'launch-inputs.json').write_text(json.dumps(receipt, indent=2) + '\n')
try:
    for _ in range(100):
        processes = subprocess.check_output(['xcrun', 'simctl', 'spawn', args.device, 'launchctl', 'list'], text=True)
        if not any(line.split() and line.split()[0] == str(pid) for line in processes.splitlines()):
            raise SystemExit('Native process exited; incomplete attempt retained')
        if all((documents / n).exists() and (documents / n).stat().st_mtime > started for n in names): break
        time.sleep(1)
    else: raise SystemExit('Fresh native outputs missing; retain incomplete attempt')
    rows = []
    for name in names:
        data = json.loads((documents / name).read_text())
        passed = all(r.get('passed', r.get('restored', False)) for r in data['results'])
        if name == 'socket-verification.json': passed = passed and data.get('unknownJointRejected', False)
        rows.append({'file': name, 'cases': len(data['results']), 'passed': passed})
    if inputs(installed) != original or inputs(args.app) != original:
        raise SystemExit('Build changed during native QA; no completion claim')
    if not all(r['passed'] for r in rows): raise SystemExit('Native candidate failed; raw outputs retained')
    (args.output / 'verification-summary.json').write_text(json.dumps({'results': rows,
        'claim': 'actual native imports/pose sockets/restoration; no rendered-pixel, final art or physical-device claim'}, indent=2) + '\n')
    print(json.dumps(rows, indent=2))
finally:
    for name in names:
        if (documents / name).exists(): shutil.copy2(documents / name, args.output / name)
