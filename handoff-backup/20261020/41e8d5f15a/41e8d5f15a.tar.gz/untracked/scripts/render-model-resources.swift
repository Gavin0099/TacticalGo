import AppKit
import SceneKit
import Metal

// Independent native preview of exported USDZ candidates; not an iPhone performance test.
guard (3...4).contains(CommandLine.arguments.count), let device = MTLCreateSystemDefaultDevice() else {
    fatalError("Usage: swift render-model-resources.swift <usdz folder> <preview folder> [--portraits|--tokens]; Metal required")
}
let portraits = CommandLine.arguments.dropFirst(3).contains("--portraits")
let tokens = CommandLine.arguments.dropFirst(3).contains("--tokens")
let source = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
let output = URL(fileURLWithPath: CommandLine.arguments[2], isDirectory: true)
try FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
for hero in ["warrior", "mage", "rogue"] {
    let scene = try SCNScene(url: source.appendingPathComponent(hero + ".usdz"), options: nil)
    scene.background.contents = portraits || tokens ? NSColor.clear : NSColor(calibratedRed: 0.075, green: 0.17, blue: 0.21, alpha: 1)
    let camera = SCNNode()
    camera.camera = SCNCamera()
    camera.camera!.fieldOfView = 34
    camera.position = SCNVector3(1.12, 1.8, 3.63)
    camera.look(at: SCNVector3(0, 0.8, 0))
    if portraits {
        camera.camera!.usesOrthographicProjection = true
        camera.camera!.orthographicScale = hero == "mage" ? 0.67 : 0.56
        camera.position = SCNVector3(0.80, 1.45, 3.63)
        camera.look(at: SCNVector3(0, hero == "mage" ? 1.03 : 0.91, 0))
    }
    if tokens {
        camera.camera!.usesOrthographicProjection = true
        camera.camera!.orthographicScale = 0.82
        camera.position = SCNVector3(0.40, 4.10, 1.86)
        camera.look(at: SCNVector3(0, 0.60, 0))
    }
    scene.rootNode.addChildNode(camera)
    let key = SCNNode()
    key.light = SCNLight()
    key.light!.type = .directional
    key.light!.intensity = 1400
    key.light!.color = NSColor(calibratedRed: 1, green: 0.91, blue: 0.78, alpha: 1)
    key.position = SCNVector3(-5, 9, 6)
    key.look(at: SCNVector3Zero)
    scene.rootNode.addChildNode(key)
    let ambient = SCNNode()
    ambient.light = SCNLight()
    ambient.light!.type = .ambient
    ambient.light!.intensity = 600
    ambient.light!.color = NSColor(calibratedRed: 0.65, green: 0.8, blue: 1, alpha: 1)
    scene.rootNode.addChildNode(ambient)
    let renderer = SCNRenderer(device: device, options: nil)
    renderer.scene = scene
    renderer.pointOfView = camera
    let sizes = tokens ? [CGSize(width: 32, height: 32), CGSize(width: 48, height: 48), CGSize(width: 64, height: 64)]
        : [portraits ? CGSize(width: 384, height: 384) : CGSize(width: 900, height: 1000)]
    for size in sizes {
        let snapshot = renderer.snapshot(atTime: 0, with: size, antialiasingMode: .multisampling4X)
        guard let tiff = snapshot.tiffRepresentation, let bitmap = NSBitmapImageRep(data: tiff),
              let png = bitmap.representation(using: .png, properties: [:]) else { fatalError("No rendered image") }
        let suffix = tokens ? "-token-\(Int(size.width)).png" : portraits ? "-portrait.png" : "-export-preview.png"
        try png.write(to: output.appendingPathComponent(hero + suffix))
    }
    print(hero, "native USDZ preview written")
}
