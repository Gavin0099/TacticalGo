#!/usr/bin/env python3
"""Original TacticalGo audio candidates. Python standard library only.

Run from any directory; --check recomposes and compares without writing.
All synthesis, harmony and note events are authored here: no samples/downloads.
"""
from array import array
import argparse
import hashlib
import io
import json
import math
from pathlib import Path
import random
import struct
import wave

RATE = 44100
BEAT_FRAMES = 29400  # Exact 90 BPM at 44.1 kHz, 32 beats = 21 1/3 seconds.
BEAT = BEAT_FRAMES / RATE
ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "ios/TacticalGo/Audio"
TAU = 2 * math.pi


def frequency(midi):
    return 440 * 2 ** ((midi - 69) / 12)


class Mix:
    def __init__(self, seconds=None, frames=None, loop=False):
        self.frames = frames or round(seconds * RATE)
        self.left = array("d", [0]) * self.frames
        self.right = array("d", [0]) * self.frames
        self.loop = loop

    def tone(self, start, duration, midi, gain, voice="pluck", pan=0):
        offset, length = round(start * RATE), round(duration * RATE)
        f = frequency(midi)
        left, right = math.sqrt((1 - pan) / 2), math.sqrt((1 + pan) / 2)
        for n in range(length):
            t = n / RATE
            phase = TAU * f * t
            if voice == "pad":
                envelope = min(t / .20, 1) * min((duration - t) / .55, 1)
                value = (math.sin(phase) + .20 * math.sin(phase * 2 + .025 * math.sin(TAU * 2 * t))
                         + .08 * math.sin(phase * 3)) * envelope * .70
            elif voice == "bell":
                envelope = min(t / .006, 1) * math.exp(-t * 4.4) * min((duration - t) / .04, 1)
                value = (math.sin(phase) + .28 * math.sin(phase * 2.01) * math.exp(-t * 8)
                         + .08 * math.sin(phase * 3)) * envelope
            else:
                envelope = min(t / .004, 1) * math.exp(-t * (5.5 if voice == "wood" else 3.5))
                envelope *= min((duration - t) / .035, 1)
                value = (math.sin(phase) + .23 * math.sin(phase * 2) * math.exp(-t * 6)
                         + .09 * math.sin(phase * 3) * math.exp(-t * 9)) * envelope
            index = offset + n
            if self.loop:
                index %= self.frames
            elif index >= self.frames:
                break
            if index >= 0:
                self.left[index] += value * gain * left
                self.right[index] += value * gain * right

    def sweep(self, start, duration, low, high, gain, seed=0, noisy=False):
        rng = random.Random(seed)
        offset, length = round(start * RATE), round(duration * RATE)
        phase, smooth_noise = 0., 0.
        for n in range(length):
            progress = n / length
            phase += TAU * (low * (high / low) ** progress) / RATE
            envelope = math.sin(math.pi * progress) ** 1.4
            smooth_noise = .82 * smooth_noise + .18 * rng.uniform(-1, 1)
            value = (smooth_noise if noisy else math.sin(phase)) * gain * envelope
            index = offset + n
            if index < self.frames:
                self.left[index] += value * .707
                self.right[index] += value * .707

    def echo(self, delay=.13, gain=.12):
        # Wrapped reflections make the BGM tail continue naturally into bar 1.
        offset = round(delay * RATE)
        old_left, old_right = self.left[:], self.right[:]
        for n in range(self.frames):
            source = n - offset
            if self.loop:
                source %= self.frames
            if source >= 0:
                self.left[n] += old_right[source] * gain
                self.right[n] += old_left[source] * gain

    def wav(self, peak):
        dc_left = sum(self.left) / self.frames
        dc_right = sum(self.right) / self.frames
        maximum = max(max(abs(x - dc_left) for x in self.left),
                      max(abs(x - dc_right) for x in self.right))
        scale = peak / maximum
        pcm = bytearray(self.frames * 4)
        square_sum = 0.
        first, last = [], []
        for n, (l, r) in enumerate(zip(self.left, self.right)):
            values = ((l - dc_left) * scale, (r - dc_right) * scale)
            if not self.loop:
                fade = min(n / (RATE * .003), 1., (self.frames - 1 - n) / (RATE * .02))
                values = tuple(v * fade for v in values)
            integers = [round(max(-1, min(1, v)) * 32767) for v in values]
            struct.pack_into("<hh", pcm, n * 4, *integers)
            square_sum += sum((v / 32767) ** 2 for v in integers)
            if n == 0:
                first = integers
            if n == self.frames - 1:
                last = integers
        buffer = io.BytesIO()
        with wave.open(buffer, "wb") as out:
            out.setnchannels(2)
            out.setsampwidth(2)
            out.setframerate(RATE)
            out.writeframes(pcm)
        return buffer.getvalue(), {
            "frames": self.frames, "duration_seconds": round(self.frames / RATE, 6),
            "sample_rate_hz": RATE, "channels": 2, "bits_per_sample": 16,
            "peak_dbfs": round(20 * math.log10(peak), 2),
            "rms_dbfs": round(10 * math.log10(square_sum / (2 * self.frames)), 2),
            "boundary_jump_pcm": max(abs(a - b) for a, b in zip(first, last)),
            "loop": self.loop,
        }


def compose_loop():
    mix = Mix(frames=BEAT_FRAMES * 32, loop=True)
    # D / G / Bm / A / D / G / A / D. Original sparse pentatonic melody.
    chords = [(50, 54, 57), (43, 47, 50), (47, 50, 54), (45, 49, 52),
              (50, 54, 57), (43, 47, 50), (45, 49, 52), (50, 54, 57)]
    motifs = [(74, 78, 81, 78), (79, 78, 74, 71), (78, 81, 83, 81), (76, 73, 71, 69),
              (74, 78, 81, 86), (83, 81, 79, 78), (76, 78, 73, 76), (78, 76, 74, 69)]
    for bar, chord in enumerate(chords):
        start = bar * 4 * BEAT
        for j, note in enumerate(chord):
            mix.tone(start, 4 * BEAT + .60, note + 12, .045, "pad", (j - 1) * .35)
        mix.tone(start, 2.8 * BEAT, chord[0] - 12, .09, pan=0)
        for step in range(8):
            note = chord[step % 3] + 12
            mix.tone(start + step * .5 * BEAT, .95, note, .080 if step % 2 == 0 else .054,
                     pan=(-.30 if step % 2 == 0 else .30))
        for step, note in enumerate(motifs[bar]):
            mix.tone(start + (step + .25) * BEAT, 1.15, note, .09, "wood", -.10)
    mix.echo(.151, .13)
    mix.echo(.293, .08)
    return mix


def compose_effect(key):
    durations = {"selection": .11, "place": .24, "capture": .48, "summon": .72,
                 "mage": .62, "warrior": .45, "rogue": .35, "danger": .55,
                 "victory": 2.15, "defeat": 1.55, "draw": 1.20}
    mix = Mix(seconds=durations[key])
    if key == "selection":
        mix.tone(0, .105, 81, .16, "wood")
    elif key == "place":
        mix.tone(0, .22, 50, .7, "wood")
        mix.sweep(0, .11, 170, 70, .3)
        mix.sweep(0, .06, 900, 300, .18, seed=101, noisy=True)
    elif key == "capture":
        for j, note in enumerate((81, 78, 74)):
            mix.tone(j * .045, .30, note, .28, "bell", (j - 1) * .35)
        mix.sweep(.02, .32, 900, 100, .20, seed=102, noisy=True)
    elif key == "summon":
        for j, note in enumerate((62, 66, 69, 74)):
            mix.tone(j * .09, .41, note, .26, "bell", (j % 2 - .5) * .5)
        mix.sweep(.29, .24, 150, 65, .28)
    elif key == "mage":
        for j, note in enumerate((74, 81, 86)):
            mix.tone(j * .067, .45, note, .28, "bell", (j - 1) * .2)
        mix.sweep(.01, .38, 280, 900, .18)
    elif key == "warrior":
        mix.sweep(0, .24, 160, 48, .50)
        mix.tone(.045, .35, 62, .20, "bell")
        mix.sweep(.015, .18, 200, 80, .25, seed=103, noisy=True)
    elif key == "rogue":
        mix.sweep(0, .26, 250, 1300, .50, seed=104, noisy=True)
        mix.tone(.02, .23, 86, .09, "bell", -.45)
        mix.tone(.12, .20, 81, .13, "bell", .45)
    elif key == "danger":
        mix.tone(0, .25, 76, .28, "wood")
        mix.tone(.24, .28, 74, .32, "wood")
    elif key == "victory":
        for start, notes in ((0, (62, 66, 69)), (.30, (67, 71, 74)), (.60, (69, 73, 76)),
                             (.90, (74, 78, 81))):
            for j, note in enumerate(notes):
                mix.tone(start + j * .018, 1.05, note, .22, "bell", (j - 1) * .25)
        mix.tone(1.20, .8, 86, .12, "bell")
    elif key == "defeat":
        for j, note in enumerate((69, 66, 62, 59)):
            mix.tone(j * .22, .8, note, .23, pan=(j - 1.5) * .12)
    elif key == "draw":
        for j, note in enumerate((62, 69, 74)):
            mix.tone(j * .16, .78, note, .22, "bell")
    mix.echo(.07, .10)
    return mix


def validate_encoded_wav(content, expected_frames, loop):
    """Inspect encoded bytes against format/level invariants, independent of mixing."""
    with wave.open(io.BytesIO(content), "rb") as encoded:
        assert encoded.getparams()[:4] == (2, 2, RATE, expected_frames), "Unexpected PCM header"
        samples = array("h")
        samples.frombytes(encoded.readframes(expected_frames))
    if struct.pack("=h", 1) != struct.pack("<h", 1):
        samples.byteswap()
    assert len(samples) == expected_frames * 2
    assert 0 < max(abs(value) for value in samples) < round(.75 * 32767), "Silent or insufficient headroom"
    assert abs(sum(samples) / len(samples)) < 65, "DC offset exceeds 0.2 percent full scale"
    if loop:
        assert max(abs(samples[c] - samples[-2 + c]) for c in range(2)) < 800, "Discontinuous loop boundary"
    else:
        assert list(samples[:2]) == list(samples[-2:]) == [0, 0], "SFX endpoints must be silent"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Recompose; verify exact WAV + manifest bytes and signal limits.")
    args = parser.parse_args()
    products = {}
    entries = []
    mixes = [("tabletop-loop", compose_loop(), .34)]
    mixes += [(key, compose_effect(key), .13 if key == "selection" else .52)
              for key in ("selection", "place", "capture", "summon", "mage", "warrior", "rogue", "danger", "victory", "defeat", "draw")]
    for key, mix, peak in mixes:
        content, spec = mix.wav(peak)
        name = key + ".wav"
        assert spec["rms_dbfs"] > -60, f"Silent asset: {name}"
        assert peak < .8, f"Insufficient headroom: {name}"
        if mix.loop:
            assert spec["boundary_jump_pcm"] < 800, "Loop boundary can click"
        else:
            assert spec["boundary_jump_pcm"] == 0, "SFX fade endpoints must be zero"
        validate_encoded_wav(content, mix.frames, mix.loop)
        products[name] = content
        entries.append({"key": key, "file": name, "sha256": hashlib.sha256(content).hexdigest(), **spec})
    manifest = {
        "schema_version": 1, "candidate": "AUDIO-01 original procedural prototype",
        "created_for": "TacticalGo", "composition_date": "2026-10-09",
        "source": "scripts/generate-combat-audio.py",
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "generation": "Python 3 standard library additive/subtractive synthesis; seeded noise; original note events; no audio samples, downloads or model service",
        "seed": {"place": 101, "capture": 102, "warrior": 103, "rogue": 104},
        "rights": {"third_party_inputs": [], "external_sample_license": "not applicable; no external recordings",
                   "publication_status": "prototype only; owner rights and listening approval required before formal release"},
        "music": {"tempo_bpm": 90, "bars": 8, "meter": "4/4", "key": "D major",
                  "style": "quiet warm fantasy tabletop; synthesized wood/pluck/soft harmonic pad",
                  "loop_method": "exact 32-beat frame grid; notes and stereo echoes wrap into beginning"},
        "assets": entries,
    }
    products["manifest.json"] = (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode()
    if args.check:
        for name, content in products.items():
            path = OUTPUT / name
            assert path.exists() and path.read_bytes() == content, f"Regeneration differs: {path}"
        print(f"PASS: {len(entries)} assets and manifest reproduce exactly; PCM, headroom, RMS and loop/SFX endpoints validated.")
    else:
        OUTPUT.mkdir(parents=True, exist_ok=True)
        for name, content in products.items():
            (OUTPUT / name).write_bytes(content)
        print(f"Generated {len(entries)} original stereo PCM WAV candidates ({sum(len(v) for v in products.values()):,} bytes).")
    print(f"Loop: {entries[0]['duration_seconds']} s, boundary jump {entries[0]['boundary_jump_pcm']} / 32767; no release rights approval claimed.")


if __name__ == "__main__":
    main()
