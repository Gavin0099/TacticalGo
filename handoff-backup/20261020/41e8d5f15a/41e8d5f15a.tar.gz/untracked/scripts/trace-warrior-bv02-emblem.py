"""Vectorize the actual B-v02 gold branch; no replacement heraldry design."""
from pathlib import Path
from PIL import Image
import json,hashlib,math
root=Path(__file__).resolve().parents[1];ref=root/'assets/candidates/vis-feel-01/tokens/B-warrior-v02.png';im=Image.open(ref).convert('RGBA');pix=im.load();mask=set()
for y in range(307,484):
 for x in range(292,453):
  if y<342 and not 355<=x<=386:continue # exclude the top frame connected to the central emblem stem
  r,g,b,a=pix[x,y]
  if a>220 and r>g*1.03 and g>b*1.3 and g>48:mask.add((x,y))
seed=min(mask,key=lambda p:(p[0]-369)**2+(p[1]-450)**2);todo=[seed];component=set()
while todo:
 p=todo.pop()
 if p in component or p not in mask:continue
 component.add(p);x,y=p;todo.extend([(x-1,y),(x+1,y),(x,y-1),(x,y+1)])
edges={}
for x,y in component:
 for neighbor,a,b in [((x,y-1),(x,y),(x+1,y)),((x+1,y),(x+1,y),(x+1,y+1)),((x,y+1),(x+1,y+1),(x,y+1)),((x-1,y),(x,y+1),(x,y))]:
  if neighbor not in component:edges.setdefault(a,[]).append(b)
loops=[]
while edges:
 start=next(iter(edges));a=start;loop=[]
 while True:
  loop.append(a);bs=edges[a];b=bs.pop()
  if not bs:del edges[a]
  a=b
  if a==start:break
  if a not in edges:break
 loops.append(loop)
outline=max(loops,key=len)
def simplify(points,eps):
 if len(points)<3:return points
 a,b=points[0],points[-1];den=math.dist(a,b)
 ds=[abs((b[0]-a[0])*(a[1]-p[1])-(a[0]-p[0])*(b[1]-a[1]))/den if den else math.dist(a,p) for p in points];m=max(ds);i=ds.index(m)
 return simplify(points[:i+1],eps)[:-1]+simplify(points[i:],eps) if m>eps else [a,b]
# Break closed path at furthest point, preserve both halves.
k=max(range(len(outline)),key=lambda i:math.dist(outline[i],outline[0]));result=simplify(outline[:k+1],.7)[:-1]+simplify(outline[k:]+[outline[0]],.7)[:-1]
out=root/'assets/candidates/warrior-bust-bv02-v01/emblem-trace.json';out.write_text(json.dumps({'reference':str(ref.relative_to(root)),'referenceSHA256':hashlib.sha256(ref.read_bytes()).hexdigest(),'method':'actual gold-color component within inner-shield ROI; boundary traced, max simplification .7 source pixels; not a newly invented icon','componentPixels':len(component),'bounds':[min(x for x,y in component),min(y for x,y in component),max(x for x,y in component),max(y for x,y in component)],'outlinePixels':result,'notClaimed':'hidden or original high-resolution contour; 512 derivative only'},indent=2)+'\n');print(out,len(component),len(result),json.loads(out.read_text())['bounds'])
