import importlib.util
import math
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('compact',Path(__file__).resolve().parents[1]/'compact-static-models.py')
compact=importlib.util.module_from_spec(spec);spec.loader.exec_module(compact)


class StaticTransformTests(unittest.TestCase):
    def test_position_translation_and_nonuniform_scale(self):
        m=[[2,0,0,0],[0,3,0,0],[0,0,4,0],[10,20,30,1]]
        self.assertEqual(compact.transform(m,[1,2,3]),[12,26,42])
        self.assertEqual(compact.normal(m,[0,1,0]),[0,1,0])

    def test_normal_uses_inverse_transpose(self):
        m=[[2,0,0,0],[0,3,0,0],[0,0,4,0],[91,82,73,1]]
        result=compact.normal(m,[1/math.sqrt(2),1/math.sqrt(2),0])
        self.assertAlmostEqual(result[0],3/math.sqrt(13),places=12)
        self.assertAlmostEqual(result[1],2/math.sqrt(13),places=12)
        self.assertEqual(result[2],0)

    def test_known_quarter_rotation_after_parent_translation(self):
        quarter=[[0,1,0,0],[-1,0,0,0],[0,0,1,0],[0,0,0,1]]
        parent=[[1,0,0,0],[0,1,0,0],[0,0,1,0],[10,20,30,1]]
        m=compact.multiply(parent,quarter)
        self.assertEqual(compact.transform(m,[2,0,0]),[10,22,30])
        self.assertEqual(compact.normal(m,[1,0,0]),[0,1,0])

    def test_reflection_sign_and_normal(self):
        m=[[-2,0,0,0],[0,3,0,0],[0,0,4,0],[0,0,0,1]]
        self.assertEqual(compact.determinant(m),-24)
        self.assertEqual(compact.normal(m,[1,0,0]),[-1,0,0])

    def test_singular_nonfinite_and_zero_normal_rejected(self):
        with self.assertRaises(ValueError):compact.normal([[0,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]],[1,0,0])
        with self.assertRaises(ValueError):compact.transform(compact.IDENTITY,[float('nan'),0,0])
        with self.assertRaises(ValueError):compact.normal(compact.IDENTITY,[0,0,0])


if __name__=='__main__':unittest.main()
