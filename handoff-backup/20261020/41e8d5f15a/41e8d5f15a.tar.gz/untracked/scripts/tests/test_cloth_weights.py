import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('cloth', Path(__file__).parents[1] / 'cloth_weights.py')
cloth = importlib.util.module_from_spec(spec); spec.loader.exec_module(cloth)


class CapeWeightTests(unittest.TestCase):
    def test_reviewed_shoulder_midpoint_and_hem_bindings(self):
        # Independent garment contract: upper edge belongs entirely to body;
        # halfway down the transition both bones contribute equally.
        for height in [.665, .735, 1]: self.assertEqual(cloth.cape_weight(height), 0)
        for height in [.4, .25, 0]: self.assertEqual(cloth.cape_weight(height), 1)
        self.assertAlmostEqual(cloth.cape_weight(.5325), .5)

    def test_no_negative_or_overshooting_skin_contributions(self):
        samples = [cloth.cape_weight(y / 1000) for y in range(0, 1001)]
        self.assertTrue(all(0 <= w <= 1 for w in samples))
        self.assertTrue(all(a >= b for a, b in zip(samples, samples[1:])))
        for height in [float('nan'), float('inf'), -float('inf')]:
            with self.assertRaises(ValueError): cloth.cape_weight(height)
