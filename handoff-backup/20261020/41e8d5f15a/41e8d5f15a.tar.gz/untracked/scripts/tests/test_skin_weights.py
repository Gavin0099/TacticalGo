import importlib.util
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location("skin",Path(__file__).parents[1]/"audit-skin-weights.py")
skin=importlib.util.module_from_spec(spec);spec.loader.exec_module(skin)


class SkinWeightTests(unittest.TestCase):
    def test_supported_topology_and_partial_or_misordered_rigs(self):
        original = ["body", "body/left_arm", "body/right_arm", "body/head"]
        articulated = original + [
            "body/left_thigh", "body/left_thigh/left_calf",
            "body/left_thigh/left_calf/left_foot", "body/right_thigh",
            "body/right_thigh/right_calf", "body/right_thigh/right_calf/right_foot",
        ]
        self.assertTrue(skin.validate_joint_names(original, 4)["passed"])
        self.assertTrue(skin.validate_joint_names(articulated, 10)["passed"])
        self.assertTrue(skin.validate_joint_names(articulated + ["body/cape"], 11)["passed"])
        self.assertFalse(skin.validate_joint_names(articulated + ["body/head/cape"], 11)["passed"])
        wrong_order = articulated.copy()
        wrong_order[4], wrong_order[5] = wrong_order[5], wrong_order[4]
        for names, count in [(original, 10), (articulated, 4),
                             (articulated[:-1], None), (wrong_order, 10),
                             (articulated + ["body"], None),
                             (original + ["body/tail"], None)]:
            with self.subTest(names=names, count=count):
                self.assertFalse(skin.validate_joint_names(names, count)["passed"])

    def test_normalized_two_joint_fixture(self):
        result=skin.validate_weights([.2,.8,1,0],[0,1,3,0],2,2,4)
        self.assertTrue(result["passed"]);self.assertEqual(result["mixedVertices"],1)

    def test_invalid_weight_or_index_rejected(self):
        for weights,indices in [([-.1,1.1],[0,1]),([float("nan"),1],[0,1]),([.5,.5],[0,4])]:
            self.assertFalse(skin.validate_weights(weights,indices,2,1,4)["passed"])

    def test_sum_duplicate_or_length_rejected(self):
        for weights,indices in [([.2,.7],[0,1]),([.5,.5],[1,1]),([1],[0])]:
            self.assertFalse(skin.validate_weights(weights,indices,2,1,4)["passed"])


if __name__=="__main__":unittest.main()
