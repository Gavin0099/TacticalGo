import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from surface_colors import atlas_limits, linear_to_srgb, srgb_to_linear


class SurfaceColorTests(unittest.TestCase):
    def test_standard_transfer_reference_values(self):
        # IEC sRGB reference points; independent of any generated model/image.
        self.assertAlmostEqual(srgb_to_linear(.5), .21404114048223255)
        self.assertAlmostEqual(linear_to_srgb(.18), .46135612950044164)
        self.assertAlmostEqual(srgb_to_linear(.04045), .0031308049535603713)
        self.assertAlmostEqual(linear_to_srgb(.0031308), .040449936)

    def test_ao_fallback_is_encoded_after_linear_multiplication(self):
        low, high, fallback = atlas_limits((.21404114048223255, 1, 0))
        self.assertAlmostEqual(fallback[0], .47616244159974214)
        self.assertAlmostEqual(fallback[1], .9546871718858662)
        self.assertEqual(fallback[2], 0)
        self.assertLess(low[0], fallback[0])
        self.assertGreater(high[0], fallback[0])
        # Writing the linear .192637 directly into a byte sRGB atlas is the
        # observed darkening regression; it falls outside the intended bounds.
        self.assertLess(.21404114048223255 * .90, low[0])
