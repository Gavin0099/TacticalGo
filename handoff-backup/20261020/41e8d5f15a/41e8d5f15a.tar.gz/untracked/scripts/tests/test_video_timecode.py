import importlib.util
from pathlib import Path
import unittest
spec=importlib.util.spec_from_file_location('clock',Path(__file__).resolve().parents[1]/'video_timecode.py')
clock=importlib.util.module_from_spec(spec);spec.loader.exec_module(clock)

class PixelClockTests(unittest.TestCase):
    def fixture(self):
        # Handwritten four bytes 01/02/03/04 have XOR 04. This fixture is not
        # encoded by production Swift or the decoder's implementation.
        bits='0000000100000010000000110000010000000100'
        return [(0,255,255)]+[(255,255,255) if b=='1' else (0,0,0) for b in bits]+[(255,0,255)]
    def test_handwritten_epoch_and_wrap(self):
        self.assertEqual(clock.decode_cells(self.fixture(),0x01020304),0x01020304)
        self.assertEqual(clock.decode_cells(self.fixture(),(1<<32)+0x01020304),(1<<32)+0x01020304)
    def test_corrupted_timestamp_and_missing_anchor_rejected(self):
        cells=self.fixture();cells[1]=(255,255,255)
        self.assertIsNone(clock.decode_cells(cells,0x01020304))
        cells=self.fixture();cells[-1]=(0,255,255)
        self.assertIsNone(clock.decode_cells(cells,0x01020304))
    def test_ambiguous_cell_or_incomplete_strip_rejected(self):
        cells=self.fixture();cells[12]=(110,110,110)
        self.assertIsNone(clock.decode_cells(cells,0x01020304))
        self.assertIsNone(clock.decode_cells(self.fixture()[:-1],0x01020304))

if __name__=='__main__':unittest.main()
