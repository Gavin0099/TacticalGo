import copy
import importlib.util
import math
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location("shells", Path(__file__).parents[1] / "audit-model-shells.py")
shells = importlib.util.module_from_spec(spec)
spec.loader.exec_module(shells)


class ShellAuditTests(unittest.TestCase):
    def setUp(self):
        # Independently authored tetrahedron: signed volume is analytically 1/6.
        self.fixture = dict(id="fixture", points=[[0,0,0],[1,0,0],[0,1,0],[0,0,1]],
                            normals=[[-1/math.sqrt(3)]*3,[1,0,0],[0,1,0],[0,0,1]],
                            triangles=[0,2,1,0,1,3,0,3,2,1,2,3])

    def test_closed_oriented_volume(self):
        result = shells.audit(self.fixture)
        self.assertTrue(result["passed"])
        self.assertAlmostEqual(result["signedVolumeLocalUnits"], 1/6)

    def test_missing_face_rejects_open_shell(self):
        self.fixture["triangles"] = self.fixture["triangles"][:-3]
        result = shells.audit(self.fixture)
        self.assertFalse(result["passed"])
        self.assertEqual(result["boundaryOrNonmanifoldEdges"], 3)

    def test_flipped_face_rejects_orientation(self):
        self.fixture["triangles"][:3] = [0,1,2]
        result = shells.audit(self.fixture)
        self.assertFalse(result["passed"])
        self.assertEqual(result["inconsistentEdgeDirections"], 3)

    def test_degenerate_or_nonunit_normal_rejected(self):
        self.fixture["triangles"] += [0,0,1]
        self.assertFalse(shells.audit(self.fixture)["passed"])
        self.fixture["triangles"] = self.fixture["triangles"][:-3]
        self.fixture["normals"][0] = [0,0,0]
        self.assertFalse(shells.audit(self.fixture)["passed"])


if __name__ == "__main__":
    unittest.main()
