"""Hand-authored axis/state invariants, including the observed orthogonal-snap failure."""
import copy
import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('pan_audit', Path(__file__).parents[1] / 'audit-board-pan.py')
audit = importlib.util.module_from_spec(spec); spec.loader.exec_module(audit)


def fixtures():
    # These expected directions are the gesture contract, not copied ray math.
    def entry(n, pid, x, z):
        return dict(size=n, pid=pid, focus=[x,.08,z], panMinimum=[-1,-1], panMaximum=[1,1],
                    ap=2, mana=4, selected=[], diagram='unchanged fixture board')
    return [[entry(7,101,.5,0),entry(7,101,.5,.5)],
            [entry(9,102,.5,0),entry(9,102,.5,.5)],
            [entry(9,103,x,x) for x in [.4,.8,1,1]]]


class PanAuditTests(unittest.TestCase):
    def test_known_good_axes_and_boundaries(self): audit.audit_records(fixtures())
    def test_horizontal_orthogonal_snap_is_rejected(self):
        r=fixtures(); r[0][0]['focus']=[0,.08,.3]
        with self.assertRaisesRegex(AssertionError,'Horizontal'): audit.audit_records(r)
    def test_vertical_changes_horizontal_is_rejected(self):
        r=fixtures(); r[1][1]['focus']=[.8,.08,.5]
        with self.assertRaisesRegex(AssertionError,'Vertical'): audit.audit_records(r)
    def test_drag_spends_mana_is_rejected(self):
        r=fixtures(); r[1][1]['mana']=3
        with self.assertRaises(AssertionError): audit.audit_records(r)
    def test_drag_changes_selection_or_board_is_rejected(self):
        for key,value in [('selected',[[4,4]]),('diagram','mutated board')]:
            r=fixtures(); r[0][1][key]=value
            with self.assertRaises(AssertionError): audit.audit_records(r)
    def test_out_of_bound_camera_is_rejected(self):
        r=fixtures(); r[2][-1]['focus']=[1.2,.08,1]
        with self.assertRaises(AssertionError): audit.audit_records(r)
    def test_missing_launch_is_rejected(self):
        with self.assertRaises(AssertionError): audit.audit_records(fixtures()[:2])
    def test_repeated_drag_never_reaches_boundary_is_rejected(self):
        r=fixtures(); r[2][-1]['focus']=[.8,.08,.8]
        with self.assertRaisesRegex(AssertionError,'Repeated'): audit.audit_records(r)
