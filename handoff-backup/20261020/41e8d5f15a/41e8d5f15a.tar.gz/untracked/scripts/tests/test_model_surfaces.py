import importlib.util
from pathlib import Path
import struct
import unittest

spec = importlib.util.spec_from_file_location('surfaces', Path(__file__).parents[1] / 'audit-model-surfaces.py')
surfaces = importlib.util.module_from_spec(spec); spec.loader.exec_module(surfaces)


class SurfaceContractTests(unittest.TestCase):
    def test_triangle_corner_binding_and_rejected_streams(self):
        uv = [(0, 0), (1, 0), (0, 1)]
        self.assertTrue(surfaces.validate_uv(uv, [0, 1, 2], 3)['passed'])
        for indices in ([0, 1], [0, 1, 3], [0, -1, 2], [0, 1.0, 2]):
            with self.subTest(indices=indices):
                self.assertFalse(surfaces.validate_uv(uv, indices, 3)['passed'])

    def test_nonfinite_and_out_of_atlas_uv_are_rejected(self):
        for point in ((float('nan'), 0), (float('inf'), 0), (-.1, 0), (1.1, 0), (0, 0, 0)):
            with self.subTest(point=point):
                self.assertFalse(surfaces.validate_uv([point], [0, 0, 0], 3)['passed'])

    def test_png_dimensions_from_ihdr_and_invalid_headers(self):
        fixture = b'\x89PNG\r\n\x1a\n' + struct.pack('>I', 13) + b'IHDR' + struct.pack('>II', 1024, 1024) + b'\x08\x02\x00\x00\x00' + b'\x00' * 4
        self.assertEqual(surfaces.png_size(fixture), [1024, 1024])
        for data in (b'', fixture[:24], b'not-a-png' + fixture[9:]):
            with self.subTest(data=data):
                with self.assertRaises(ValueError): surfaces.png_size(data)
