import copy
import importlib.util
from pathlib import Path
import tempfile
import unittest
import json

spec = importlib.util.spec_from_file_location("model_export", Path(__file__).parents[1] / "export-models-usd.py")
writer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(writer)
IDENTITY = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]


def fixture():
    # Independent triangle, translated two metres along X. Its bounds are explicit.
    root = {"name": "FixtureHero", "matrixColumns": copy.deepcopy(IDENTITY), "children": [],
            "mesh": "triangle", "surface": {"colorSRGB": [1, 0, 0, 1], "roughness": .7, "metallic": 0}}
    root["matrixColumns"][3][0] = 2
    mesh = {"models": [{"id": "triangle", "parts": [{
        "id": "face", "points": [[0, 0, 0], [1, 0, 0], [0, 1, 0]],
        "normals": [[0, 0, 1]] * 3, "triangles": [0, 1, 2]}]}],
        "instances": [{"model": "triangle", "matrixColumns": copy.deepcopy(IDENTITY)}]}
    return {"schema": "tacticalgo-model-snapshot.v1", "upAxis": "Y", "metersPerUnit": 1,
            "models": {"FixtureHero": root}, "meshes": {"triangle": mesh}}


class ModelExportTests(unittest.TestCase):
    def testValidFixturePreservesTopologyBoundsAndUSDRowTranslation(self):
        data = fixture()
        writer.validate(data)
        text, counts = writer.stage(data, "FixtureHero")
        self.assertIn("faceVertexIndices = [0, 1, 2]", text)
        self.assertIn("extent = [(0, 0, 0), (1, 1, 0)]", text)
        self.assertIn("(2, 0, 0, 1)", text)  # Gf row-vector convention, not last-column translation.
        self.assertIn('info:id = "UsdPreviewSurface"', text)
        self.assertEqual(counts["triangles"], 1)
        self.assertEqual(counts["vertices"], 3)

    def testInvalidIndexFailsBeforeWritingFiles(self):
        data = fixture()
        data["meshes"]["triangle"]["models"][0]["parts"][0]["triangles"] = [0, 1, 3]
        with tempfile.TemporaryDirectory() as directory:
            source, output = Path(directory) / "bad.json", Path(directory) / "out"
            source.write_text(json.dumps(data))
            with self.assertRaisesRegex(ValueError, "outside vertex"):
                writer.export(source, output)
            self.assertFalse(output.exists())

    def testNonFinitePointAndMalformedMatrixRejected(self):
        for mutation in ["nan", "matrix"]:
            data = fixture()
            if mutation == "nan":
                data["meshes"]["triangle"]["models"][0]["parts"][0]["points"][1][0] = float("nan")
            else:
                data["models"]["FixtureHero"]["matrixColumns"] = [[1, 0, 0, 0]]
            with self.assertRaises(ValueError):
                writer.validate(data)

    def testDanglingMeshAndMismatchedNormalsRejected(self):
        data = fixture()
        data["models"]["FixtureHero"]["mesh"] = "missing"
        with self.assertRaisesRegex(ValueError, "Missing mesh"):
            writer.validate(data)
        data = fixture()
        data["meshes"]["triangle"]["models"][0]["parts"][0]["normals"].pop()
        with self.assertRaisesRegex(ValueError, "normal count"):
            writer.validate(data)

    def testWritesInspectableAssetAndManifestWithSourceHash(self):
        with tempfile.TemporaryDirectory() as directory:
            source, output = Path(directory) / "source.json", Path(directory) / "out"
            source.write_text(json.dumps(fixture()))
            manifest = writer.export(source, output)
            self.assertTrue((output / "fixturehero.usda").is_file())
            self.assertEqual(json.loads((output / "manifest.json").read_text()), manifest)
            self.assertEqual(len(manifest["sourceSHA256"]), 64)
            self.assertTrue(manifest["candidate"])

    def testPoseSamplesPreserveRestEndpointsAndRejectMissingFrames(self):
        data = fixture()
        data["animation"] = {"framesPerSecond": 30, "endTimeCode": 42}
        root = data["models"]["FixtureHero"]
        root["matrixSamples"] = [{"time": i, "matrixColumns": copy.deepcopy(root["matrixColumns"])} for i in range(43)]
        root["matrixSamples"][21]["matrixColumns"][3][1] = .5
        writer.validate(data)
        text, _ = writer.stage(data, "FixtureHero", animated=True)
        self.assertIn("endTimeCode = 42", text)
        self.assertIn("xformOp:transform.timeSamples", text)
        self.assertIn("(2, 0.5, 0, 1)", text)
        root["matrixSamples"].pop(20)
        with self.assertRaisesRegex(ValueError, "unordered pose"):
            writer.validate(data)

    def testPoseThatFailsToSettleAtRestIsRejected(self):
        data = fixture()
        data["animation"] = {"framesPerSecond": 30, "endTimeCode": 42}
        root = data["models"]["FixtureHero"]
        root["matrixSamples"] = [{"time": i, "matrixColumns": copy.deepcopy(root["matrixColumns"])} for i in range(43)]
        root["matrixSamples"][-1]["matrixColumns"][3][0] = 3
        with self.assertRaisesRegex(ValueError, "settle at the rest"):
            writer.validate(data)


class IdleExportTests(unittest.TestCase):
    def idle(self):
        data = fixture()
        data["animation"] = {"framesPerSecond": 30, "endTimeCode": 102}
        root = data["models"]["FixtureHero"]
        root["matrixSamples"] = [{"time": i, "matrixColumns": copy.deepcopy(root["matrixColumns"])} for i in range(103)]
        root["matrixSamples"][51]["matrixColumns"][3][1] = -.004
        return data

    def testExplicitIdleDurationAndEndpointsExport(self):
        data = self.idle(); writer.validate(data)
        text, counts = writer.stage(data, "FixtureHero", animated=True)
        self.assertIn("endTimeCode = 102", text)
        self.assertIn("51: ((1, 0, 0, 0)", text)
        self.assertIn("(2, -0.004, 0, 1)", text)
        self.assertEqual(counts["triangles"], 1)
        self.assertEqual(counts["vertices"], 3)

    def testMissingReorderedAndUnsettledIdleRejected(self):
        for defect in ["missing", "reordered", "unsettled", "wrong-duration", "wrong-rate"]:
            data = self.idle(); samples = data["models"]["FixtureHero"]["matrixSamples"]
            if defect == "missing": samples.pop(51)
            elif defect == "reordered": samples[50], samples[51] = samples[51], samples[50]
            elif defect == "unsettled": samples[-1]["matrixColumns"][3][1] = -.004
            elif defect == "wrong-duration": data["animation"]["endTimeCode"] = 101
            else: data["animation"]["framesPerSecond"] = 60
            with self.subTest(defect=defect), self.assertRaises(ValueError): writer.validate(data)
