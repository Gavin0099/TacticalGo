"""Decode the independent DEBUG pixel clock in native review recordings.

Protocol: cyan anchor, 32 MSB-first epoch-millisecond low bits, eight bits
containing XOR of the four timestamp bytes, magenta anchor. Movie PTS and
native wall time are independently observed; never assume recorder spawn=PTS0.
"""

def decode_cells(cells, near_epoch_ms):
    if len(cells) != 42:
        return None
    r,g,b = cells[0]
    if not (r < 90 and g > 180 and b > 180):
        return None
    r,g,b = cells[-1]
    if not (r > 180 and g < 90 and b > 180):
        return None
    payload = 0
    for pixel in cells[1:-1]:
        if max(pixel) < 70: bit = 0
        elif min(pixel) > 180: bit = 1
        else: return None
        payload = (payload << 1) | bit
    stamp, check = payload >> 8, payload & 255
    if (stamp ^ (stamp >> 8) ^ (stamp >> 16) ^ (stamp >> 24)) & 255 != check:
        return None
    period = 1 << 32
    return stamp + round((near_epoch_ms - stamp) / period) * period


def find_marker(pixels, near_epoch_ms):
    import numpy as np
    data = np.asarray(pixels.convert('RGB'))
    cyan = (data[:,:,0] < 90) & (data[:,:,1] > 180) & (data[:,:,2] > 180)
    magenta = (data[:,:,0] > 180) & (data[:,:,1] < 90) & (data[:,:,2] > 180)
    for y in np.where(cyan.any(axis=1) & magenta.any(axis=1))[0]:
        starts = np.where(cyan[y] & ~np.r_[False, cyan[y,:-1]])[0]
        for start in starts:
            for cell in (8,12):
                for offset in (0,-1,1):
                    x = int(start) + offset
                    centers = [x + cell * i + cell//2 for i in range(42)]
                    if min(centers) < 0 or max(centers) >= data.shape[1]: continue
                    samples = [tuple(int(v) for v in data[y,c]) for c in centers]
                    if decode_cells(samples, near_epoch_ms) is not None:
                        return {'x':x,'y':int(y),'cellPixels':cell,'width':cell*42}
    raise ValueError('No valid pixel timecode found; do not infer video alignment')
