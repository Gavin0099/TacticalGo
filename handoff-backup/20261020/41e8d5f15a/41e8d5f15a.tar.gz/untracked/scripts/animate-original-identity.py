"""Author class-specific skinned pose studies from the inspected rest pose, not rule outcomes."""
import bpy,math,json,hashlib,sys
from pathlib import Path
from mathutils import Vector,Quaternion
root=Path(__file__).resolve().parents[1];hero=sys.argv[sys.argv.index('--')+1];out=root/'assets/candidates/ios-identity-motion-v04'/hero;out.mkdir(parents=True,exist_ok=True)
identityVersion='ios-identity-v05' if hero=='mage' else 'ios-identity-v02'
bpy.ops.wm.open_mainfile(filepath=str(root/'assets/candidates'/identityVersion/hero/(hero+'.blend')));scene=bpy.context.scene;rig=next(o for o in scene.objects if o.type=='ARMATURE');scene.frame_set(1);bpy.context.view_layer.update()
# Bake authored hair subdivision before USD export so native meshes match actual source review.
subdivisionBakes=[]
for o in scene.objects:
 if o.type != 'MESH': continue
 for modifier in list(o.modifiers):
  if modifier.type == 'SUBSURF':
   bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
   bpy.ops.object.modifier_apply(modifier=modifier.name);subdivisionBakes.append(o.name)
base={b.name:(b.location.copy(),b.rotation_quaternion.copy(),b.scale.copy()) for b in rig.pose.bones};axes={b.name:b.matrix.to_quaternion().inverted()@Vector((1,0,0)) for b in rig.pose.bones}
rig.animation_data.action=None;action=bpy.data.actions.new(hero.title()+'_original_identity_skill_study');rig.animation_data.action=action;scene.render.fps=30;scene.frame_start=0;scene.frame_end=42
for frame in range(43):
 t=frame/42;bell=math.sin(math.pi*t)**2;anticipation=math.sin(math.pi*min(1,t/.35))*.12 if t<.35 else 0;strike=math.sin(math.pi*min(1,(t-.20)/.65))**2 if .20<t<.85 else 0
 for bone in rig.pose.bones:
  bone.rotation_mode='QUATERNION';bone.location, bone.rotation_quaternion,bone.scale=base[bone.name]
 angles={}
 if hero=='warrior':angles={'upperarm.l':-.48*strike+.10*anticipation,'lowerarm.l':-.12*strike,'chest':.09*strike,'head':-.05*strike}
 elif hero=='mage':angles={'upperarm.r':-.58*bell,'lowerarm.r':-.12*bell,'head':-.09*bell,'chest':-.035*bell}
 else:angles={'upperarm.r':-.50*strike,'upperarm.l':.18*strike,'chest':.13*bell,'head':-.05*bell,'upperleg.l':-.045*bell,'upperleg.r':-.045*bell,'lowerleg.l':.08*bell,'lowerleg.r':.08*bell}
 for name,angle in angles.items():rig.pose.bones[name].rotation_quaternion=base[name][1]@Quaternion(axes[name],angle)
 # Full start/end snapshots preserve all 23 authored joint transforms.
 for b in rig.pose.bones:
  b.keyframe_insert(data_path='location',frame=frame,group=b.name);b.keyframe_insert(data_path='rotation_quaternion',frame=frame,group=b.name);b.keyframe_insert(data_path='scale',frame=frame,group=b.name)
scene.frame_set(0);bpy.context.view_layer.update();parts=[o for o in scene.objects if o.type=='MESH'];source=out/(hero+'.blend');bpy.ops.wm.save_as_mainfile(filepath=str(source))
# Independent point samples: actual evaluated deformed vertices at source frames, not inferred bone angles.
samples=[];restPts=None
for frame in [0,9,21,33,42]:
 scene.frame_set(frame);bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();pts=[]
 for o in parts:
  e=o.evaluated_get(dg);pts.extend(tuple(o.matrix_world@v.co) for v in e.data.vertices)
 assert all(math.isfinite(c) for p in pts for c in p)
 if restPts is None:restPts=pts
 delta=max(math.dist(a,b) for a,b in zip(restPts,pts));samples.append({'frame':frame,'vertices':len(pts),'maxDisplacementMeters':delta,'bounds':[[min(p[i] for p in pts),max(p[i] for p in pts)] for i in range(3)]})
assert samples[-1]['maxDisplacementMeters']<1e-5,'End pose does not restore';assert samples[2]['maxDisplacementMeters']>.025,'Study has no visible deformation'
scene.frame_set(0);bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=rig
usd=out/(hero+'-rig.usda');bpy.ops.wm.usd_export(filepath=str(usd),selected_objects_only=True,export_animation=True,export_armatures=True,only_deform_bones=True,export_shapekeys=False,export_lights=False,export_cameras=False,export_normals=True,export_uvmaps=True,export_textures_mode='NEW',export_subdivision='IGNORE',generate_preview_surface=True,convert_orientation=True,export_global_up_selection='Y',root_prim_path='/'+hero.title()+'Identity',convert_world_material=False)
report={'class':hero,'animation':action.name,'frames':43,'durationSeconds':1.4,'joints':list(rig.data.bones.keys()),'samples':samples,'bakedSubdivisionMeshes':subdivisionBakes,'sourceBlendSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'usdSHA256':hashlib.sha256(usd.read_bytes()).hexdigest(),'notClaimed':['Owner likeness/quality acceptance','rules cue integration','native deformation parity','foot contact','performance','physical device']};(out/'motion-report.json').write_text(json.dumps(report,indent=2)+'\n')
scene.cycles.samples=24
for frame,label in [(0,'rest'),(21,'skill-mid')]:
 scene.frame_set(frame);cam=scene.camera;cam.location=(2.1,-5,1.8);cam.rotation_euler=(Vector((0,0,.65))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(label+'-three-quarter.png'));bpy.ops.render.render(write_still=True)
print('IDENTITY_SKILL_STUDY_COMPLETE',hero,samples)
