import bpy,bmesh,json,hashlib
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];out=root/'assets/candidates/ios-identity-v01/final/mage-brim';out.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(root/'assets/candidates/ios-identity-v01/final/mage/mage.blend'));scene=bpy.context.scene;rig=next(o for o in scene.objects if o.type=='ARMATURE');scene.frame_set(1)
for n in ['Crown curl','Cream brim bound edge']:
 o=bpy.data.objects.get(n)
 if o:bpy.data.objects.remove(o,do_unlink=True)
def surface(name,rows,m):
 import math
 n=48;vs=[];fs=[]
 for z,rx,ry in rows:
  for i in range(n):a=2*math.pi*i/n;vs.append((math.cos(a)*rx,math.sin(a)*ry+.03,z))
 for k in range(len(rows)-1):
  for i in range(n):j=(i+1)%n;fs.append((k*n+i,k*n+j,(k+1)*n+j,(k+1)*n+i))
 fs.extend([tuple(reversed(range(n))),tuple((len(rows)-1)*n+i for i in range(n))]);me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);me.materials.append(m);bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free();o.parent=rig;o.vertex_groups.new(name='head').add(list(range(len(me.vertices))),1,'REPLACE');o.modifiers.new('Hat binding','ARMATURE').object=rig
 for p in me.polygons:p.use_smooth=True
surface('Broad curved plum hat brim',[(1.815,.63,.48),(1.85,.65,.50),(1.90,.44,.37)],bpy.data.materials['Plum cloak and hat'])
surface('Cream wide brim binding',[(1.807,.636,.485),(1.838,.650,.499)],bpy.data.materials['Cream woven tunic'])
parts=[o for o in scene.objects if o.type=='MESH'];bpy.ops.wm.save_as_mainfile(filepath=str(out/'mage.blend'));bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=rig
usd=out/'mage-rig.usda';bpy.ops.wm.usd_export(filepath=str(usd),selected_objects_only=True,export_animation=True,export_armatures=True,only_deform_bones=True,export_shapekeys=False,export_lights=False,export_cameras=False,export_normals=True,export_uvmaps=True,export_textures_mode='NEW',export_subdivision='IGNORE',generate_preview_surface=True,convert_orientation=True,export_global_up_selection='Y',root_prim_path='/MageIdentity',convert_world_material=False)
scene.cycles.samples=24
for frame,label in [(1,'rest'),(26,'idle-mid')]:
 scene.frame_set(frame)
 for side,loc in [('front',(0,-5,1.45)),('three-quarter',(2.1,-5,1.8)),('back',(2.1,5,1.8))]:
  cam=scene.camera;cam.location=loc;cam.rotation_euler=(Vector((0,0,.65))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(label+'-'+side+'.png'));bpy.ops.render.render(write_still=True)
(out/'report.json').write_text(json.dumps({'sourceBlendSHA256':hashlib.sha256((out/'mage.blend').read_bytes()).hexdigest(),'usdSHA256':hashlib.sha256(usd.read_bytes()).hexdigest(),'change':'Wide cream-bound brim from original Mage art; remove floating crown curl','notClaimed':['exact likeness','Owner quality acceptance','physical device']},indent=2)+'\n');print('MAGE_WIDE_BRIM_COMPLETE')
