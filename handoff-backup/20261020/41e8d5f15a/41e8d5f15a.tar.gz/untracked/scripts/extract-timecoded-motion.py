#!/usr/bin/env python3
"""Extract real movie frames nearest to independently decoded native pixel time."""
import argparse, io, json, subprocess, sys
from pathlib import Path
from PIL import Image
from video_timecode import decode_cells, find_marker

p=argparse.ArgumentParser(description=__doc__);p.add_argument('video',type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--phases',type=float,nargs='+',default=[.5,.83]);a=p.parse_args()
if any(not 0 < phase < 1 for phase in a.phases):raise SystemExit('Phases must lie within the playback interval')
if a.output.exists():raise SystemExit('Use fresh output; prior evidence must remain')
a.output.mkdir(parents=True)
process=json.loads(a.video.with_suffix('.process.json').read_text());trace=json.loads(a.video.with_suffix('.trace.json').read_text())
if '--record-timecode' not in process['launchArguments']:raise SystemExit('No pixel clock requested; launch time cannot align movie PTS')
near=round(process['startedAt']*1000);ffmpeg='/opt/homebrew/bin/ffmpeg';ffprobe='/opt/homebrew/bin/ffprobe'
marker=None
for at in [6,10,15]:
    probe=subprocess.check_output([ffmpeg,'-v','error','-ss',str(at),'-i',str(a.video),'-frames:v','1','-f','image2pipe','-vcodec','png','pipe:1'])
    (a.output/f'timecode-probe-{at}.png').write_bytes(probe)
    try:marker=find_marker(Image.open(io.BytesIO(probe)),near);break
    except ValueError:pass
if marker is None:raise SystemExit('No valid timecode found; probe pixels retained')
pts=json.loads(subprocess.check_output([ffprobe,'-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=best_effort_timestamp_time','-of','json',str(a.video)],text=True))['frames']
crop=f"format=rgb24,crop={marker['width']}:1:{marker['x']}:{marker['y']}"
reader=subprocess.Popen([ffmpeg,'-v','error','-i',str(a.video),'-vf',crop,'-fps_mode','passthrough','-f','rawvideo','-pix_fmt','rgb24','pipe:1'],stdout=subprocess.PIPE)
rows=[];index=0;chunk_bytes=marker['width']*3
while True:
    raw=reader.stdout.read(chunk_bytes)
    if not raw:break
    assert len(raw)==chunk_bytes,'Truncated raw frame'
    cells=[tuple(raw[(i*marker['cellPixels']+marker['cellPixels']//2)*3:(i*marker['cellPixels']+marker['cellPixels']//2)*3+3]) for i in range(42)]
    stamp=decode_cells(cells,near)
    if stamp is not None and near-60000 <= stamp <= near+180000:
        rows.append({'frameIndex':index,'ptsSeconds':float(pts[index]['best_effort_timestamp_time']),'pixelEpochMilliseconds':stamp})
    index+=1
assert reader.wait()==0 and index==len(pts),(index,len(pts))
assert rows,'No valid decoded frames'
(a.output/'pixel-clock-index.json').write_text(json.dumps({'marker':marker,'totalFrames':index,'decodedFrames':len(rows),'rows':rows},indent=2)+'\n')
requested={r['receipt']:r['example'] for r in trace['rows'] if r['phase']=='requested'};mapping=[]
for n,start in enumerate(r for r in trace['rows'] if r['phase']=='native-start'):
    for phase in a.phases:
        target=start['wallTimeUnix']+start['durationSeconds']/start['rate']*phase
        nearest=min(rows,key=lambda r:abs(r['pixelEpochMilliseconds']/1000-target));error=abs(nearest['pixelEpochMilliseconds']/1000-target)
        filename=f'{n+1}-{phase}.png'
        mapping.append({'example':requested[start['receipt']],'receipt':start['receipt'],'normalizedPhase':phase,'targetEpochSeconds':target,'alignmentErrorSeconds':error,'file':filename,**nearest})
# Movie PTS may jump or be shifted by seeking. Select decoded frame indices,
# then independently validate the clock on EVERY extracted original PNG.
indices=sorted(set(row['frameIndex'] for row in mapping if row['alignmentErrorSeconds']<.100))
selection='select='+ '+'.join('eq(n\\,'+str(i)+')' for i in indices)
subprocess.run([ffmpeg,'-v','error','-i',str(a.video),'-vf',selection,'-fps_mode','passthrough','-start_number','0','-frames:v',str(len(indices)),str(a.output/'selected-%03d.png')],check=True)
lookup={index:a.output/f'selected-{n:03d}.png' for n,index in enumerate(indices)}
for row in mapping:
    if row['frameIndex'] not in lookup: continue
    source=lookup[row['frameIndex']]
    (a.output/row['file']).write_bytes(source.read_bytes())
    decoded=Image.open(source).convert('RGB')
    m=find_marker(decoded,near)
    cells=[decoded.getpixel((m['x']+m['cellPixels']*i+m['cellPixels']//2,m['y'])) for i in range(42)]
    stamp=decode_cells(cells,near)
    row['extractedPixelEpochMilliseconds']=stamp
    row['extractedAlignmentErrorSeconds']=abs(stamp/1000-row['targetEpochSeconds'])
    row['extractedClockMatchesFrameIndex']=stamp==row['pixelEpochMilliseconds']

(a.output/'mapping.json').write_text(json.dumps({'claim':'clock aligned raw frames; visual action/pose review remains separate; UI/Metal can differ by rendering latency','mapping':mapping},indent=2)+'\n')
assert all(r['alignmentErrorSeconds']<.100 and r.get('extractedClockMatchesFrameIndex') and r.get('extractedAlignmentErrorSeconds',1)<.100 for r in mapping),'Extracted frame/index clock mismatch or alignment >100ms; preserve evidence and do not claim valid review'
print(f'Clock aligned {len(mapping)} raw frames; maximum clock error {max(r["alignmentErrorSeconds"] for r in mapping):.4f}s')
