#!/usr/bin/env python3
"""Collect fresh meshes from the local debug prototype and validate editable USD candidates."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import signal
import subprocess
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--device", required=True, help="Simulator UDID")
parser.add_argument("--resources", type=Path, default=Path("assets/candidates/ios-3d-v01/resources"), help="Candidate output directory relative to the repository")
parser.add_argument("--evidence", type=Path, default=Path("artifacts/ios/model-resources-v01"), help="Evidence directory relative to the repository")
parser.add_argument("--idle", action="store_true", help="Export the separate 3.4-second idle study")
args = parser.parse_args()
snapshot_name = "idle-candidates.json" if args.idle else "model-candidates.json"
root = Path(__file__).resolve().parents[1]
evidence = root / args.evidence
resources = root / args.resources
evidence.mkdir(parents=True, exist_ok=True)
resources.mkdir(parents=True, exist_ok=True)
app = root / "ios/Build/Products/Debug-iphonesimulator/TacticalGo.app"
bundle = "com.tacticalgo.prototype"

def run(command, **kwargs):
    return subprocess.run(command, check=True, **kwargs)

build_hash = hashlib.sha256((app / "TacticalGo.debug.dylib").read_bytes()).hexdigest()
subprocess.run(["xcrun", "simctl", "terminate", args.device, bundle], capture_output=True)
run(["xcrun", "simctl", "install", args.device, str(app)])
container = Path(subprocess.check_output(["xcrun", "simctl", "get_app_container", args.device, bundle, "data"], text=True).strip())
source = container / "Documents" / snapshot_name
previous = source.stat().st_mtime_ns if source.exists() else 0
with (evidence / "native-export.log").open("w") as log:
    process = subprocess.Popen(["xcrun", "simctl", "launch", "--console-pty", args.device, bundle, "--models", "--export-idle" if args.idle else "--export-models"], stdout=log, stderr=log)
    try:
        for _ in range(100):
            if source.exists() and source.stat().st_mtime_ns > previous:
                break
            time.sleep(.2)
        else:
            raise RuntimeError("No fresh export; inspect native-export.log and ensure DEBUG is defined")
        snapshot = resources / snapshot_name
        shutil.copy2(source, snapshot)
    finally:
        process.send_signal(signal.SIGINT)
        process.wait(timeout=10)

spec = importlib.util.spec_from_file_location("writer", root / "scripts/export-models-usd.py")
writer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(writer)
manifest = writer.export(snapshot, resources / "usd")
results = []
for hero, asset in manifest["assets"].items():
    for kind, filename in [("static", asset["file"]), *([("rigidPose", asset["poseFile"])] if "poseFile" in asset else [])]:
        name = Path(filename).stem
        with (evidence / f"{name}-validation.log").open("w") as log:
            run(["usdchecker", "--strict", filename], cwd=resources / "usd", stdout=log, stderr=log)
            run(["usdcat", "-o", name + ".usdc", filename], cwd=resources / "usd", stdout=log, stderr=log)
            run(["usdzip", "--arkitAsset", name + ".usdc", name + ".usdz"], cwd=resources / "usd", stdout=log, stderr=log)
            run(["usdchecker", "--arkit", "--strict", name + ".usdz"], cwd=resources / "usd", stdout=log, stderr=log)
        package = resources / "usd" / (name + ".usdz")
        results.append(dict(hero=hero, kind=kind, triangles=asset["triangles"], vertices=asset["vertices"],
                            usdSHA256=hashlib.sha256((resources / "usd" / filename).read_bytes()).hexdigest(),
                            usdzSHA256=hashlib.sha256(package.read_bytes()).hexdigest(),
                            usdzBytes=package.stat().st_size, usdCheckerExit=0, arkitCheckerExit=0))
report = {"generatedAt": datetime.now(timezone.utc).isoformat(), "device": args.device,
          "sourceSHA256": manifest["sourceSHA256"], "buildExecutableSHA256": build_hash,
          "assets": results, "claim": "static candidate geometry and editable hierarchy; native import/visual QA still required"}
(evidence / "export-report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
