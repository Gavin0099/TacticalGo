"""Blender: compare actual rest meshes and review pinned shoulder/hem follow-through."""
import argparse
import itertools
import json
import math
from pathlib import Path
import sys
import bpy
from mathutils import Vector


def geometry(folder, hero):
    bpy.ops.wm.open_mainfile(filepath=str((folder / (hero + '.blend')).resolve()))
    scene = bpy.context.scene; scene.frame_set(0); bpy.context.view_layer.update()
    obj = bpy.data.objects[hero.title() + '_Skin']
    evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
    mesh = evaluated.to_mesh()
    points = [evaluated.matrix_world @ v.co for v in mesh.vertices]
    triangles = sum(len(p.vertices) - 2 for p in mesh.polygons)
    evaluated.to_mesh_clear()
    return points, triangles


def multiset_error(source, target):
    if len(source) != len(target): raise ValueError('Rest vertex counts differ')
    cell = lambda p: tuple(math.floor(x * 100000) for x in p)
    buckets = {}
    for i, p in enumerate(target): buckets.setdefault(cell(p), []).append(i)
    used = set(); maximum = 0
    for p in source:
        c = cell(p); best = None
        for offset in itertools.product((-1, 0, 1), repeat=3):
            for i in buckets.get(tuple(a + b for a, b in zip(c, offset)), []):
                if i in used: continue
                distance = (p - target[i]).length
                if distance < 1e-6 and (best is None or distance < best[1]): best = (i, distance)
        if best is None: raise ValueError('Actual rest geometry multiset differs')
        used.add(best[0]); maximum = max(maximum, best[1])
    return maximum


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--previous', required=True, type=Path)
parser.add_argument('--candidate', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--equipment-change', choices=['rogue'], help='Explicitly report deliberate Rogue pouch relocation; do not claim v06 rest equivalence')
args = parser.parse_args(sys.argv[sys.argv.index('--') + 1:]); args.output.mkdir(parents=True, exist_ok=True)
rows = []
for hero in ['warrior', 'mage', 'rogue']:
    original, old_triangles = geometry(args.previous, hero)
    current, triangles = geometry(args.candidate, hero)
    error = None if hero == args.equipment_change else multiset_error(original, current)
    if triangles != old_triangles: raise ValueError('Rest triangle count changed')
    scene = bpy.context.scene; obj = bpy.data.objects[hero.title() + '_Skin']; rig = bpy.data.objects[hero.title() + '_Rig']
    part_map = json.loads(obj['editable_part_map'])
    cape_indices = [i for p in part_map if p['bone'] == 'cape' for i in range(p['offset'], p['offset'] + p['vertices'])]
    cape_group = obj.vertex_groups['cape'].index
    pinned = [i for i in cape_indices if not any(g.group == cape_group and g.weight > 0 for g in obj.data.vertices[i].groups)]
    if not pinned: raise ValueError('No body-pinned shoulder vertices')
    attachment = []
    for frame in [0, 6, 12, 21, 29, 35, 42]:
        scene.frame_set(frame); bpy.context.view_layer.update()
        evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get()); mesh = evaluated.to_mesh()
        body = rig.matrix_world @ rig.pose.bones['body'].matrix @ rig.data.bones['body'].matrix_local.inverted()
        maximum = max(((evaluated.matrix_world @ mesh.vertices[i].co) - (body @ obj.data.vertices[i].co)).length for i in pinned)
        attachment.append({'frame': frame, 'pinnedVertices': len(pinned), 'maxBodyAttachmentErrorMeters': maximum})
        evaluated.to_mesh_clear()
        if maximum > 1e-6: raise ValueError('Cape shoulder detached from body')
    peak_frame = 35 if hero == 'warrior' else 29
    camera = scene.camera
    for frame, label in [(0, 'rest'), (peak_frame, 'peak')]:
        scene.frame_set(frame)
        for side, position in [('back', (-2.3, 4.5, 2.5)), ('side', (4.5, .4, 2.4))]:
            camera.location = position
            camera.rotation_euler = (Vector((0, 0, .72)) - camera.location).to_track_quat('-Z', 'Y').to_euler()
            scene.render.filepath = str((args.output / (hero + '-' + label + '-' + side + '.png')).resolve())
            bpy.ops.render.render(write_still=True)
    rows.append({'hero': hero, 'restVertices': len(current), 'triangles': triangles,
                 'completeRestVertexMultisetErrorMeters': error, 'pinnedShoulderChecks': attachment,
                 'v06RestGeometryEquivalent': error is not None,
                 'restComparisonNotClaimedReason': 'deliberate side-hip pouch relocation; compare to final native source in build-report' if error is None else None,
                 'reviewPeakFrame': peak_frame, 'blendFileModified': False, 'passed': True})
(args.output / 'cape-review-verification.json').write_text(json.dumps({'results': rows,
    'claim': 'actual evaluated rest multiset and body-pinned shoulder vertices; back/side pixels separately reviewed; no cloth physics'}, indent=2) + '\n')
