#!/usr/bin/env python3
"""Fresh actual native idle pose and mounted-gallery restoration checks."""
import argparse, hashlib, json, shutil, subprocess, time
from pathlib import Path
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--device', required=True); p.add_argument('--output', type=Path, required=True)
p.add_argument('--app', type=Path, default=Path('ios/Build/Products/Debug-iphonesimulator/TacticalGo.app'))
a = p.parse_args()
if a.output.exists(): raise SystemExit('Use fresh output; previous attempts remain reviewable')
a.output.mkdir(parents=True)
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
inputs = lambda app: {'librarySHA256': sha(app/'TacticalGo.debug.dylib'), 'models': {x.name: sha(x) for x in (app/'Models').glob('*.usdz')}}
bundle = 'com.tacticalgo.prototype'; before = inputs(a.app)
subprocess.run(['xcrun','simctl','terminate',a.device,bundle], capture_output=True)
subprocess.run(['xcrun','simctl','install',a.device,str(a.app)], check=True)
container = Path(subprocess.check_output(['xcrun','simctl','get_app_container',a.device,bundle,'data'], text=True).strip())
installed = Path(subprocess.check_output(['xcrun','simctl','get_app_container',a.device,bundle,'app'], text=True).strip())
if inputs(installed) != before: raise SystemExit('Installed input mismatch')
source = container/'Documents/idle-pose-verification.json'
if source.exists(): shutil.copy2(source,a.output/'prior-idle-pose-verification.json'); source.unlink()
started = time.time(); flags = ['--verify-idle']
with (a.output/'launch.log').open('w') as log:
    launch = subprocess.check_output(['xcrun','simctl','launch',a.device,bundle,*flags], text=True); log.write(launch)
pid = int(launch.rsplit(':',1)[1])
(a.output/'launch-inputs.json').write_text(json.dumps({'pid':pid,'startedAtUnix':started,'device':a.device,'flags':flags,'inputs':before},indent=2)+'\n')
for _ in range(90):
    processes = subprocess.check_output(['xcrun','simctl','spawn',a.device,'launchctl','list'],text=True)
    if not any(line.split() and line.split()[0] == str(pid) for line in processes.splitlines()): raise SystemExit('Native app exited; incomplete attempt retained')
    if source.exists() and source.stat().st_mtime > started: break
    time.sleep(1)
else: raise SystemExit('Fresh native output missing; incomplete attempt retained')
shutil.copy2(source, a.output/source.name); data = json.loads(source.read_text()); rows = data['results']
if inputs(a.app) != before or inputs(installed) != before: raise SystemExit('Inputs changed during native verification')
assert len(rows)==327 and all(row['passed'] for row in rows), 'Native idle checks failed; raw outputs retained'
assert sum('frame' in row for row in rows)==309 and sum(row.get('ending')=='direct-reset' for row in rows)==3
for hero in ['Warrior','Mage','Rogue']:
    assert [r['frame'] for r in rows if r['hero']==hero and 'frame' in r]==list(range(103))
    assert {r['ending'] for r in rows if r['hero']==hero and 'ending' in r}=={'direct-reset','stop','attack','hero-change','leave','reduced'}
report = {'passed':True,'cases':len(rows),'poseSamples':309,'directResets':3,'mountedEndings':15,
          'maxNativeError':max(r['maxNativeError'] for r in rows if 'frame' in r),
          'claim':'actual native imported/source sockets and lifecycle checks; rendered UI and physical device remain separate'}
(a.output/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
