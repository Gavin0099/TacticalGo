#!/usr/bin/env python3
"""Run inside Blender: sample real atlas UV corners/centers and render unlit QA.

The authored AO floor is 0.70. A color sample below 0.55 of its material's
dominant linear channel indicates missing/foreign texel coverage, not lighting.
This is a bounded atlas-coverage diagnostic, not a complete texture-quality gate.
"""
import argparse
from array import array
import json
import math
from pathlib import Path
import sys

import bpy

sys.path.insert(0, str(Path(__file__).resolve().parent))
from surface_colors import srgb_to_linear

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('directory', type=Path)
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args(sys.argv[sys.argv.index('--') + 1:])
args.output.mkdir(parents=True, exist_ok=True)
results = []
for hero in ('warrior', 'mage', 'rogue'):
    bpy.ops.wm.open_mainfile(filepath=str((args.directory / (hero + '.blend')).resolve()))
    bpy.context.scene.frame_set(0)
    obj = next(o for o in bpy.data.objects if o.type == 'MESH')
    atlas = next(i for i in bpy.data.images if i.name.endswith('_Original_Surface_Atlas'))
    width, height = atlas.size
    pixels = array('f', [0]) * len(atlas.pixels); atlas.pixels.foreach_get(pixels)
    uv = obj.data.uv_layers.active.data
    bad, sampled = [], 0
    for face in obj.data.polygons:
        if face.area < 1e-10: continue
        mat = obj.data.materials[face.material_index]
        shader = mat.node_tree.nodes.get('Principled BSDF')
        base = shader.inputs['Base Color'].default_value[:3]
        channel = max(range(3), key=lambda c: base[c])
        if base[channel] < .01: continue
        coords = [uv[i].uv[:] for i in face.loop_indices]
        samples = coords + [tuple(sum(p[c] for p in coords) / len(coords) for c in (0, 1))]
        for point in samples:
            x, y = point[0] * width - .5, point[1] * height - .5
            ix, iy = math.floor(x), math.floor(y); fx, fy = x - ix, y - iy
            value = 0
            for dx, dy, weight in ((0, 0, (1-fx)*(1-fy)), (1, 0, fx*(1-fy)), (0, 1, (1-fx)*fy), (1, 1, fx*fy)):
                px, py = max(0, min(width-1, ix+dx)), max(0, min(height-1, iy+dy))
                encoded = pixels[(py * width + px) * 4 + channel]
                value += (encoded if atlas.is_float else srgb_to_linear(encoded)) * weight
            ratio = value / base[channel]; sampled += 1
            if ratio < .55: bad.append({'face': face.index, 'material': mat.name, 'uv': point, 'ratio': ratio})
    results.append({'hero': hero, 'samples': sampled, 'belowFloorSamples': len(bad), 'examples': bad[:24],
                    'claim': 'bilinear texture coverage only; does not include native metallic or shadow behavior'})
    # Unlit surface render isolates baked texture color from light/shadow artifacts.
    for mat in obj.data.materials:
        nodes, links = mat.node_tree.nodes, mat.node_tree.links
        target = nodes.get('Original_Surface_Atlas')
        emission = nodes.new('ShaderNodeEmission')
        links.new(target.outputs['Color'], emission.inputs['Color'])
        links.new(emission.outputs[0], nodes.get('Material Output').inputs['Surface'])
    bpy.context.scene.cycles.samples = 8
    bpy.context.scene.render.filepath = str((args.output / (hero + '-unlit-atlas.png')).resolve())
    bpy.ops.render.render(write_still=True)
report = {'results': results, 'diagnosticOnly': True}
(args.output / 'coverage-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
