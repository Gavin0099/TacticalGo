"""Repair construction-selection baking and restore matching skin modifiers before likeness review."""
import bpy,json,hashlib
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];out=root/'assets/candidates/ios-identity-v01/warrior-refined';out.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(root/'assets/candidates/ios-identity-v01/warrior/warrior.blend'))
scene=bpy.context.scene;rig=bpy.data.objects['Warrior_Identity_Rig'];parts=[o for o in scene.objects if o.type=='MESH']
fix=[]
for o in parts:
 if not any(m.type=='ARMATURE' for m in o.modifiers):
  mod=o.modifiers.new('Restored identity binding','ARMATURE');mod.object=rig;fix.append(o.name)
# Keep genuine strand lofts, add controlled subdivision for rounded wave continuity.
for o in parts:
 if any(w in o.name.lower() for w in ['fringe','wave','curl']):
  m=o.modifiers.new('Controlled wave subdivision','SUBSURF');m.levels=2;m.render_levels=2
# Constant-width torso/cape and source lowpoly silhouettes remain candidates.
scene.frame_set(1);scene.cycles.samples=24;scene.render.resolution_x=800;scene.render.resolution_y=1000
bpy.ops.wm.save_as_mainfile(filepath=str(out/'warrior.blend'))
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=rig
usd=out/'warrior-rig.usda';bpy.ops.wm.usd_export(filepath=str(usd),selected_objects_only=True,export_animation=True,export_armatures=True,only_deform_bones=True,export_shapekeys=False,export_lights=False,export_cameras=False,export_normals=True,export_uvmaps=True,export_textures_mode='NEW',export_subdivision='IGNORE',generate_preview_surface=True,convert_orientation=True,export_global_up_selection='Y',root_prim_path='/WarriorIdentity',convert_world_material=False)
for frame,label in [(1,'rest'),(26,'idle-mid')]:
 scene.frame_set(frame)
 for side,loc in [('front',(0,-6,2.3)),('three-quarter',(3.1,-6.4,2.6)),('back',(3.1,6.4,2.6))]:
  cam=scene.camera;cam.location=loc;cam.rotation_euler=(Vector((0,0,1.10))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(label+'-'+side+'.png'));bpy.ops.render.render(write_still=True)
report={'repairedMeshBindings':fix,'joints':list(rig.data.bones.keys()),'frames':[1,26],'sourceBlendSHA256':hashlib.sha256((out/'warrior.blend').read_bytes()).hexdigest(),'notClaimed':['Owner approval','final art','main gameplay 23-joint compatibility','physical device']};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('REFINED_IDENTITY_COMPLETE',report)
