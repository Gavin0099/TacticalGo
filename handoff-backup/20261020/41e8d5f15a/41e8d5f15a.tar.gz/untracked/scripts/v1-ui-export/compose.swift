import AppKit
let root = URL(fileURLWithPath: CommandLine.arguments[1])
let phases = ["normal", "preview", "danger"]
let names = ["一般局面", "技能預覽", "主將危險"]
for size in [7, 9] {
    let w = 1242, h = 1588
    let rep = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: w, pixelsHigh: h, bitsPerSample: 8, samplesPerPixel: 4,
                              hasAlpha: true, isPlanar: false, colorSpaceName: .calibratedRGB, bytesPerRow: 0, bitsPerPixel: 0)!
    NSGraphicsContext.saveGraphicsState(); NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: rep)
    NSColor(red: 0.04, green: 0.08, blue: 0.10, alpha: 1).setFill(); NSRect(x: 0, y: 0, width: w, height: h).fill()
    let attrs: [NSAttributedString.Key: Any] = [.font:NSFont.systemFont(ofSize:16,weight:.semibold),.foregroundColor:NSColor.white]
    ("TacticalGo V1 · \(size)×\(size) · 靜態設計稿 / 非 iOS 截圖" as NSString).draw(at:NSPoint(x:20,y:h-30),withAttributes:attrs)
    for (row, dimension) in [(390,844),(320,568)].enumerated() {
        let top = row == 0 ? 68 : 968
        for (col, phase) in phases.enumerated() {
            let x = 20 + 410 * col
            ("\(dimension.0)×\(dimension.1) · \(names[col])" as NSString).draw(at:NSPoint(x:x,y:h-top+8),withAttributes:attrs)
            let image = NSImage(contentsOf:root.appendingPathComponent("screens/\(dimension.0)-\(size)-\(phase).png"))!
            image.draw(in:NSRect(x:x,y:h-top-dimension.1,width:dimension.0,height:dimension.1),from:.zero,operation:.sourceOver,fraction:1)
        }
    }
    NSGraphicsContext.restoreGraphicsState()
    try rep.representation(using:.png,properties:[:])!.write(to:root.appendingPathComponent("comparison-\(size).png"))
}
