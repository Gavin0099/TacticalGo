import Foundation

func coord(_ p: Point) -> String { String(UnicodeScalar(65 + p.x)!) + String(p.y + 1) }
func points(_ set: Set<Point>) -> [[Int]] { set.sorted { $0.y == $1.y ? $0.x < $1.x : $0.y < $1.y }.map { [$0.x, $0.y] } }
func pieces(_ board: Board) -> [[String: Any]] {
    board.points.compactMap { p in
        guard let piece = board[p] else { return nil }
        let kind = piece.kind == .soldier ? "soldier" : piece.kind == .hero ? "hero" : "commander"
        return ["x": p.x, "y": p.y, "owner": piece.owner == .one ? "black" : "white", "kind": kind]
    }
}
var scenes: [[String: Any]] = []
for size in [7, 9] {
    for phase in ["normal", "preview", "danger"] {
        var diagram: String
        let hero: HeroClass, enemy: HeroClass
        switch phase {
        case "normal":
            diagram = "..oO.o.\n...oQ..\n.oo....\n..x.o..\n.xHox..\n..xXx..\n......."; hero = .rogue; enemy = .mage
        case "preview":
            diagram = "..oO.o.\n...oQ..\n.oo....\n..xHo..\n.x...x.\n..xXx..\n......."; hero = .mage; enemy = .warrior
        default:
            diagram = "..oO.o.\n...oQ..\n.......\n..Hx...\n..ooo..\n..oXo..\n......."; hero = .warrior; enemy = .mage
        }
        let offset = size == 9 ? 1 : 0
        if size == 9 { diagram = (["........."] + diagram.split(separator: "\n").map { "." + $0 + "." } + ["........."]).joined(separator: "\n") }
        let state = try GameSetup.fromDiagram(config: .board(size: size), diagram: diagram, classOne: hero,
                                              classTwo: enemy, manaOne: 5, manaTwo: 4, ap: 2, ply: 15)
        precondition(state.config.bastionScope == .heroAdjacent && state.config.magicHandDestination == .emptyOnly)
        precondition(state.board.points.filter { state.board[$0] != nil }.allSatisfy { !state.board.liberties(at: $0).isEmpty })
        let commander = state.board.find(.one, .commander)!, other = state.board.find(.two, .commander)!
        let legal = GameEngine.legalActions(state)
        let soldierTargets: Set<Point> = Set(legal.compactMap { if case .placeSoldier(let p) = $0 { return p }; return nil })
        let skillActions = legal.filter { switch $0 { case .castBastion, .castMagicHand, .castSwap: true; default: false } }
        let skillTargets: Set<Point> = Set(skillActions.flatMap { action -> [Point] in
            switch action { case .castBastion(let a, let b): [a, b]; case .castMagicHand(let p, _), .castSwap(let p): [p]; default: [] }
        })
        var scene: [String: Any] = ["id": "\(size)-\(phase)", "phase": phase, "size": size, "ply": state.ply,
            "hero": hero.rawValue.lowercased(), "enemyHero": enemy.rawValue.lowercased(), "pieces": pieces(state.board),
            "diagram": state.board.diagram, "ap": state.apRemaining, "mana": state.mana(of: .one), "manaCap": state.config.manaCap,
            "enemyMana": state.mana(of: .two), "commanderLiberties": points(state.board.liberties(at: commander)),
            "enemyLiberties": state.board.liberties(at: other).count, "legalSoldiers": points(soldierTargets),
            "legalSkillTargets": points(skillTargets), "legalSkills": skillActions.count, "heroAt": [state.board.find(.one, .hero)!.x, state.board.find(.one, .hero)!.y]]
        if phase == "preview" {
            let from = Point(4 + offset, 3 + offset), to = Point(4 + offset, 2 + offset)
            let action = GameAction.castMagicHand(from, .up), outcome = GameEngine.apply(state, action)
            precondition(outcome.success && outcome.state.current == .one && outcome.state.apRemaining == 1 && outcome.state.mana(of: .one) == 3)
            precondition(outcome.state.board[from] == nil && outcome.state.board[to] == Piece(.two, .soldier))
            precondition(outcome.events == [.resourcesSpent(.one, ap: 1, mana: 2), .piecePushed(caster: .one, from: from, to: to, piece: Piece(.two, .soldier))])
            scene["preview"] = ["from": [from.x, from.y], "to": [to.x, to.y], "label": coord(from) + " → " + coord(to),
                "postAP": outcome.state.apRemaining, "postMana": outcome.state.mana(of: .one), "pieces": pieces(outcome.state.board),
                "events": outcome.events.map { $0.name }, "captures": 0,
                "validDirections": PushDirection.allCases.filter { GameEngine.validate(state, .castMagicHand(from, $0)) == .none }.map { $0.rawValue }]
            var session = GameSession(state); _ = session.apply(action); precondition(session.undo() && session.state == state)
        }
        if phase == "danger" {
            let liberties = state.board.liberties(at: commander)
            precondition(liberties.count == 1)
            let escape = liberties.first!, result = GameEngine.apply(state, .placeSoldier(escape))
            precondition(result.success && result.state.board.liberties(at: commander).count > 1)
            scene["escape"] = ["point": [escape.x, escape.y], "label": coord(escape), "postLiberties": result.state.board.liberties(at: commander).count]
        }
        scenes.append(scene)
    }
}
let data = try JSONSerialization.data(withJSONObject: scenes, options: [.prettyPrinted, .sortedKeys])
FileHandle.standardOutput.write(data); print("")
