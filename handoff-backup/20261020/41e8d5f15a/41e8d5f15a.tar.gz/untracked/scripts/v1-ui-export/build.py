#!/usr/bin/env python3
"""Build static V1 design previews from unchanged art and real Swift rule outcomes.
These are WebKit design screenshots, never iOS simulator or device evidence.
"""
from pathlib import Path
import base64, hashlib, json, shutil, subprocess
root = Path(__file__).resolve().parents[2]
source = Path(__file__).resolve().parent
out = root / 'artifacts/ios/v1-a0-ui'
out.mkdir(parents=True, exist_ok=True)
(out/'assets').mkdir(exist_ok=True); (out/'screens').mkdir(exist_ok=True)
with (out/'build.log').open('w') as log:
    subprocess.run(['swiftc', *map(str, sorted((root/'swift/TacticalGoCore/Sources/TacticalGoCore').glob('*.swift'))), str(source/'main.swift'), '-o', str(out/'export-scenes')], check=True, stdout=log, stderr=log)
    data = subprocess.check_output([str(out/'export-scenes')])
    scenes = json.loads(data)
    assert len(scenes) == 6
    (out/'scenes.json').write_bytes(data)
    subprocess.run(['swiftc', '-parse-as-library', str(source/'render-web.swift'), '-o', str(out/'render-web')], check=True, stdout=log, stderr=log)
assets = {}
art = {}
for hero in ['warrior', 'mage', 'rogue']:
    for kind, file, folder in [('card', 'portrait.png', hero), ('token', 'token.png', 'token-'+hero)]:
        original = root/'ios/TacticalGo/Assets.xcassets'/(folder+'.imageset')/file
        name = hero+'-'+kind
        target = out/'assets'/(name+'.png')
        shutil.copyfile(original, target)
        assert original.read_bytes() == target.read_bytes()
        assets[name] = {'source':str(original.relative_to(root)), 'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
        art[name] = 'data:image/png;base64,'+base64.b64encode(target.read_bytes()).decode()
html=(source/'review.template.html').read_text().replace('__SCENES__',data.decode()).replace('__ART__',json.dumps(art))
(out/'review.html').write_text(html)
manifest={'source':'WebKit screenshots of a static HTML/SVG V1 design; not native iOS screenshots', 'assets':assets, 'screens':[]}
with (out/'render.log').open('w') as log:
    for width,height in [(390,844),(320,568)]:
        for size in [7,9]:
            for phase in ['normal','preview','danger']:
                name=f'{width}-{size}-{phase}'
                url=(out/'review.html').as_uri()+f'?scene={phase}&board={size}&width={width}&height={height}'
                subprocess.run([str(out/'render-web'),url,str(width),str(height),str(out/'screens'/(name+'.png'))],check=True,stdout=log,stderr=log,timeout=35)
                audit=json.loads((out/'screens'/(name+'.json')).read_text())
                assert audit.get('ready') is True, audit
                item=audit['audit'][0]
                assert item['headerFits'] and item['footerVisible'] and not item['overflow'] and item['imagesLoaded'], item
                assert all(c['height']>=44 and c['width']>=44 for c in item['controls']), item
                item['png']=name+'.png'; item['sha256']=hashlib.sha256((out/'screens'/(name+'.png')).read_bytes()).hexdigest()
                manifest['screens'].append(item)
                print('PASS',name,'board',item['boardWidth'],item['boardHeight'],'min grid',round(min(item['minRowSpacing'],item['minColumnSpacing']),2),flush=True)
subprocess.run(['swiftc',str(source/'compose.swift'),'-o',str(out/'compose')],check=True)
subprocess.run([str(out/'compose'),str(out)],check=True)
manifest['core_sources']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'swift/TacticalGoCore/Sources/TacticalGoCore').glob('*.swift')}
manifest['sources']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.is_file()}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print('12 design PNGs and layout audits saved. Owner visual and native touch acceptance remain pending.')
