import AppKit
import WebKit

@MainActor final class Renderer: NSObject, WKNavigationDelegate {
    let view: WKWebView
    let window: NSWindow
    let output: URL
    let width: Int
    let height: Int
    var finished = false
    init(url: URL, width: Int, height: Int, output: URL) {
        self.width = width; self.height = height; self.output = output
        view = WKWebView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        window = NSWindow(contentRect: NSRect(x: -10000, y: -10000, width: width, height: height), styleMask: [.borderless], backing: .buffered, defer: false)
        super.init(); window.contentView = view; window.orderFront(nil); view.navigationDelegate = self
        view.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        DispatchQueue.main.asyncAfter(deadline: .now() + 30) { if !self.finished { fputs("Timed out rendering V1 HTML\n", stderr); exit(1) } }
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.view.evaluateJavaScript("JSON.stringify({ready:window.__ready,error:window.__error,audit:window.auditLayout()})") { value, error in
                guard error == nil, let json = value as? String, json.contains("\"ready\":true") else { fputs("DOM audit failed\n", stderr); exit(1) }
                do { try json.write(to: self.output.deletingPathExtension().appendingPathExtension("json"), atomically: true, encoding: .utf8) } catch { exit(1) }
                let config = WKSnapshotConfiguration(); config.rect = NSRect(x: 0, y: 0, width: self.width, height: self.height)
                self.view.takeSnapshot(with: config) { image, error in
                    guard error == nil, let image, let cg = image.cgImage(forProposedRect: nil, context: nil, hints: nil),
                          let context = CGContext(data: nil, width: self.width, height: self.height, bitsPerComponent: 8, bytesPerRow: 0,
                                                  space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { exit(1) }
                    context.draw(cg, in: CGRect(x: 0, y: 0, width: self.width, height: self.height))
                    guard let result = context.makeImage(), let data = NSBitmapImageRep(cgImage: result).representation(using: .png, properties: [:]) else { exit(1) }
                    do { try data.write(to: self.output) } catch { exit(1) }
                    self.finished = true; print("Rendered \(self.width)×\(self.height): \(self.output.lastPathComponent)"); exit(0)
                }
            }
        }
    }
}
@main struct RenderMain {
    @MainActor static func main() {
        let args = CommandLine.arguments
        precondition(args.count == 5, "render-web URL WIDTH HEIGHT OUTPUT")
        let app = NSApplication.shared; app.setActivationPolicy(.accessory)
        let renderer = Renderer(url: URL(string: args[1])!, width: Int(args[2])!, height: Int(args[3])!, output: URL(fileURLWithPath: args[4]))
        withExtendedLifetime(renderer) { app.run() }
    }
}
