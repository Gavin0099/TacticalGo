"""Static, editable B-warrior-v02 head/chest correction. No game/rig/action/lower body.
Single identity source is the surviving exact 512 derivative; high-res master unavailable.
"""
import bpy,bmesh,math,json,hashlib
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];out=root/'assets/candidates/warrior-bust-bv02-v01';out.mkdir(exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True);scene=bpy.context.scene
materials={};headParts=[]
def material(name,c,metal=0,rough=.62,grain=.002):
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True;n=m.node_tree.nodes;s=n.get('Principled BSDF');s.inputs['Base Color'].default_value=(*c,1);s.inputs['Metallic'].default_value=metal;s.inputs['Roughness'].default_value=rough
 if grain:
  tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=115;tex.inputs['Detail'].default_value=2;b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=.17;b.inputs['Distance'].default_value=grain;m.node_tree.links.new(tex.outputs['Fac'],b.inputs['Height']);m.node_tree.links.new(b.outputs['Normal'],s.inputs['Normal'])
 materials[name]=m;return m
skin=material('Warm peach skin',(.73,.365,.19),rough=.68,grain=.0006);darkskin=material('Ear and lip warm shadow',(.44,.16,.08),rough=.72);hair=material('Chestnut root',(.13,.038,.012),rough=.58);hairlit=material('Chestnut golden strand',(.23,.075,.022),rough=.6);hairdark=material('Deep hair grooves',(.07,.019,.006),rough=.67);brown=material('Brows and smile',(.06,.019,.009),rough=.7);freckle=material('Freckles',(.31,.11,.055),rough=.8);ivory=material('Eye ivory',(.9,.85,.72),rough=.34,grain=0);iris=material('Brown iris',(.22,.073,.012),rough=.32,grain=0);pupil=material('Pupil',(.008,.004,.003),rough=.29,grain=0);teal=material('Woven deep teal',(.022,.15,.18),rough=.85,grain=.003);tealhi=material('Raised teal folds',(.032,.22,.26),rough=.85,grain=.003);cream=material('Cream linen',(.72,.63,.46),rough=.89,grain=.003);silver=material('Brushed silver pauldron',(.45,.48,.49),.8,.34);rim=material('Bright polished steel edging',(.61,.64,.65),.83,.24);steelshade=material('Recessed steel seam',(.16,.20,.22),.7,.42);gold=material('Warm gold hardware',(.73,.39,.08),.76,.28);leather=material('Chestnut leather glove',(.17,.065,.025),rough=.75,grain=.002);leatherhi=material('Leather seam highlights',(.27,.11,.041),rough=.73);blade=material('Steel blade face',(.57,.63,.67),.88,.25)
def mesh(name,v,f,m,smooth=True,bevel=0):
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);me.materials.append(m);bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free()
 for p in me.polygons:p.use_smooth=smooth
 if bevel:
  mod=o.modifiers.new('Crafted edge radius','BEVEL');mod.width=bevel;mod.segments=3
  o.modifiers.new('Weighted edge normals','WEIGHTED_NORMAL')
 return o
def sphere(name,p,s,m,head=False):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=40,ring_count=24,location=p);o=bpy.context.object;o.name=name;o.scale=s;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 for p in o.data.polygons:p.use_smooth=True
 if head:headParts.append(o)
 return o
def tube(name,points,radius,m,radii=None,head=False):
 bpy.ops.object.select_all(action='DESELECT');cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=20;cu.bevel_depth=radius;cu.bevel_resolution=4;cu.use_fill_caps=True;s=cu.splines.new('BEZIER');s.bezier_points.add(len(points)-1)
 for i,(b,p) in enumerate(zip(s.bezier_points,points)):b.co=p;b.handle_left_type='AUTO';b.handle_right_type='AUTO';b.radius=radii[i] if radii else 1
 o=bpy.data.objects.new(name,cu);scene.collection.objects.link(o);o.data.materials.append(m);bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o=bpy.context.object
 for p in o.data.polygons:p.use_smooth=True
 if head:headParts.append(o)
 return o
def loft(name,rows,m,head=False,sub=1):
 n=64;v=[];f=[]
 for z,rx,ry,cy in rows:
  for i in range(n):a=2*math.pi*i/n;v.append((math.cos(a)*rx,cy+math.sin(a)*ry,z))
 for k in range(len(rows)-1):
  for i in range(n):j=(i+1)%n;f.append((k*n+i,k*n+j,(k+1)*n+j,(k+1)*n+i))
 f.extend([tuple(reversed(range(n))),tuple((len(rows)-1)*n+i for i in range(n))]);o=mesh(name,v,f,m)
 if sub:mod=o.modifiers.new('Face and cloth continuity','SUBSURF');mod.levels=sub
 if head:headParts.append(o)
 return o
def slab(name,poly,depth,m,bevel=.006):
 n=len(poly);v=poly+[(x,y+depth,z) for x,y,z in poly];f=[tuple(reversed(range(n))),tuple(n+i for i in range(n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)];return mesh(name,v,f,m,False,bevel)
# The jaw and nose are authored for the portrait, not a stock baby-face mesh.
loft('Head tapered cheek and confident jaw',[(1.54,.065,.065,-.075),(1.57,.16,.11,-.068),(1.63,.245,.16,-.05),(1.75,.34,.22,-.028),(1.89,.393,.265,0),(2.06,.398,.272,.007),(2.24,.372,.25,.01),(2.36,.28,.19,.012),(2.41,.10,.065,.016)],skin,True,2)
loft('Neck rising above scarf',[(1.25,.17,.14,.025),(1.40,.18,.145,.025),(1.59,.16,.14,.038)],skin)
for sign in [-1,1]:
 o=sphere('Ear shell '+str(sign),(sign*.385,.002,1.95),(.107,.062,.14),skin,True);o.rotation_euler.y=sign*-.18
 sphere('Ear inner bowl '+str(sign),(sign*.416,-.047,1.958),(.060,.016,.082),darkskin,True)
 tube('Ear folded rim '+str(sign),[(sign*.390,-.065,1.866),(sign*.455,-.053,1.944),(sign*.448,-.040,2.018),(sign*.40,-.05,2.027)],.013,skin,head=True)
# Horizontal almond lens, closed back; outer corners are not circular eyeballs.
for sign in [-1,1]:
 cx=sign*.17;cz=2.022 if sign==1 else 2.005;n=64;verts=[(cx,-.307,cz)];faces=[]
 for k in range(1,9):
  r=k/8
  for i in range(n):
   a=2*math.pi*i/n;dx=math.cos(a)*.117*r;dz=math.sin(a)*(.076 if math.sin(a)>0 else .059)*r+sign*dx*.15;yy=-.297-.031*(1-r*r);verts.append((cx+dx,yy,cz+dz))
 for i in range(n):faces.append((0,1+i,1+(i+1)%n))
 for k in range(7):
  for i in range(n):j=(i+1)%n;faces.append((1+k*n+i,1+k*n+j,1+(k+1)*n+j,1+(k+1)*n+i))
 o=mesh('Almond eye seated '+str(sign),verts,faces,ivory);mod=o.modifiers.new('Closed eyeball depth','SOLIDIFY');mod.thickness=.012;headParts.append(o)
 sphere('Iris focused '+str(sign),(cx+.018,-.331,cz+.002),(.049,.014,.057),iris,True);sphere('Pupil '+str(sign),(cx+.020,-.343,cz+.003),(.024,.009,.037),pupil,True);sphere('Upper eye sparkle '+str(sign),(cx+.003,-.353,cz+.025),(.014,.004,.019),ivory,True)
 tube('Upper sharp eyelid '+str(sign),[(cx-.116,-.297,cz-sign*.017),(cx-.065,-.320,cz+.065),(cx+.016,-.324,cz+.076),(cx+.116,-.294,cz+sign*.017)],.009,brown,[.55,.9,1.1,.45],True)
 tube('Lower skin lid '+str(sign),[(cx-.114,-.291,cz-.008),(cx-.013,-.309,cz-.058),(cx+.110,-.291,cz+.005)],.009,skin,[.4,.8,.4],True)
 if sign==1:points=[(.065,-.275,2.160),(.135,-.282,2.218),(.235,-.267,2.257),(.286,-.248,2.210)];widths=[.60,1,1,.12]
 else:points=[(-.295,-.231,2.171),(-.240,-.267,2.180),(-.157,-.281,2.174),(-.065,-.277,2.136)];widths=[.18,.85,1,.50]
 tube('Thick angular brow '+str(sign),points,.026,brown,widths,True)
 for x,z,r in [(0,0,.0045),(.026,.017,.005),(.054,-.003,.004),(.077,.015,.0035)]:sphere('Cheek freckle '+str(sign)+str(x),(sign*(.185+x),-.254+x*.40,1.862+z), (r,.0025,r),freckle,True)
# Rounded but defined bridge + nostril wings; asymmetrical upward smile.
sphere('Nose bridge',(.003,-.274,1.946),(.038,.037,.082),skin,True);sphere('Nose tip',(.011,-.313,1.906),(.064,.060,.039),skin,True)
for sign in [-1,1]:sphere('Nostril recess '+str(sign),(sign*.045,-.318,1.887),(.011,.0035,.006),darkskin,True)
tube('Asymmetric assured smile',[(-.127,-.225,1.745),(-.063,-.267,1.730),(.021,-.276,1.743),(.099,-.255,1.779),(.155,-.218,1.823)],.009,brown,[.45,.75,.9,.85,.45],True)
tube('Smile cheek dimple',[(.141,-.216,1.817),(.163,-.214,1.821),(.170,-.210,1.812)],.006,brown,head=True)
tube('Lower lip soft edge',[(-.074,-.270,1.709),(.008,-.281,1.721),(.063,-.263,1.741)],.011,skin,[.2,.8,.2],True)
# Hair cap underneath sculpted waves; each wave varies its direction, crest and pointed tip.
sphere('Continuous hidden hair root',(0,.055,2.21),(.385,.293,.255),hair,True)
def wave(name,control,width,tint=hair,groove=True):
 points=[]
 for i in range(len(control)-1):
  p0=Vector(control[max(0,i-1)]);p1=Vector(control[i]);p2=Vector(control[i+1]);p3=Vector(control[min(len(control)-1,i+2)])
  for j in range(7):
   t=j/7;points.append(.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t))
 points.append(Vector(control[-1]));v=[];f=[];n=12
 for i,p in enumerate(points):
  t=i/(len(points)-1);tangent=(points[min(i+1,len(points)-1)]-points[max(0,i-1)]).normalized();a=tangent.cross(Vector((0,-1,0))).normalized();b=tangent.cross(a).normalized();radius=width*(.38+.62*math.sin(math.pi*min(t/.88,1))**.65)*(1-t**5);radius=max(radius,.002)
  for j in range(n):ang=math.tau*j/n;v.append(tuple(p+a*(math.cos(ang)*radius)+b*(math.sin(ang)*radius*.55)))
 for i in range(len(points)-1):
  for j in range(n):f.append((i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j))
 f.extend([tuple(reversed(range(n))),tuple((len(points)-1)*n+j for j in range(n))]);o=mesh(name,v,f,tint);headParts.append(o)
 if groove:
  ridge=[tuple(Vector(p)+Vector((0,-width*.51,0))) for p in control[1:-1]]
  if len(ridge)>1:tube(name+' curved strand ridge',ridge,.006,hairlit,[.15]+[.7]*(len(ridge)-2)+[.10],True)
 return o
waves=[
 ('Left sweeping forelock',[(.08,-.16,2.42),(-.06,-.29,2.55),(-.24,-.33,2.45),(-.31,-.33,2.27),(-.28,-.31,2.13)],.125),
 ('Center upward curl',[(.09,.04,2.42),(.12,-.08,2.64),(.01,-.09,2.75),(-.13,-.09,2.76),(-.04,-.10,2.68)],.14),
 ('Left crest flying curl',[(-.04,.02,2.40),(-.22,-.04,2.59),(-.41,-.02,2.57),(-.48,-.03,2.63),(-.45,-.04,2.73)],.125),
 ('Outer left wing',[(-.20,.09,2.31),(-.44,.015,2.40),(-.58,-.045,2.37),(-.66,-.06,2.44),(-.63,-.06,2.52)],.105),
 ('Left cheek curl',[(-.31,.02,2.26),(-.47,-.015,2.22),(-.54,-.06,2.08),(-.49,-.08,1.99),(-.53,-.08,1.95)],.092),
 ('Left fringe hook',[(-.15,-.23,2.40),(-.35,-.28,2.34),(-.39,-.25,2.16),(-.35,-.23,2.04),(-.33,-.23,2.15)],.105),
 ('Signature forehead curl',[(.12,-.14,2.45),(.05,-.30,2.49),(-.04,-.35,2.35),(-.04,-.33,2.20),(-.12,-.31,2.16)],.083),
 ('Right swept wave',[(.07,-.17,2.40),(.26,-.26,2.46),(.37,-.23,2.32),(.47,-.12,2.31),(.44,-.07,2.38)],.12),
 ('Right crown hook',[(.14,.03,2.44),(.34,.02,2.54),(.40,.04,2.62),(.31,.025,2.68),(.33,-.015,2.60)],.096),
 ('Right outer curl',[(.29,.12,2.34),(.46,.08,2.34),(.57,.02,2.27),(.62,.02,2.31),(.59,.02,2.37)],.083),
 ('Right temple curl',[(.33,-.09,2.25),(.42,-.15,2.13),(.41,-.10,2.03),(.39,-.06,2.08)],.083),
 ('Right ear outward wave',[(.32,.17,2.08),(.49,.13,2.03),(.55,.12,2.05),(.57,.10,2.13)],.083),
 ('Right nape hook',[(.23,.23,1.99),(.40,.21,1.89),(.52,.16,1.91),(.48,.12,1.96)],.073),
 ('Left back layered hook',[(-.27,.21,2.09),(-.40,.19,1.93),(-.43,.16,1.84),(-.47,.13,1.89)],.073)]
for i,(n,p,w) in enumerate(waves):wave(n,p,w,hairlit if i%3==0 else hair)
for sign in [-1,1]:
 for k in range(3):wave('Back crown flowing '+str(sign)+str(k),[(sign*.10,.25,2.38-k*.05),(sign*.28,.32,2.33-k*.12),(sign*.40,.28,2.22-k*.13),(sign*.44,.19,2.22-k*.14)],.07,hair,False)
# Confident slight head tilt belongs to the static object, not an animation.
bpy.ops.object.empty_add(location=(0,0,1.62));headRoot=bpy.context.object;headRoot.name='B-v02 head static tilt'
for o in headParts:world=o.matrix_world.copy();o.parent=headRoot;o.matrix_world=world
headRoot.rotation_euler.y=-.065
# Chest cropped at the same portrait level; no invented lower body.
loft('Portrait cream undercloth',[(.48,.33,.17,.04),(.70,.39,.19,.03),(1.01,.39,.19,.02),(1.28,.34,.17,.02),(1.40,.19,.14,.02)],cream)
loft('Teal cape over shoulders',[(.70,.46,.20,.08),(1.09,.52,.24,.09),(1.34,.42,.21,.08),(1.57,.25,.16,.045)],teal)
loft('High scarf collar',[(1.29,.28,.20,-.03),(1.47,.29,.22,-.018),(1.61,.235,.17,.04),(1.64,.19,.14,.04)],tealhi)
for k in range(3):
 z=1.30+k*.075;tube('Folded scarf drape '+str(k),[(-.32,-.145,z+.12),(-.20,-.25,z+.055),(.02,-.286,z),(.24,-.22,z+.10),(.36,-.12,z+.21)],.047-k*.005,tealhi if k%2==0 else teal,[.5,.9,1,.9,.5])
# Scarf tails rather than the invented diagonal chest strap.
slab('Scarf left trailing fabric',[(-.38,-.06,1.22),(-.52,-.16,1.05),(-.66,-.24,.88),(-.60,-.27,.74),(-.38,-.15,.98)],.04,teal,.025)
# Broad shaped silver shoulder shells, full physical volume and raised rim.
pauldron=[(.23,1.38),(.32,1.53),(.46,1.56),(.63,1.46),(.78,1.24),(.81,1.11),(.67,1.04),(.45,1.055),(.30,1.20)]
for sign in [-1,1]:
 center=Vector((.52,1.30));n=len(pauldron);v=[];f=[]
 for scale,yy in [(1,-.105),(.92,-.17),(.70,-.27),(.40,-.307)]:
  for x,z in pauldron:p=center+(Vector((x,z))-center)*scale;v.append((sign*p.x,yy,p.y))
 for k in range(3):
  for i in range(n):f.append((k*n+i,k*n+(i+1)%n,(k+1)*n+(i+1)%n,(k+1)*n+i))
 f.append(tuple(3*n+i for i in range(n)));f.append(tuple(reversed(range(n))));o=mesh('Broad forged pauldron '+str(sign),v,f,silver,True,.012)
 outline=[(sign*x,-.133,z) for x,z in pauldron]+[(sign*pauldron[0][0],-.133,pauldron[0][1])];tube('Pauldron raised silver rim '+str(sign),outline,.022,rim)
 seam=[(sign*(center.x+(x-center.x)*.88),-.180,center.y+(z-center.y)*.88) for x,z in pauldron];tube('Pauldron inner dark bevel '+str(sign),seam+[seam[0]],.007,steelshade)
 for x,z in [(.34,1.25),(.70,1.17)]:sphere('Armor rivet '+str(sign)+str(x),(sign*x,-.177,z),(.015,.011,.015),rim)
# Round gold brooch attached at scarf/pauldron junction.
brooch=sphere('Round gold scarf clasp',(-.285,-.325,1.37),(.093,.027,.104),gold)
tube('Brooch inset border',[(-.285+.071*math.cos(a),-.351,1.37+.08*math.sin(a)) for a in [i*math.tau/24 for i in range(25)]],.009,gold)
# Shield silhouette and crest follow B-v02 visible pixels, not a castle icon.
def shieldmap(p,y=-.49):x,z=p;return ((x-350)*.00405+.58,y,(484-z)*.00405+.48)
outer=[(250,334),(414,281),(468,312),(480,335),(478,397),(451,483),(302,484),(282,431),(260,372)]
inner=[(277,345),(414,300),(456,327),(462,344),(460,396),(437,480),(321,480),(301,430),(283,372)]
slab('Shield thick gold portrait outline',[shieldmap(p) for p in outer],.10,gold,.008)
slab('Shield deep teal recessed face',[shieldmap(p,-.515) for p in inner],.028,teal,.006)
trace=json.loads((out/'emblem-trace.json').read_text());slab('B-v02 traced gold branching relief',[shieldmap(p,-.555) for p in trace['outlinePixels']],.017,gold,.0015)
# Shield's visible embossed rim on the actual edge, blue field grain remains matte.
tube('Shield gold bevel line',[shieldmap(p,-.51) for p in outer+[outer[0]]],.006,gold)
# Right gauntlet, hand, sword are continuous and posed for the B portrait.
sphere('Under sleeve at right elbow',(-.53,-.06,1.01),(.20,.16,.22),cream)
sphere('Arm under steel bracer',(-.48,-.18,.82),(.165,.145,.19),leather)
a=Vector((-.55,-.13,.71));b=Vector((-.35,-.40,.97));axis=(b-a).normalized();u=axis.cross(Vector((0,1,0))).normalized();v2=axis.cross(u).normalized();n=32;v=[];f=[]
for center,r in [(a,.165),(b,.142)]:
 for i in range(n):ang=math.tau*i/n;v.append(tuple(center+u*(math.cos(ang)*r)+v2*(math.sin(ang)*r)))
for i in range(n):f.append((i,(i+1)%n,(i+1)%n+n,i+n))
f.extend([tuple(reversed(range(n))),tuple(n+i for i in range(n))]);mesh('Silver forearm bracer',v,f,silver,True,.008)
for name,center,r in [('Bracer cuff',b,.150),('Bracer elbow rim',a,.175)]:tube(name,[tuple(center+u*(math.cos(i*math.tau/32)*r)+v2*(math.sin(i*math.tau/32)*r)) for i in range(33)],.017,rim)
sphere('Right glove palm gripping hilt',(-.32,-.43,1.06),(.15,.092,.14),leather)
for k in range(3):
 z=.989+k*.075;tube('Curled grip finger '+str(k),[(-.435,-.49,z),(-.34,-.55,z+.01),(-.22,-.54,z+.01),(-.205,-.45,z),(-.27,-.405,z-.02)],.032,leather,[.8,1,1,.8,.45])
tube('Glove opposed thumb',[(-.44,-.475,1.13),(-.40,-.555,1.19),(-.30,-.56,1.18),(-.25,-.525,1.14)],.044,leather)
tube('Glove thumb stitch',[(-.428,-.521,1.125),(-.384,-.595,1.17),(-.308,-.602,1.161)],.0045,leatherhi)
tube('Visible leather sword grip',[(-.305,-.46,.91),(-.35,-.46,1.26)],.038,leather)
for k in range(5):
 z=1.205+k*.014;tube('Hilt leather wrap '+str(k),[(-.368,-.46,z),(-.352,-.493,z),(-.325,-.466,z)],.004,leatherhi)
sphere('Sword round gold pommel',(-.352,-.46,1.302),(.065,.047,.045),gold)
tube('Sword gold guard',[(-.455,-.46,.87),(-.342,-.48,.902),(-.215,-.48,.948),(-.115,-.46,.979)],.033,gold)
# Broad blade with separate ridge/two bevel faces, anchored directly at guard.
slab('Sword broad blade silhouette',[(-.333,-.448,.918),(-.185,-.448,.957),(-.035,-.448,.43),(-.044,-.448,.29),(-.140,-.448,.398)],.044,blade,.005)
tube('Sword center ridge',[(-.257,-.48,.937),(-.087,-.48,.382),(-.046,-.47,.294)],.008,rim,[1,.8,.1])
# Fixed neutral studio. No backgrounds are used to disguise identity differences.
scene.render.engine='CYCLES';scene.cycles.samples=40;scene.cycles.use_denoising=True;scene.render.resolution_x=1024;scene.render.resolution_y=1024;scene.render.resolution_percentage=100;scene.render.film_transparent=True;scene.view_settings.view_transform='AgX'
world=bpy.data.worlds.new('Neutral fixed studio');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.38,.40,.43,1);world.node_tree.nodes['Background'].inputs[1].default_value=.45;scene.world=world
target=Vector((.12,0,1.55))
for name,pos,power,size,color in [('Upper left soft key',(-3,-4,5),460,3,(1,.87,.75)),('Neutral front fill',(3,-4,3),180,4,(.78,.86,1)),('Silver edge light',(2,3,4),320,3,(.78,.9,1))]:
 bpy.ops.object.light_add(type='AREA',location=pos);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.size=size;o.data.color=color;o.rotation_euler=(target-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(.12,-8,2.40));cam=bpy.context.object;cam.name='Locked portrait orthographic camera';cam.data.type='ORTHO';cam.data.ortho_scale=2.7;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();scene.camera=cam
# Store same identity reference in Blender as an editable viewport image empty, not a render backdrop.
bpy.ops.object.empty_add(type='IMAGE',location=(-2,0,1.55));o=bpy.context.object;o.name='ONLY IDENTITY B-warrior-v02 512 derivative; original missing';o.data=bpy.data.images.load(str(root/'assets/candidates/vis-feel-01/tokens/B-warrior-v02.png'));o.empty_display_size=2.7;o.rotation_euler.x=math.pi/2;o.hide_render=True;bpy.ops.file.pack_all()
bpy.ops.wm.save_as_mainfile(filepath=str(out/'warrior-bust.blend'))
# Static editable model exports; no animation or skeleton.
bpy.ops.object.select_all(action='DESELECT')
for o in scene.objects:
 if o.type=='MESH':o.select_set(True)
first=next(o for o in scene.objects if o.type=='MESH');bpy.context.view_layer.objects.active=first
bpy.ops.wm.usd_export(filepath=str(out/'warrior-bust.usda'),selected_objects_only=True,export_animation=False,export_armatures=False,export_lights=False,export_cameras=False,export_normals=True,export_uvmaps=True,export_textures_mode='NEW',generate_preview_surface=True,convert_orientation=True,export_global_up_selection='Y',root_prim_path='/WarriorBustBv02',convert_world_material=False)
for view,loc in [('front',(.12,-8,2.40)),('three-quarter',(3.2,-8,2.40)),('side',(8,-.2,2.40))]:
 cam.location=loc;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
 for pixels in ([1024,128,64] if view!='side' else [1024]):
  scene.render.resolution_x=pixels;scene.render.resolution_y=pixels;scene.render.filepath=str(out/f'{view}-{pixels}.png');bpy.ops.render.render(write_still=True)
print('STATIC_BV02_BUST_RENDERED',out)
