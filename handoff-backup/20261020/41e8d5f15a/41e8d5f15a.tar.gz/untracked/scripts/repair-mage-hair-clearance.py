"""Observed brim penetration: lower the purple bob under the hat, move staff outside brim."""
import bpy,json,hashlib
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];out=root/'assets/candidates/ios-identity-v05/mage';out.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(root/'assets/candidates/ios-identity-v02/mage/mage.blend'));scene=bpy.context.scene;rig=next(o for o in scene.objects if o.type=='ARMATURE');scene.frame_set(1);bpy.context.view_layer.update();hairNames=[];staffNames=[]
for o in scene.objects:
 if o.type!='MESH':continue
 if any(t in o.name.lower() for t in ['hair','fringe','wave','curl','purple bob']):
  for v in o.data.vertices:v.co.z=1.45+(v.co.z-1.45)*.70-.03
  hairNames.append(o.name)
 slot=o.vertex_groups.get('handslot.r')
 if slot is not None and all(sum(g.weight for g in v.groups if g.group==slot.index)>.99 for v in o.data.vertices):
  deform=rig.pose.bones['handslot.r'].matrix@rig.data.bones['handslot.r'].matrix_local.inverted();inverse=deform.inverted()
  for v in o.data.vertices:
   point=deform@v.co;t=min(1,max(0,(point.z-.85)/.65));v.co=inverse@(point+Vector((-.22*t*t*(3-2*t),0,0)))
  staffNames.append(o.name)
parts=[o for o in scene.objects if o.type=='MESH'];bpy.ops.wm.save_as_mainfile(filepath=str(out/'mage.blend'));scene.cycles.samples=24
for side,loc in [('front',(0,-5,1.45)),('three-quarter',(2.1,-5,1.8))]:
 cam=scene.camera;cam.location=loc;cam.rotation_euler=(Vector((0,0,.65))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/('rest-'+side+'.png'));bpy.ops.render.render(write_still=True)
(out/'report.json').write_text(json.dumps({'hairLowered':hairNames,'staffOffset':staffNames,'staffShiftLocalMeters':-.22,'sourceSHA256':hashlib.sha256((out/'mage.blend').read_bytes()).hexdigest(),'claim':'Targeted source clearance repair; native and animated intersection review separate'},indent=2)+'\n');print('MAGE_CLEARANCE_REPAIR_COMPLETE')
