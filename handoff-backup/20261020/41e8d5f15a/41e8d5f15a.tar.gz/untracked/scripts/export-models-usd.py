#!/usr/bin/env python3
"""Convert the native RealityKit review snapshot into editable, static USD assets."""
import argparse
import hashlib
import json
import math
import re
from pathlib import Path


def vector(value, length):
    if not isinstance(value, list) or len(value) != length:
        raise ValueError(f"Expected {length} components")
    if any(type(x) not in (int, float) or not math.isfinite(x) for x in value):
        raise ValueError("Non-finite or non-numeric component")


def matrix(value):
    if not isinstance(value, list) or len(value) != 4:
        raise ValueError("Expected four matrix columns")
    for column in value:
        vector(column, 4)


def validate(data):
    if data.get("schema") != "tacticalgo-model-snapshot.v1" or data.get("upAxis") != "Y" or data.get("metersPerUnit") != 1:
        raise ValueError("Unsupported snapshot coordinates/schema")
    if not data.get("meshes") or not data.get("models"):
        raise ValueError("Empty model snapshot")
    for resource in data["meshes"].values():
        model_ids = set()
        for model in resource["models"]:
            if model["id"] in model_ids:
                raise ValueError("Duplicate mesh model")
            model_ids.add(model["id"])
            for part in model["parts"]:
                points, normals, indices = part["points"], part["normals"], part["triangles"]
                if not points or not indices or len(indices) % 3:
                    raise ValueError("Empty mesh or incomplete triangles")
                for p in points:
                    vector(p, 3)
                if normals and len(normals) != len(points):
                    raise ValueError("Vertex normal count mismatch")
                for normal in normals:
                    vector(normal, 3)
                if any(type(i) is not int or i < 0 or i >= len(points) for i in indices):
                    raise ValueError("Triangle index outside vertex stream")
        if not resource["instances"]:
            raise ValueError("Missing mesh instances")
        for instance in resource["instances"]:
            matrix(instance["matrixColumns"])
            if instance["model"] not in model_ids:
                raise ValueError("Instance references missing mesh model")
    if "animation" in data:
        animation = data["animation"]
        if animation["framesPerSecond"] != 30 or animation["endTimeCode"] not in (42, 102):
            raise ValueError("Unsupported pose timing")
    def node(n):
        matrix(n["matrixColumns"])
        if "matrixSamples" in n:
            samples = n["matrixSamples"]
            if "animation" not in data or [sample["time"] for sample in samples] != list(range(data["animation"]["endTimeCode"] + 1)):
                raise ValueError("Incomplete or unordered pose samples")
            for sample in samples:
                matrix(sample["matrixColumns"])
            if samples[0]["matrixColumns"] != n["matrixColumns"] or samples[-1]["matrixColumns"] != n["matrixColumns"]:
                raise ValueError("Pose must start and settle at the rest transform")
        if not isinstance(n["name"], str):
            raise ValueError("Invalid entity name")
        if "mesh" in n:
            if n["mesh"] not in data["meshes"] or "surface" not in n:
                raise ValueError("Missing mesh/surface")
            surface = n["surface"]
            vector(surface["colorSRGB"], 4)
            if any(not 0 <= c <= 1 for c in surface["colorSRGB"]):
                raise ValueError("Color outside unit interval")
            for key in ("roughness", "metallic"):
                vector([surface[key]], 1)
                if not 0 <= surface[key] <= 1:
                    raise ValueError("Surface parameter outside unit interval")
        for child in n["children"]:
            node(child)
    for root in data["models"].values():
        node(root)


def number(x):
    return format(x, ".9g")


def tuple_value(values):
    return "(" + ", ".join(number(x) for x in values) + ")"


def identifier(name):
    result = re.sub(r"[^A-Za-z0-9_]", "_", name) or "part"
    return "_" + result if result[0].isdigit() else result


def linear(x):
    return x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4


def stage(data, hero, animated=False):
    root_name = identifier(hero)
    lines = ['#usda 1.0', '(', f'    defaultPrim = "{root_name}"', '    metersPerUnit = 1', '    upAxis = "Y"', ')']
    if animated:
        if "animation" not in data:
            raise ValueError("Missing pose animation")
        lines[-1:-1] = ["    framesPerSecond = 30", "    timeCodesPerSecond = 30", "    startTimeCode = 0", f'    endTimeCode = {data["animation"]["endTimeCode"]}']
    counts = {"entities": 0, "meshParts": 0, "triangles": 0, "vertices": 0}
    def emit(depth, text):
        lines.append("    " * depth + text)
    def transform(depth, columns):
        # SIMD uses column vectors; USD/Gf uses row vectors. Its rows are SIMD's columns.
        emit(depth, "matrix4d xformOp:transform = (" + ", ".join(tuple_value(c) for c in columns) + ")")
        emit(depth, 'uniform token[] xformOpOrder = ["xformOp:transform"]')
    def node(n, name, path, depth):
        counts["entities"] += 1
        emit(depth, f'def Xform "{name}"')
        emit(depth, "{")
        transform(depth + 1, n["matrixColumns"])
        if animated and "matrixSamples" in n:
            emit(depth + 1, "matrix4d xformOp:transform.timeSamples = {")
            for sample in n["matrixSamples"]:
                emit(depth + 2, str(sample["time"]) + ": (" + ", ".join(tuple_value(c) for c in sample["matrixColumns"]) + "),")
            emit(depth + 1, "}")
        emit(depth + 1, "custom string sourceEntityName = " + json.dumps(n["name"], ensure_ascii=False))
        if "mesh" in n:
            s = n["surface"]
            mat_path = path + "/Surface"
            emit(depth + 1, 'def Material "Surface" {')
            emit(depth + 2, f'token outputs:surface.connect = <{mat_path}/Shader.outputs:surface>')
            emit(depth + 2, 'def Shader "Shader" {')
            emit(depth + 3, 'uniform token info:id = "UsdPreviewSurface"')
            emit(depth + 3, "color3f inputs:diffuseColor = " + tuple_value([linear(x) for x in s["colorSRGB"][:3]]))
            emit(depth + 3, "float inputs:opacity = " + number(s["colorSRGB"][3]))
            emit(depth + 3, "float inputs:roughness = " + number(s["roughness"]))
            emit(depth + 3, "float inputs:metallic = " + number(s["metallic"]))
            emit(depth + 3, "token outputs:surface")
            emit(depth + 2, "}")
            emit(depth + 1, "}")
            resource = data["meshes"][n["mesh"]]
            models = {m["id"]: m for m in resource["models"]}
            for j, instance in enumerate(resource["instances"]):
                emit(depth + 1, f'def Xform "instance_{j}" {{')
                transform(depth + 2, instance["matrixColumns"])
                for k, part in enumerate(models[instance["model"]]["parts"]):
                    points, normals, indices = part["points"], part["normals"], part["triangles"]
                    counts["meshParts"] += 1
                    counts["triangles"] += len(indices) // 3
                    counts["vertices"] += len(points)
                    emit(depth + 2, f'def Mesh "mesh_{k}" (prepend apiSchemas = ["MaterialBindingAPI"]) {{')
                    emit(depth + 3, 'uniform token subdivisionScheme = "none"')
                    emit(depth + 3, "point3f[] points = [" + ", ".join(tuple_value(p) for p in points) + "]")
                    emit(depth + 3, "int[] faceVertexCounts = [" + ", ".join(["3"] * (len(indices) // 3)) + "]")
                    emit(depth + 3, "int[] faceVertexIndices = [" + ", ".join(str(i) for i in indices) + "]")
                    extent = [[min(p[i] for p in points) for i in range(3)], [max(p[i] for p in points) for i in range(3)]]
                    emit(depth + 3, "float3[] extent = [" + ", ".join(tuple_value(p) for p in extent) + "]")
                    if normals:
                        emit(depth + 3, "normal3f[] normals = [" + ", ".join(tuple_value(p) for p in normals) + '] (interpolation = "vertex")')
                    emit(depth + 3, f'rel material:binding = <{mat_path}>')
                    emit(depth + 2, "}")
                emit(depth + 1, "}")
        for i, child in enumerate(n["children"]):
            child_name = identifier(child["name"]) + f"_{i}"
            node(child, child_name, path + "/" + child_name, depth + 1)
        emit(depth, "}")
    node(data["models"][hero], root_name, "/" + root_name, 0)
    return "\n".join(lines) + "\n", counts


def export(snapshot, output):
    data = json.loads(Path(snapshot).read_text())
    validate(data)  # Validate the complete snapshot before writing any candidates.
    results = {hero: stage(data, hero) for hero in sorted(data["models"])}
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    manifest = {"sourceSHA256": hashlib.sha256(Path(snapshot).read_bytes()).hexdigest(),
                "coordinates": "Y-up, metres, right handed", "candidate": True,
                "animation": "static hierarchy with optional authored rigid-pose study; no skeletal/skin claim", "assets": {}}
    for hero, (text, counts) in results.items():
        path = output / (identifier(hero).lower() + ".usda")
        path.write_text(text)
        manifest["assets"][hero] = dict(counts, file=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        if "animation" in data:
            pose_text, _ = stage(data, hero, animated=True)
            pose_path = output / (identifier(hero).lower() + "-pose.usda")
            pose_path.write_text(pose_text)
            manifest["assets"][hero].update(poseFile=pose_path.name, poseSHA256=hashlib.sha256(pose_path.read_bytes()).hexdigest())
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("snapshot")
    parser.add_argument("output")
    args = parser.parse_args()
    print(json.dumps(export(args.snapshot, args.output), indent=2))
