"""Reuse reviewed sculpt-form construction for distinct Mage/Rogue candidate studies.

Preserves the old class props/clothing and actual 11-joint bind transforms;
replaces rejected spherical face/fist parts. Voxel study, not manual retopology.
"""
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
base=(root/'scripts/sculpt-guardian-final.py').read_text()
prefix=base[:base.index('head=loft(')]
face=base[base.index('head=loft('):base.index('# Open helmet shell:')]
hand=base[base.index(' # Palm and four'):base.index('# Join with original')]
end=base[base.index('# Join with original'):]
for hero in ['Mage','Rogue']:
 low=hero.lower();code=prefix.replace("ios-sculpt-v10/guardian-final'",f"ios-sculpt-v10/{low}-study'").replace('warrior.blend',low+'.blend').replace('Warrior_Rig',hero+'_Rig').replace('Warrior_Skin',hero+'_Skin')
 a=code.index('for part in parts:');b=code.index('bm=bmesh.new()',a)
 code=code[:a]+'''for part in parts:
 indices=range(part['offset'],part['offset']+part['vertices'])
 verts=set(indices);pol=next((p for p in skin.data.polygons if p.vertices[0] in verts),None)
 color=skin.data.materials[pol.material_index].diffuse_color if pol else (0,0,0,1)
 if CLASS=='Mage': keep_head=(abs(color[0]-.35)<.025 and abs(color[1]-.13)<.025 or abs(color[0]-1)<.025 and abs(color[1]-.65)<.025)
 else: keep_head=abs(color[0]-.075)<.025 and abs(color[1]-.19)<.025
 drop=(part['bone']=='head' and not keep_head) or (CLASS=='Mage' and part['name']=='robe')
 if part['bone'] in ['left_arm','right_arm']:drop=drop or abs(color[0]-.96)<.01
 if drop:remove.update(indices);removed.append(part)
'''.replace('CLASS',repr(hero))+code[b:]
 code+=face
 if hero=='Mage':
  code+='''
# Designed coherent beard mass and swept side locks instead of a collection of white balls.
beardmat=mat('Mage warm ivory hair',(.79,.77,.67),0,.80)
loft('Guardian mage pointed beard',[(.653,.012,.012,.235),(.680,.043,.026,.245),(.745,.103,.031,.261),(.810,.153,.035,.267),(.854,.146,.026,.259),(.875,.111,.018,.256)],beardmat,'head',32,.45,2)
for side in [-1,1]:
 locks=[]
 for j in range(3):
  locks.append(volume('Guardian mage side lock '+str(side)+'-'+str(j),(side*(.197+j*.010),.988-j*.059,-.009),(.044,.081,.056),beardmat,exp=.55))
 fuse(locks,'Guardian mage swept hair '+str(side),beardmat,'head',.0075)
 moustache=tube('Guardian mage swept moustache '+str(side),[(side*.022,.866,.302),(side*.066,.857,.299),(side*.111,.864,.288)],.014,beardmat)
# Broad robe planes preserve class silhouette but remove the straight cone body.
clothmat=next(m for m in skin.data.materials if abs(m.diffuse_color[0]-.35)<.025)
loft('Guardian mage robe planes',[(.169,.243,.225,0),(.177,.276,.262,0),(.218,.275,.259,0),(.375,.252,.229,0),(.541,.211,.183,0),(.685,.166,.151,0),(.730,.125,.109,0)],clothmat,'body',32,.45,2)
'''
 else:
  code+='''
# Narrower agile face; retained original hood and face cloth remain separate layers.
for o in scene.objects:
 if o.type=='MESH' and o.name.startswith('Guardian'):
  for v in o.data.vertices:v.co.x*=.92
'''
 code+="\nfor side in [-1,1]:\n bone='left_arm' if side<0 else 'right_arm'\n"+hand
 suffix=end.replace("guardian-sculpt-master.blend",low+'-sculpt-master.blend').replace("'Warrior'",repr(hero)).replace("'/Warrior'",repr('/'+hero)).replace("warrior.blend",low+'.blend').replace("warrior-rig.usda",low+'-rig.usda')
 code+=suffix
 # Run sequential class sessions; inherited helper functions stay independent after fresh .blend load.
 exec(compile(code,str(root/f'scripts/sculpt-{low}-generated.py'),'exec'),globals())
