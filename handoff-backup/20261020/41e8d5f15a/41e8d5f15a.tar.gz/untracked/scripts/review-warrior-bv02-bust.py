"""Requested side-by-side and 128/64 review. Preserve source and real Blender renders.
Resize only reference for explicit scale QA; no character repainting or synthetic renders.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import hashlib,json,sys
root=Path(__file__).resolve().parents[1];version=sys.argv[1] if len(sys.argv)>1 else 'warrior-bust-bv02-v01';src=root/'assets/candidates'/version;out=root/'artifacts/ios/warrior-bust-bv02-v01'/('final-v02' if version.endswith('v02') else 'first-v01');out.mkdir(exist_ok=True);ref=root/'assets/candidates/vis-feel-01/tokens/B-warrior-v02.png';font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',20)
required=[src/f'{view}-{n}.png' for view,n in [('front',1024),('front',128),('front',64),('three-quarter',1024),('three-quarter',128),('three-quarter',64),('side',1024)]]
assert all(p.is_file() for p in required),'Wait for all seven real Blender outputs; do not publish incomplete comparison'
for n in [128,64]:Image.open(ref).resize((n,n),Image.Resampling.LANCZOS).save(out/f'reference-{n}.png')
# All panel cells use exactly the same plain QA background. Original is never repainted.
canvas=Image.new('RGB',(1600,610),'#203741');draw=ImageDraw.Draw(canvas)
for i,(label,p) in enumerate([('B-v02 actual reference (512 derivative)',ref),('Editable 3D bust - fixed front',src/'front-1024.png'),('Editable 3D bust - fixed 3/4',src/'three-quarter-1024.png')]):
 im=Image.open(p).convert('RGBA').resize((500,500),Image.Resampling.LANCZOS);canvas.paste(im,(25+i*525,70),im);draw.text((25+i*525,22),label,font=font,fill='#ffffff')
canvas.save(out/'comparison.png')
# Show native 128/64 renders at 1:1; no upscaling mistaken for size evidence.
small=Image.new('RGB',(760,360),'#203741');d=ImageDraw.Draw(small)
for row,n in enumerate([128,64]):
 y=44+row*177;d.text((18,y),f'{n}px',font=font,fill='white')
 for i,(title,p) in enumerate([('B-v02',out/f'reference-{n}.png'),('Front',src/f'front-{n}.png'),('3/4',src/f'three-quarter-{n}.png')]):
  im=Image.open(p).convert('RGBA');small.paste(im,(120+i*206,y),im);d.text((120+i*206,y-28),title,font=font,fill='white')
small.save(out/'native-size-review.png')
files=[ref,*src.glob('*.blend'),*src.glob('*.usda'),*src.glob('*.png'),out/'comparison.png',out/'native-size-review.png',out/'reference-128.png',out/'reference-64.png'];manifest=[]
for p in files:
 item={'path':str(p.relative_to(root)),'SHA256':hashlib.sha256(p.read_bytes()).hexdigest()}
 if p.suffix=='.png':im=Image.open(p);item.update({'width':im.width,'height':im.height,'RGBA_SHA256':hashlib.sha256(im.convert('RGBA').tobytes()).hexdigest()})
 manifest.append(item)
(out/'artifact-manifest.json').write_text(json.dumps({'files':manifest,'referenceStatus':'B-v02 exact 512 derivative verified; 1254 original unavailable','renderSource':'Blender Cycles actual static geometry; no image_gen','QAOperation':'reference resize and actual-render comparison only; originals unchanged','approval':'pending_owner','gameplayIntegration':'not_changed'},indent=2)+'\n')
print('COMPARISON_AND_NATIVE_SIZES_SAVED')
