#!/usr/bin/env python3
"""Record an existing Debug app's real native review actions on a named simulator."""
import argparse
import hashlib
import json
from pathlib import Path
import signal
import subprocess
import time
import uuid

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--device', required=True)
parser.add_argument('--scenario', choices=['all', 'seal', 'models', 'idle', 'match-warrior', 'match-rogue'], default='all')
parser.add_argument('--resource-kind', choices=['rig', 'pose', 'identity'], help='Review packages already in the simulator Documents folder; models only')
parser.add_argument('--closeup', action='store_true', help='Debug motion-only camera magnification; preserve the overview clip separately')
parser.add_argument('--timecode', action='store_true', help='DEBUG pixel clock for actual movie/trace alignment; preserve clean videos separately')
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--app', type=Path, default=Path('ios/Build/Products/Debug-iphonesimulator/TacticalGo.app'))
args = parser.parse_args()
if args.resource_kind and args.scenario not in ('models', 'idle'): parser.error('--resource-kind requires --scenario models/idle')
if args.resource_kind == 'identity' and args.scenario != 'models': parser.error('identity candidates have class-keyed study clips; models tour only')
if args.closeup and args.scenario not in ('all', 'seal'): parser.error('--closeup requires all/seal motion review')
if args.output.exists(): raise SystemExit('Refusing to overwrite an existing native recording')
args.output.parent.mkdir(parents=True, exist_ok=True)
subprocess.run(['xcrun','simctl','install',args.device,str(args.app)],check=True)
subprocess.run(['xcrun','simctl','terminate',args.device,'com.tacticalgo.prototype'],capture_output=True)
flags, seconds = {'all':(['--motion-tour'],54), 'seal':(['--seal-tour'],13), 'models':(['--model-tour'],44), 'idle':(['--idle-tour'],54),
                  'match-warrior':(['--match-tour','--slow-match'],42),
                  'match-rogue':(['--match-tour','--slow-match','--rogue-match'],36)}[args.scenario]
flags += ['--identity-models' if args.resource_kind == 'identity' else ('--rig-models' if args.resource_kind == 'rig' else '--package-models')] if args.resource_kind else []
token = str(uuid.uuid4()) if args.scenario in ('all', 'seal', 'models', 'idle') else None
if token: flags += ['--record-tour-token', token]
if args.closeup: flags += ['--motion-closeup']
if args.timecode: flags += ['--record-timecode']
documents = Path(subprocess.check_output(['xcrun', 'simctl', 'get_app_container', args.device, 'com.tacticalgo.prototype', 'data'], text=True).strip()) / 'Documents'
original_inputs = {'debugLibrarySHA256': hashlib.sha256((args.app / 'TacticalGo.debug.dylib').read_bytes()).hexdigest(),
                   'bundledModelSHA256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (args.app / 'Models').glob('*.usdz')}}
if args.resource_kind and args.resource_kind != 'identity':
    review_files = [documents / (hero + '-' + args.resource_kind + '.usdz') for hero in ['warrior','mage','rogue']]
    original_review = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in review_files}
    original_inputs['documentsResourceSHA256'] = original_review
with args.output.with_suffix('.log').open('w') as log:
    recording_started = time.time()
    process = subprocess.Popen(['xcrun','simctl','io',args.device,'recordVideo','--codec=h264',str(args.output)],stdout=log,stderr=log)
    try:
        time.sleep(1)
        launch = subprocess.check_output(['xcrun','simctl','launch',args.device,'com.tacticalgo.prototype',*flags], text=True)
        log.write(launch); log.flush()
        native_pid = int(launch.strip().rsplit(':', 1)[1])
        args.output.with_suffix('.process.json').write_text(json.dumps({'recorderPID':process.pid,'nativeAppPID':native_pid,
            'recordingStartedAt':recording_started,'startedAt':time.time(),'device':args.device,'scenario':args.scenario,
            'launchArguments':flags, **original_inputs},indent=2)+'\n')
        if token:
            trace = documents / ('motion-tour-' + token + '.json')
            for _ in range(120):
                processes = subprocess.check_output(['xcrun', 'simctl', 'spawn', args.device, 'launchctl', 'list'], text=True)
                if not any(line.split() and line.split()[0] == str(native_pid) for line in processes.splitlines()):
                    raise SystemExit('Native app exited during recording; incomplete attempt retained')
                if trace.exists():
                    receipt = json.loads(trace.read_text())
                    if receipt.get('complete'):
                        args.output.with_suffix('.trace.json').write_text(json.dumps(receipt, indent=2) + '\n')
                        expected = 8 if args.scenario == 'all' else (6 if args.scenario in ('models', 'idle') else 1)
                        requested = [row['receipt'] for row in receipt['rows'] if row['phase'] == 'requested']
                        started = [row['receipt'] for row in receipt['rows'] if row['phase'] == 'native-start']
                        finished = [row['receipt'] for row in receipt['rows'] if row['phase'] == 'native-complete']
                        cancelled = [row for row in receipt['rows'] if row['phase'] == 'native-cancel']
                        if len(requested) != expected or requested != started or requested != finished or cancelled:
                            raise SystemExit('Tour ended without every requested native playback completing; trace retained')
                        break
                time.sleep(1)
            else: raise SystemExit('Native tour did not report completion; incomplete attempt retained')
            time.sleep(1)
        else: time.sleep(seconds)
    finally:
        if process.poll() is None:
            process.send_signal(signal.SIGINT); process.wait(timeout=15)
    if process.returncode: raise SystemExit(f'Recorder failed with {process.returncode}')
if not args.output.exists() or args.output.stat().st_size == 0: raise SystemExit('No video output')
final_inputs = {'debugLibrarySHA256': hashlib.sha256((args.app / 'TacticalGo.debug.dylib').read_bytes()).hexdigest(),
                'bundledModelSHA256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (args.app / 'Models').glob('*.usdz')}}
if args.resource_kind and args.resource_kind != 'identity':
    final_inputs['documentsResourceSHA256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in review_files}
if final_inputs != original_inputs:
    raise SystemExit('Build changed while recording; attempt retained, no completion claim')
print(f'Native recording: {args.output} ({args.output.stat().st_size} bytes); not physical-device performance evidence')
