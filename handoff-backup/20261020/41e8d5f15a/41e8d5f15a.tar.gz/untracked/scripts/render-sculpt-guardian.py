"""Resume actual Blender master export/review without rebuilding or overwriting failure logs."""
import bpy,sys,json,hashlib
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
output=root/'assets/candidates/ios-sculpt-v10/guardian'
bpy.ops.wm.open_mainfile(filepath=str(output/'warrior.blend'))
scene=bpy.context.scene; scene.frame_set(0)
rig=bpy.data.objects['Warrior_Rig'];skin=bpy.data.objects['Warrior_Skin']
for group in list(skin.vertex_groups):
 if group.name.startswith('edit_'):skin.vertex_groups.remove(group)
bpy.ops.object.select_all(action='DESELECT');skin.select_set(True);rig.select_set(True);bpy.context.view_layer.objects.active=rig
usd=output/'warrior-rig.usda'
bpy.ops.wm.usd_export(filepath=str(usd),selected_objects_only=True,export_animation=True,export_armatures=True,only_deform_bones=True,export_shapekeys=False,export_lights=False,export_cameras=False,export_normals=True,export_uvmaps=True,export_textures_mode='NEW',export_subdivision='IGNORE',generate_preview_surface=True,convert_orientation=True,export_global_up_selection='Y',root_prim_path='/Warrior',export_custom_properties=True,convert_world_material=False)
scene.cycles.samples=32;scene.render.resolution_x=720;scene.render.resolution_y=840
images=[]
for frame,label in [(0,'rest'),(35,'gesture')]:
 scene.frame_set(frame)
 for side,location in [('front',(0,-4.5,2.0)),('three-quarter',(2.3,-4.5,2.7)),('profile',(4.5,0,2.0)),('back',(2.3,4.5,2.5))]:
  scene.camera.location=location;scene.camera.rotation_euler=(Vector((0,0,.65))-scene.camera.location).to_track_quat('-Z','Y').to_euler();scene.camera.data.ortho_scale=1.6
  p=output/(label+'-'+side+'.png');scene.render.filepath=str(p);bpy.ops.render.render(write_still=True);images.append(p.name)
report=dict(sourceSHA256=hashlib.sha256((output/'warrior.blend').read_bytes()).hexdigest(),usdSHA256=hashlib.sha256(usd.read_bytes()).hexdigest(),vertices=len(skin.data.vertices),triangles=len(skin.data.polygons),joints=list(rig.data.bones.keys()),renders=images,claim='Editable original sculpt-form master and inherited action study, voxel fusion not manual production topology. Visual review and native integration separate.')
(output/'sculpt-render-report.json').write_text(json.dumps(report,indent=2)+'\n');print('SCULPT_RENDER_COMPLETE',report['vertices'],report['triangles'])
