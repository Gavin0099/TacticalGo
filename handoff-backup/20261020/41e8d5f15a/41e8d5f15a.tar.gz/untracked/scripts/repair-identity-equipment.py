"""Preserve blade width lost by the study pose formula; new outputs, failures retained."""
import bpy,bmesh,json,sys,hashlib
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];hero=sys.argv[sys.argv.index('--')+1];source=root/'assets/candidates/ios-identity-v01'/('warrior-native' if hero=='warrior' else hero)/(hero+'.blend');out=root/'assets/candidates/ios-identity-v01/final'/hero;out.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(source));scene=bpy.context.scene;rig=next(o for o in scene.objects if o.type=='ARMATURE');scene.frame_set(1);bpy.context.view_layer.update()
def newmesh(name,vs,fs,m,bone,posed=False):
 d=bpy.data.meshes.new(name);d.from_pydata(vs,[],fs);d.update();o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.data.materials.append(m)
 if posed:
  inv=(rig.pose.bones[bone].matrix@rig.data.bones[bone].matrix_local.inverted()).inverted()
  for v in d.vertices:v.co=inv@v.co
 bm=bmesh.new();bm.from_mesh(d);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(d);bm.free();o.parent=rig;o.vertex_groups.new(name=bone).add(list(range(len(d.vertices))),1,'REPLACE');o.modifiers.new('Reviewed skin binding','ARMATURE').object=rig;return o
def extrude(name,front,thickness,material):
 n=len(front);return newmesh(name,front+[(x,y+thickness,z) for x,y,z in front],[tuple(reversed(range(n))),tuple(n+i for i in range(n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)],material,'handslot.r',True)
if hero=='warrior':
 for o in list(scene.objects):
  if o.type=='MESH' and 'sword' in o.name.lower():bpy.data.objects.remove(o,do_unlink=True)
 extrude('Broad original-design sword',[(-.575,-.26,.585),(-.480,-.26,.61),(-.63,-.26,.18),(-.74,-.26,.095),(-.72,-.26,.22)],.03,bpy.data.materials['Soft brushed steel'])
 extrude('Gold sword crossguard',[(-.64,-.28,.60),(-.425,-.28,.66),(-.418,-.28,.71),(-.647,-.28,.65)],.075,bpy.data.materials['Aged warm gold'])
 extrude('Leather sword handle',[(-.55,-.25,.64),(-.49,-.25,.65),(-.43,-.25,.82),(-.49,-.25,.84)],.07,bpy.data.materials['Chestnut leather'])
# A tiny skin underlay covers the separated mouth insert opening. Preserve original friendly smile.
bpy.ops.object.select_all(action='DESELECT');bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=16,location=(0,-.337,1.415));mouth=bpy.context.object;mouth.name='Closed smile skin underlay';mouth.scale=(.085,.036,.034);bpy.ops.object.transform_apply(location=True,rotation=True,scale=True);mouth.data.materials.append(bpy.data.materials['Warm youthful complexion']);mouth.parent=rig;mouth.vertex_groups.new(name='head').add(list(range(len(mouth.data.vertices))),1,'REPLACE');mouth.modifiers.new('Head binding','ARMATURE').object=rig
for p in mouth.data.polygons:p.use_smooth=True
parts=[o for o in scene.objects if o.type=='MESH'];scene.frame_set(1);scene.cycles.samples=24;scene.render.resolution_x=720;scene.render.resolution_y=900
bpy.ops.wm.save_as_mainfile(filepath=str(out/(hero+'.blend')))
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=rig
usd=out/(hero+'-rig.usda');bpy.ops.wm.usd_export(filepath=str(usd),selected_objects_only=True,export_animation=True,export_armatures=True,only_deform_bones=True,export_shapekeys=False,export_lights=False,export_cameras=False,export_normals=True,export_uvmaps=True,export_textures_mode='NEW',export_subdivision='IGNORE',generate_preview_surface=True,convert_orientation=True,export_global_up_selection='Y',root_prim_path='/'+hero.title()+'Identity',convert_world_material=False)
for frame,label in [(1,'rest'),(26,'idle-mid')]:
 scene.frame_set(frame)
 for side,loc in [('front',(0,-5,1.45)),('three-quarter',(2.1,-5,1.8)),('back',(2.1,5,1.8))]:
  cam=scene.camera;cam.location=loc;cam.rotation_euler=(Vector((0,0,.65))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(label+'-'+side+'.png'));bpy.ops.render.render(write_still=True)
report={'class':hero,'sourceBlendSHA256':hashlib.sha256((out/(hero+'.blend')).read_bytes()).hexdigest(),'usdSHA256':hashlib.sha256(usd.read_bytes()).hexdigest(),'fix':'warrior right blade preserves transverse X width; tiny mouth skin underlay','notClaimed':['exact likeness','Owner art acceptance','physical device','main gameplay 23-joint adapter']};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('IDENTITY_FINAL_CANDIDATE',report)
