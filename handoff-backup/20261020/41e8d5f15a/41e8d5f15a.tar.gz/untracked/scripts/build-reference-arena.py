"""Original editable arena composition study from Owner's supplied screenshot.
No Supercell meshes, logos, textures or game rules are copied. Real beveled solids.
"""
import bpy,math,json,sys,hashlib
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];out=root/'assets/candidates/ios-reference-arena-v01';out.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.render.engine='CYCLES';scene.cycles.samples=40
scene.render.resolution_x=900;scene.render.resolution_y=1200;scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX'
materials={};parts=[]
def mat(name,c,metal=0,rough=.65):
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True;s=m.node_tree.nodes.get('Principled BSDF');s.inputs['Base Color'].default_value=(*c,1);s.inputs['Metallic'].default_value=metal;s.inputs['Roughness'].default_value=rough;materials[name]=m;return m
stone=mat('Warm carved limestone',(.43,.48,.43));lightstone=mat('Stone edge highlight',(.58,.62,.55));darkstone=mat('Foundation stone',(.21,.26,.24));earth=mat('Cut earth',(.27,.16,.055));grass=mat('Sunlit grass',(.42,.66,.105));grass2=mat('Checker grass',(.48,.72,.14));grass3=mat('Grass border',(.30,.50,.065));water=mat('Clear turquoise river',(.035,.52,.74),.15,.33);foam=mat('Water glints',(.23,.80,.89),0,.40);wood=mat('Warm bridge timber',(.43,.235,.085));woodlight=mat('Timber plank highlights',(.57,.35,.15));gold=mat('Warm gold trim',(.93,.54,.06),.3,.44);red=mat('Red team painted timber',(.74,.075,.045));blue=mat('Blue team painted timber',(.035,.28,.71));leaf=mat('Hedge leaf mid',(.26,.49,.045));leaflight=mat('Hedge sunlit crown',(.36,.61,.065));leafdark=mat('Hedge recess',(.13,.32,.035))
# Coordinates are authored in game x/y-up/z-forward; Blender converts to x/-z/y.
def cv(p):return (p[0],-p[2],p[1])
def box(name,p,size,material,bevel=.04):
 bpy.ops.mesh.primitive_cube_add(size=1,location=cv(p));o=bpy.context.object;o.name=name;o.scale=(size[0],size[2],size[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if bevel:
  mod=o.modifiers.new('Designed bevel','BEVEL');mod.width=bevel;mod.segments=3;bpy.ops.object.modifier_apply(modifier=mod.name)
 o.data.materials.append(material);o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL');parts.append(o);return o

def crown_tower(x,z,team,king=False):
 c=red if team=='red' else blue;w=1.26 if king else .88;h=1.16 if king else .87;prefix=team+(' bastion' if king else ' watchtower')
 box(prefix+' foot',(x,.10,z),(w+.30,.20,w+.26),darkstone,.08)
 box(prefix+' base',(x,.27,z),(w+.14,.28,w+.10),stone,.09)
 box(prefix+' lower bevel',(x,.43,z),(w+.17,.13,w+.13),lightstone,.045)
 box(prefix+' core',(x,.43+h/2,z),(w,h,w),stone,.10)
 # Broad stacked masonry courses and corner keys.
 for yy in [.57,.83,1.07] if king else [.56,.81]:
  for side in [-1,1]:box(prefix+' side masonry',(x+side*(w/2+.003),yy,z),(.032,.022,w-.10),darkstone,.004)
  box(prefix+' front course',(x,yy,z+w/2+.005),(w-.10,.024,.028),darkstone,.003)
 box(prefix+' painted frieze',(x,.62,z+w/2+.055),(w*.73,.32,.11),c,.03)
 box(prefix+' trim',(x,.79,z+w/2+.11),(w*.81,.060,.040),gold,.012)
 box(prefix+' raised diamond',(x,.60,z+w/2+.123),(.12,.20,.040),gold,.02).rotation_euler[1]=0
 box(prefix+' parapet',(x,h+.52,z),(w+.22,.18,w+.22),lightstone,.06)
 # Thick crenellations give the reference's chunky stepped silhouettes.
 for dx in [-1,1]:
  for dz in [-1,1]:box(prefix+' merlon',(x+dx*w*.42,h+.70,z+dz*w*.42),(.26,.27,.27),lightstone,.045)
 box(prefix+' top deck',(x,h+.59,z),(w-.22,.035,w-.22),c,.014)
 # Original angular heraldic marker, not a Supercell crown/logo.
 box(prefix+' standard pole',(x-.22,h+.83,z-.10),(.05,.57,.05),wood,.012)
 box(prefix+' standard',(x-.03,h+.98,z-.10),(.34,.27,.06),c,.018)
 box(prefix+' standard stripe',(x-.03,h+.98,z-.064),(.08,.20,.015),gold,.004)
 if king:
  box(prefix+' cap',(x,h+.76,z),(.46,.20,.43),c,.055)
 return prefix

box('Deep arena foundation',(0,-.34,0),(8.4,.64,11.3),earth,.18)
box('Stone footing',(0,-.10,0),(8.40,.20,11.28),darkstone,.09)
box('Lawn field',(0,-.025,0),(7.95,.05,10.94),grass3,.035)
# Small checker squares, regular hue family rather than giant Go-board cells.
for x in range(16):
 for z in range(22):
  box(f'Lawn tile {x}-{z}',(-3.75+x*.5,.009,-5.25+z*.5),(.50,.020,.50),grass if (x+z)%2 else grass2,0)
# River remains between rule rows in the visual study; carries no collision/rule semantics.
box('Turquoise river',(0,.025,.50),(7.98,.026,.56),water,.012)
for side in [-1,1]:
 for i in range(19):
  x=-3.82+i*.425
  o=box('River bank stone',(x,.075,.50+side*.34),(.40,.16,.20),lightstone if i%3 else stone,.055);o.rotation_euler[2]=(i%3-1)*.015
for x in [-1.85,1.85]:
 for i in range(9):
  z=.5+(i-4)*.104;y=.09+.065*math.sin((i/8)*math.pi)
  o=box('Arched bridge plank',(x,y,z),(.90,.11,.104),woodlight if i%3 else wood,.018);o.rotation_euler[0]=math.cos(i/8*math.pi)*.12
 for dx in [-.39,.39]:box('Bridge side beam',(x+dx,.07,.5),(.11,.12,1.05),wood,.025)
for i in range(14):box('Water ribbon glint',(-3.45+i*.48,.044,.42+(i%3)*.055),(.23,.003,.018),foam,.003)
# Red and blue fortifications frame the full arena, instead of tiny podium units.
for team,z,front in [('red',-4.42,-3.68),('blue',4.42,3.68)]:
 crown_tower(0,z,team,True)
 for x in [-2.30,2.30]:crown_tower(x,front,team)
 for x in [-1.55,1.55]:
  box(team+' entry paving',(x,.031,front+(-.44 if team=='blue' else .44)),(.42,.027,1.0),woodlight,.02)
# Stone border, hedged side gardens and wooden boundary rail.
for side in [-1,1]:
 for i in range(23):
  z=-5.25+i*.475
  o=box('Boundary carved block',(side*4.02,.11,z),(.31,.28,.445),stone if i%4 else lightstone,.07);o.rotation_euler[2]=(i%3-1)*.025
 for i in range(10):
  z=-4.90+i*1.1
  box('Hedge trunk',(side*4.20,.27,z),(.17,.50,.18),wood,.04)
  # Rounded cuboid topiary volumes create broad defined masses, not marble spheres.
  box('Hedge deep foliage',(side*4.15,.55,z),(.65,.72,.89),leafdark,.19)
  box('Hedge leaf crown',(side*4.08,.80,z-.035),(.57,.62,.79),leaf if i%2 else leaflight,.19)
 for z in [-5.25,5.25]:
  for x in [-2.8,-1.1,1.1,2.8]:box('Fence pillar',(x,.26,z),(.18,.47,.19),wood,.035)
  box('End fence rail',(0,.39,z),(7.50,.13,.13),woodlight,.035)
# Editable geometry and a clean static USD excluding the studio.
scene.frame_set(0);source=out/'reference-arena.blend';bpy.ops.wm.save_as_mainfile(filepath=str(source))
bpy.ops.object.select_all(action='DESELECT')
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=parts[0]
usd=out/'reference-arena.usda';bpy.ops.wm.usd_export(filepath=str(usd),selected_objects_only=True,export_animation=False,export_lights=False,export_cameras=False,export_normals=True,export_uvmaps=False,export_subdivision='IGNORE',generate_preview_surface=True,convert_orientation=True,export_global_up_selection='Y',root_prim_path='/ArenaStudy',convert_world_material=False)
# Actual orthographic source review, matching the near-overhead reference composition.
bpy.ops.object.camera_add(location=cv((0,15,9)));cam=bpy.context.object;cam.rotation_euler=(Vector(cv((0,.10,0)))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=12.1;scene.camera=cam
world=bpy.data.worlds.new('Soft sky');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.28,.40,.50,1);world.node_tree.nodes['Background'].inputs[1].default_value=.7;scene.world=world
for name,p,power,size,c in [('Large warm sky',(-6,13,7),1750,7,(1,.92,.75)),('Cool sky bounce',(5,8,-3),800,8,(.65,.82,1))]:
 bpy.ops.object.light_add(type='AREA',location=cv(p));o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=c;o.rotation_euler=(Vector(cv((0,0,0)))-o.location).to_track_quat('-Z','Y').to_euler()
scene.render.filepath=str(out/'arena-composition.png');bpy.ops.render.render(write_still=True)
report={'source':str(source),'sourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'usdSHA256':hashlib.sha256(usd.read_bytes()).hexdigest(),'objects':len(parts),'materials':len(materials),'boundsGameMeters':{'width':8.8,'depth':11.3},'claim':'Original editable 3D scene composition study from supplied reference. Not a copied Clash Royale asset, accepted visual gate, completed gameplay integration or physical device test.'};(out/'scene-report.json').write_text(json.dumps(report,indent=2)+'\n');print('ARENA_COMPOSITION_COMPLETE',len(parts))
