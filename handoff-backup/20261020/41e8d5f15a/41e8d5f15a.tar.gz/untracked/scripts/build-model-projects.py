#!/usr/bin/env python3
"""Build editable Blender meshes, actual weighted skeletons and sampled native poses.

Run inside Blender, using -- --source SNAPSHOT --output DIRECTORY.
This uses the actual RealityKit vertex streams; no proxy replacement geometry.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import sys
from pathlib import Path

import bpy
from mathutils import Matrix, Vector

sys.path.insert(0, str(Path(__file__).resolve().parent))
from surface_colors import atlas_limits
from cloth_weights import cape_weight

spec = importlib.util.spec_from_file_location("model_usd", Path(__file__).with_name("export-models-usd.py"))
usd = importlib.util.module_from_spec(spec)
spec.loader.exec_module(usd)
# Native coordinates Y up, +Z front; Blender Z up, -Y front.
CONVERSION = Matrix.Rotation(math.pi / 2, 4, "X")
INVERSE = CONVERSION.inverted()
BONES = {name: name.replace("-", "_") for name in (
    "left-arm", "right-arm", "head", "left-thigh", "left-calf", "left-foot", "right-thigh", "right-calf", "right-foot", "cape")}


def native_matrix(columns):
    return Matrix(columns).transposed()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def surface_key(surface):
    return tuple(surface["colorSRGB"]) + (surface["roughness"], surface["metallic"])


def material(surface, cache):
    key = surface_key(surface)
    if key not in cache:
        c = surface["colorSRGB"]
        m = bpy.data.materials.new("Surface_" + str(len(cache)))
        m.use_nodes = True
        shader = m.node_tree.nodes.get("Principled BSDF")
        shader.inputs["Base Color"].default_value = tuple(usd.linear(x) for x in c[:3]) + (c[3],)
        shader.inputs["Roughness"].default_value = surface["roughness"]
        shader.inputs["Metallic"].default_value = surface["metallic"]
        m.diffuse_color = tuple(c)
        cache[key] = m
    return cache[key]


def flatten(data, root):
    """Each record retains its exact ancestor transform path and binding bone."""
    records = []
    rig_nodes = {}
    def walk(node, ancestors, group):
        path = ancestors + [node]
        if node["name"] in BONES:
            group = BONES[node["name"]]
            # Keep the actual nested source path. Excluding root avoids applying
            # its animation twice when deriving armature-local bone matrices.
            parent = next((BONES[n["name"]] for n in reversed(ancestors) if n["name"] in BONES), "body")
            rig_nodes[group] = {"node": node, "path": path[1:], "parent": parent}
        if "mesh" in node:
            resource = data["meshes"][node["mesh"]]
            models = {m["id"]: m for m in resource["models"]}
            for instance in resource["instances"]:
                for part in models[instance["model"]]["parts"]:
                    records.append((path, native_matrix(instance["matrixColumns"]), part, group, node["surface"]))
        for child in node["children"]:
            walk(child, path, group)
    walk(root, [], "body")
    return records, rig_nodes


def path_matrix(path, frame=None):
    result = Matrix.Identity(4)
    for node in path:
        columns = node["matrixColumns"]
        if frame is not None and "matrixSamples" in node:
            columns = node["matrixSamples"][frame]["matrixColumns"]
        result = result @ native_matrix(columns)
    return result


def orient(obj, target):
    direction = Vector(target) - obj.location
    obj.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()


def studio(scene):
    collection = bpy.data.collections.new("Review_Studio")
    scene.collection.children.link(collection)
    def add(obj):
        collection.objects.link(obj)
        return obj
    camera = add(bpy.data.objects.new("Review_Camera", bpy.data.cameras.new("Review_Camera")))
    camera.location = (2.3, -4.5, 2.7)
    camera.data.type = "ORTHO"
    camera.data.ortho_scale = 1.95
    orient(camera, (0, 0, .80))
    scene.camera = camera
    for name, pos, energy, size, color in [
        ("Warm_Key", (-3, -4, 5), 450, 4, (1, .86, .70)),
        ("Cool_Fill", (3, -1, 3), 200, 3, (.65, .80, 1)),
        ("Rim", (1, 3, 4), 350, 3, (1, .92, .80)),
    ]:
        light = add(bpy.data.objects.new(name, bpy.data.lights.new(name, "AREA")))
        light.location = pos
        light.data.energy = energy
        light.data.shape = "DISK"
        light.data.size = size
        light.data.color = color
        orient(light, (0, 0, .7))
    world = bpy.data.worlds.new("Review_World")
    world.use_nodes = True
    world.node_tree.nodes["Background"].inputs[0].default_value = (.055, .095, .12, 1)
    world.node_tree.nodes["Background"].inputs[1].default_value = .5
    scene.world = world
    scene.render.engine = "CYCLES"
    scene.cycles.samples = 32
    scene.render.resolution_x = 900
    scene.render.resolution_y = 1000
    scene.render.resolution_percentage = 100
    scene.view_settings.view_transform = "AgX"
    return camera


def pad_surface_atlas(obj, image, radius=8):
    """Fill subpixel islands/borders from their actual UV material ownership.

    Baking can miss tiny beveled faces entirely. Preserve valid bounded AO texels;
    fill only missing/foreign colors with that face's authored color at 0.90 AO.
    No geometry, skin weight or UV coordinate changes are made here.
    """
    import numpy as np
    width, height = image.size
    distances = np.full((height, width), np.inf, dtype=np.float32)
    owners = np.full((height, width), -1, dtype=np.int16)
    uv = obj.data.uv_layers.active.data
    for face in obj.data.polygons:
        if face.area < 1e-10: continue
        points = [(uv[i].uv.x * width - .5, uv[i].uv.y * height - .5) for i in face.loop_indices]
        if len(points) != 3: raise ValueError('Surface padding requires the authored triangle mesh')
        x0 = max(0, math.floor(min(p[0] for p in points) - radius))
        x1 = min(width - 1, math.ceil(max(p[0] for p in points) + radius))
        y0 = max(0, math.floor(min(p[1] for p in points) - radius))
        y1 = min(height - 1, math.ceil(max(p[1] for p in points) + radius))
        yy, xx = np.mgrid[y0:y1+1, x0:x1+1]
        signs, edges = [], []
        for i in range(3):
            a, b = points[i], points[(i + 1) % 3]
            dx, dy = b[0]-a[0], b[1]-a[1]
            denom = dx*dx + dy*dy
            fraction = np.clip(((xx-a[0])*dx + (yy-a[1])*dy) / max(denom, 1e-20), 0, 1)
            edges.append((xx-a[0]-fraction*dx)**2 + (yy-a[1]-fraction*dy)**2)
            signs.append(dx*(yy-a[1]) - dy*(xx-a[0]))
        distance = np.minimum.reduce(edges)
        area = (points[1][0]-points[0][0])*(points[2][1]-points[0][1]) - (points[1][1]-points[0][1])*(points[2][0]-points[0][0])
        if abs(area) > 1e-8:
            inside = np.logical_and.reduce([s >= -1e-8 if area > 0 else s <= 1e-8 for s in signs])
            distance[inside] = 0
        local = distances[y0:y1+1, x0:x1+1]
        replace = (distance < local) & (distance <= radius*radius)
        local[replace] = distance[replace]
        owners[y0:y1+1, x0:x1+1][replace] = face.material_index
    pixels = np.empty(len(image.pixels), dtype=np.float32); image.pixels.foreach_get(pixels)
    pixels = pixels.reshape(height, width, 4)
    # Non-float sRGB Image.pixels exposes encoded byte values, not shader-linear
    # color. Apply AO in linear space, then encode every bound/fallback.
    limits = np.array([atlas_limits(mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value[:3])
                       for mat in obj.data.materials])
    owned = owners >= 0
    expected = limits[owners[owned]]
    color = pixels[owned, :3]
    invalid = np.any((color < expected[:, 0] - .004) | (color > expected[:, 1] + .004), axis=1)
    color[invalid] = expected[invalid, 2]
    pixels[owned, :3] = color
    image.pixels.foreach_set(pixels.ravel()); image.update()
    return {'method': 'nearest authored UV triangle material; preserve valid bounded AO',
            'radiusPixels': radius, 'repairedTexels': int(invalid.sum()), 'fallbackAOMultiplier': .90,
            'pixelEncoding': 'byte sRGB; AO bounds and fallback encoded from linear authored colors'}


def bake_surfaces(obj, materials, hero, output, pad_atlas=False):
    """Original UV atlas, with bounded local AO baked into authored base colors.

    This preserves geometry/skin weights and per-material metallic/roughness.
    Lighting and exported textures are reviewed separately on the native device.
    """
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True); bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=.015, correct_aspect=True)
    bpy.ops.object.mode_set(mode="OBJECT")
    image = bpy.data.images.new(hero + "_Original_Surface_Atlas", width=1024, height=1024, alpha=False)
    image.colorspace_settings.name = "sRGB"
    links_to_restore = []
    for mat in materials.values():
        nodes, links = mat.node_tree.nodes, mat.node_tree.links
        shader = nodes.get("Principled BSDF")
        base = tuple(shader.inputs["Base Color"].default_value)
        target = nodes.new("ShaderNodeTexImage"); target.name = "Original_Surface_Atlas"
        target.image = image; target.select = True; nodes.active = target
        ao = nodes.new("ShaderNodeAmbientOcclusion"); ao.only_local = True
        ao.inputs["Distance"].default_value = .12
        amount = nodes.new("ShaderNodeMath"); amount.operation = "MULTIPLY"
        amount.inputs[1].default_value = .30; links.new(ao.outputs["AO"], amount.inputs[0])
        floor = nodes.new("ShaderNodeMath"); floor.operation = "ADD"
        floor.inputs[1].default_value = .70; links.new(amount.outputs[0], floor.inputs[0])
        color = nodes.new("ShaderNodeMixRGB"); color.blend_type = "MULTIPLY"
        color.inputs[0].default_value = 1; color.inputs[1].default_value = base
        links.new(floor.outputs[0], color.inputs[2])
        emission = nodes.new("ShaderNodeEmission"); links.new(color.outputs[0], emission.inputs["Color"])
        out = nodes.get("Material Output")
        links.new(emission.outputs[0], out.inputs["Surface"])
        links_to_restore.append((mat, target, shader, out, [ao, amount, floor, color, emission]))
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"; scene.cycles.samples = 64
    scene.render.bake.margin = 12
    bpy.ops.object.bake(type="EMIT")
    padding = pad_surface_atlas(obj, image) if pad_atlas else None
    textures = output / "textures"; textures.mkdir(parents=True, exist_ok=True)
    image.filepath_raw = str(textures / (hero.lower() + "-surface.png")); image.file_format = "PNG"
    image.save(); texture_sha = sha(image.filepath_raw)
    for mat, target, shader, out, temporary in links_to_restore:
        nodes, links = mat.node_tree.nodes, mat.node_tree.links
        links.new(shader.outputs["BSDF"], out.inputs["Surface"])
        for node in temporary: nodes.remove(node)
        links.new(target.outputs["Color"], shader.inputs["Base Color"])
        target.interpolation = "Linear"; nodes.active = target
    image.pack()
    uv = obj.data.uv_layers.active
    return {"kind": "original authored-color UV atlas with local AO", "texture": str(textures / (hero.lower() + "-surface.png")),
            "sha256": texture_sha, "resolution": [1024, 1024], "uvLoops": len(uv.data),
            "aoDistanceMeters": .12, "aoMultiplierRange": [.70, 1], "marginPixels": 12,
            "uvMaterialPadding": padding,
            "claim": "candidate contact shading, not final artist textures or physical-device validation"}


def build(data, hero, output, blend_sleeves=False, surface_atlas=False, pad_atlas=False, blend_cape=False):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.unit_settings.system = "METRIC"
    scene.render.fps = 30
    end_frame = data["animation"]["endTimeCode"]
    scene.frame_start, scene.frame_end = 0, end_frame
    root = data["models"][hero]
    records, nodes = flatten(data, root)
    vertices, faces, normals, groups, material_ids = [], [], [], [], []
    materials = {}
    offsets, arm_weights, edit_parts = [], [], []
    for path, instance, part, group, surface in records:
        # Bake rest geometry into armature space with the true instance transform.
        transform = CONVERSION @ path_matrix(path) @ instance
        normal_transform = transform.to_3x3().inverted().transposed()
        offset = len(vertices)
        offsets.append((offset, path, instance, part))
        vertices.extend(tuple(transform @ Vector(p)) for p in part["points"])
        normals.extend(tuple((normal_transform @ Vector(n)).normalized()) for n in part["normals"])
        groups.extend([group] * len(part["points"]))
        for point in part["points"]:
            y = (path_matrix(path) @ instance @ Vector(point)).y
            blend = blend_sleeves and part["id"].startswith("tailored-") and "sleeve" in part["id"]
            t = max(0, min(1, (.735 - y) / (.735 - .57)))
            arm_weights.append(cape_weight(y) if blend_cape and group == 'cape' else (t * t * (3 - 2 * t) if blend else 1))
        edit_parts.append({"name": part["id"], "offset": offset, "vertices": len(part["points"]), "bone": group})
        triangles = part["triangles"]
        faces.extend(tuple(offset + triangles[i + j] for j in range(3)) for i in range(0, len(triangles), 3))
        m = material(surface, materials)
        material_ids.extend([list(materials.values()).index(m)] * (len(triangles) // 3))
    mesh = bpy.data.meshes.new(hero + "_Native_Mesh")
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    for m in materials.values():
        mesh.materials.append(m)
    for face, index in zip(mesh.polygons, material_ids):
        face.material_index = index
        face.use_smooth = True
    mesh.normals_split_custom_set_from_vertices(normals)
    obj = bpy.data.objects.new(hero + "_Skin", mesh)
    scene.collection.objects.link(obj)
    for name in ["body", *nodes]:
        vg = obj.vertex_groups.new(name=name)
        vg.add([i for i, group in enumerate(groups) if group == name and arm_weights[i] == 1], 1, "REPLACE")
    for i, weight in enumerate(arm_weights):
        if weight != 1:
            if weight > 0: obj.vertex_groups[groups[i]].add([i], weight, "REPLACE")
            obj.vertex_groups["body"].add([i], 1 - weight, "REPLACE")
    # Named selection groups make individual modeled components editable after
    # packing the mobile skin into one mesh. These are not additional bones.
    for i, part in enumerate(edit_parts):
        vg = obj.vertex_groups.new(name=f"edit_{i:03d}_{part['name']}")
        vg.add(list(range(part["offset"], part["offset"] + part["vertices"])), 1, "REPLACE")
    obj["editable_part_map"] = json.dumps(edit_parts)
    armature = bpy.data.armatures.new(hero + "_Skeleton")
    rig = bpy.data.objects.new(hero + "_Rig", armature)
    scene.collection.objects.link(rig)
    bpy.context.view_layer.objects.active = rig
    rig.select_set(True)
    bpy.ops.object.mode_set(mode="EDIT")
    body = armature.edit_bones.new("body")
    body.matrix = CONVERSION.copy()
    body.length = .4
    for name, info in nodes.items():
        bone = armature.edit_bones.new(name)
        bone.matrix = CONVERSION @ path_matrix(info["path"])
        bone.length = .2
        bone.parent = armature.edit_bones[info["parent"]]
        bone.use_connect = False
    bpy.ops.object.mode_set(mode="OBJECT")
    rig.show_in_front = True
    rig.data.display_type = "STICK"
    modifier = obj.modifiers.new("Authored_Skeleton", "ARMATURE")
    modifier.object = rig
    obj.parent = rig
    rig.rotation_mode = "QUATERNION"
    for bone in rig.pose.bones:
        bone.rotation_mode = "QUATERNION"
    for frame in range(end_frame + 1):
        scene.frame_set(frame)
        root_sample = native_matrix(root["matrixSamples"][frame]["matrixColumns"])
        rig.matrix_world = CONVERSION @ root_sample @ INVERSE
        for path in ("location", "rotation_quaternion", "scale"):
            rig.keyframe_insert(path, frame=frame, group="Root")
        for name, info in nodes.items():
            # Bone rest axes match the original entity axes after coordinate conversion.
            rig.pose.bones[name].matrix = CONVERSION @ path_matrix(info["path"], frame)
            # Nested children must see this frame's evaluated parent matrix;
            # otherwise their absolute-matrix setter uses the previous frame.
            bpy.context.view_layer.update()
            for prop in ("location", "rotation_quaternion", "scale"):
                rig.pose.bones[name].keyframe_insert(prop, frame=frame, group=name)
    rig.animation_data.action.name = hero + ("_Authored_Idle_3p4s" if end_frame == 102 else "_Authored_Pose_1p4s")
    # Actually evaluate deformation at independent pose times and compare with native hierarchy.
    errors = []
    for frame in (0, round(end_frame / 7), round(end_frame * 2 / 7), end_frame // 2, round(end_frame * 5 / 7), end_frame):
        scene.frame_set(frame)
        bpy.context.view_layer.update()
        evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
        evaluated_mesh = evaluated.to_mesh()
        max_error = 0
        for offset, path, instance, part in offsets:
            target = CONVERSION @ path_matrix(path, frame) @ instance
            for i, point in enumerate(part["points"]):
                rigid_expected = target @ Vector(point)
                rest_native = path_matrix(path) @ instance @ Vector(point)
                root_sample = native_matrix(root["matrixSamples"][frame]["matrixColumns"])
                body_expected = CONVERSION @ root_sample @ native_matrix(root["matrixColumns"]).inverted() @ rest_native
                weight = arm_weights[offset + i]
                expected = rigid_expected * weight + body_expected * (1 - weight)
                actual = evaluated.matrix_world @ evaluated_mesh.vertices[offset + i].co
                max_error = max(max_error, (actual - expected).length)
        evaluated.to_mesh_clear()
        errors.append({"frame": frame, "maxVertexErrorMeters": max_error})
        if max_error > .00001:
            raise ValueError(f"{hero}: skin deformation differs from native frame {frame}: {max_error}")
    # Exact single-bone weights are an initial rigid skeleton, not organic smooth joint skinning.
    obj["candidate_status"] = "Cape shoulders pinned to body; hem and sleeves blend two bones; production acceptance pending" if blend_cape else ("Sleeves blend shoulder/body weights; production acceptance pending" if blend_sleeves else "Rigid weighted skeleton; joint blending and production acceptance pending")
    obj["source_sha256"] = hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()
    rig["animation_seconds"] = end_frame / 30
    rig["native_source"] = "TacticalGo RealityKit shared meshes and MiniaturePose"
    scene.frame_set(0)
    camera = studio(scene)
    output.mkdir(parents=True, exist_ok=True)
    surface = bake_surfaces(obj, materials, hero, output, pad_atlas=pad_atlas) if surface_atlas else None
    blend = output / (hero.lower() + ".blend")
    bpy.ops.wm.save_as_mainfile(filepath=str(blend))
    # Blender counts all vertex groups when reserving exported influence slots,
    # including named edit selections. Keep selections in .blend, but strip
    # them from this transient export session so mobile skins stay bounded.
    for group in list(obj.vertex_groups):
        if group.name.startswith("edit_"): obj.vertex_groups.remove(group)
    # Export only actual model and skeleton. Studio is solely the source-file review setup.
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    rig.select_set(True)
    bpy.context.view_layer.objects.active = rig
    usd_path = output / (hero.lower() + "-rig.usda")
    bpy.ops.wm.usd_export(
        filepath=str(usd_path), selected_objects_only=True, export_animation=True,
        export_armatures=True, only_deform_bones=True, export_shapekeys=False,
        export_lights=False, export_cameras=False, export_normals=True,
        export_uvmaps=surface_atlas, export_textures_mode="NEW" if surface_atlas else "KEEP",
        export_subdivision="IGNORE", generate_preview_surface=True,
        convert_orientation=True, export_global_up_selection="Y", root_prim_path="/" + hero,
        export_custom_properties=True, convert_world_material=False,
    )
    for frame, label in [(0, "rest"), (round(end_frame * 2 / 7), "pose")]:
        scene.frame_set(frame)
        scene.render.filepath = str(output / (hero.lower() + "-" + label + ".png"))
        bpy.ops.render.render(write_still=True)
    return {
        "hero": hero, "triangles": len(faces), "vertices": len(vertices),
        "bones": list(rig.pose.bones.keys()), "materials": len(materials),
        "editableParts": len(edit_parts), "blendedVertices": sum(0 < w < 1 for w in arm_weights),
        "capeVertices": sum(group == "cape" for group in groups),
        "mixedCapeVertices": sum(group == "cape" and 0 < weight < 1 for group, weight in zip(groups, arm_weights)),
        "bodyPinnedCapeVertices": sum(group == "cape" and weight == 0 for group, weight in zip(groups, arm_weights)),
        "weightSpec": {"sleevesBlended": blend_sleeves, "pinnedAboveY": .735, "fullyArmBelowY": .57, "blend": "smoothstep",
                       "capeBlended": blend_cape, "capePinnedAboveY": .665, "capeFullyFreeBelowY": .40},
        "surfaceAtlas": surface,
        "poseFrames": end_frame + 1, "poseSeconds": end_frame / 30, "deformationChecks": errors,
        "blend": str(blend), "blendSHA256": sha(blend), "usd": str(usd_path), "usdSHA256": sha(usd_path),
        "claim": "editable mesh, hierarchical skin, body-pinned cape and bounded sleeve blending; not cloth physics/full organic production skin or owner approval" if blend_cape else ("editable mesh, actual hierarchical skin and bounded sleeve blending; not full organic production skin or owner approval" if blend_sleeves else "editable meshes and rigid single-bone weighted skeleton; not blended skin or owner approval"),
    }


def main():
    args = sys.argv[sys.argv.index("--") + 1:]
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--hero", choices=["Warrior", "Mage", "Rogue"])
    parser.add_argument("--blend-sleeves", action="store_true", help="Blend cloth shoulder vertices to body while hands/props stay rigid")
    parser.add_argument("--blend-cape", action="store_true", help="Pin cloak shoulders to body and smoothly blend lower cloth to the cape bone")
    parser.add_argument("--surface-atlas", action="store_true", help="Create original UV/color atlas with bounded local contact shading")
    parser.add_argument("--pad-atlas", action="store_true", help="Fill missed subpixel UV faces and borders from their actual material ownership")
    opt = parser.parse_args(args)
    data = json.loads(opt.source.read_text())
    usd.validate(data)
    if opt.pad_atlas and not opt.surface_atlas: parser.error('--pad-atlas requires --surface-atlas')
    results = [build(data, hero, opt.output.resolve(), blend_sleeves=opt.blend_sleeves, surface_atlas=opt.surface_atlas, pad_atlas=opt.pad_atlas, blend_cape=opt.blend_cape) for hero in ([opt.hero] if opt.hero else ["Warrior", "Mage", "Rogue"])]
    report = {"schema": "tacticalgo-blender-projects.v1", "sourceSHA256": sha(opt.source),
              "blender": bpy.app.version_string, "builderSHA256": sha(__file__), "assets": results}
    path = opt.output / ("build-report-" + (opt.hero.lower() if opt.hero else "all") + ".json")
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
