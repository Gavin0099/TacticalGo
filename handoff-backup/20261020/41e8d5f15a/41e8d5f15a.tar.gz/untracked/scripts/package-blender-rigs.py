#!/usr/bin/env python3
"""Validate and package the three authored Blender skeleton USD candidates."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("directory",type=Path)
parser.add_argument("--evidence",required=True,type=Path)
args=parser.parse_args()
args.evidence.mkdir(parents=True,exist_ok=True)
results=[]
for hero in ["warrior","mage","rogue"]:
    asset=args.directory/(hero+"-rig.usda")
    steps=[["usdchecker","--strict",str(asset)],["usdcat","-o",str(asset.with_suffix(".usdc")),str(asset)],
           ["usdzip","--arkitAsset",str(asset.with_suffix(".usdc")),str(asset.with_suffix(".usdz"))],
           ["usdchecker","--arkit","--strict",str(asset.with_suffix(".usdz"))]]
    for i,command in enumerate(steps):
        r=subprocess.run(command,capture_output=True,text=True)
        (args.evidence/f"{hero}-rig-step-{i}.log").write_text(r.stdout+r.stderr)
        if r.returncode: raise RuntimeError(f"{hero}, step {i}: exit {r.returncode}")
    package=asset.with_suffix(".usdz")
    results.append({"hero":hero,"usdaSHA256":hashlib.sha256(asset.read_bytes()).hexdigest(),
                    "usdzSHA256":hashlib.sha256(package.read_bytes()).hexdigest(),"usdzBytes":package.stat().st_size,
                    "validationExits":[0]*4})
report={"createdAt":datetime.now(timezone.utc).isoformat(),"assets":results,
        "claim":"validated skeleton packages; native playback and owner acceptance remain separate"}
(args.evidence/"rig-package-report.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
