#!/usr/bin/env python3
"""Capture actual iPhone simulator play layouts; never synthesize their contents."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time
import uuid

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--device', required=True)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--shadow-cull', choices=['front', 'back', 'none'], help='DEBUG shadow-map comparison; omit for default')
parser.add_argument('--app', type=Path, default=Path('ios/Build/Products/Debug-iphonesimulator/TacticalGo.app'))
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
if (args.output / 'capture-manifest.json').exists():
    raise SystemExit('Refusing to overwrite existing review evidence')
def inputs(app):
    return {'debugLibrarySHA256': hashlib.sha256((app / 'TacticalGo.debug.dylib').read_bytes()).hexdigest(),
            'models': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (app / 'Models').glob('*.usdz')}}

original_inputs = inputs(args.app)
subprocess.run(['xcrun', 'simctl', 'install', args.device, str(args.app)], check=True)
installed = Path(subprocess.check_output(['xcrun', 'simctl', 'get_app_container', args.device, 'com.tacticalgo.prototype', 'app'], text=True).strip())
if inputs(installed) != original_inputs or inputs(args.app) != original_inputs:
    raise SystemExit('Build inputs changed during install; do not capture while building')
documents = Path(subprocess.check_output(['xcrun', 'simctl', 'get_app_container', args.device, 'com.tacticalgo.prototype', 'data'], text=True).strip()) / 'Documents'
subprocess.run(['xcrun', 'simctl', 'status_bar', args.device, 'override', '--time', '9:41',
                '--dataNetwork', 'wifi', '--wifiMode', 'active', '--wifiBars', '3',
                '--batteryState', 'charged', '--batteryLevel', '100'], check=True)
captures = []
for size in (7, 9):
    for scene in ('normal', 'skill', 'danger'):
        path = args.output / f'{size}x{size}-{scene}.png'
        if path.exists(): raise SystemExit(f'Refusing to overwrite {path}')
        flags = (['--nine'] if size == 9 else []) + ([] if scene == 'normal' else ['--' + scene])
        if args.shadow_cull: flags += ['--shadow-cull', args.shadow_cull]
        token = str(uuid.uuid4())
        flags += ['--capture-ready-token', token]
        subprocess.run(['xcrun', 'simctl', 'terminate', args.device, 'com.tacticalgo.prototype'], capture_output=True)
        launched = subprocess.check_output(['xcrun', 'simctl', 'launch', args.device, 'com.tacticalgo.prototype', *flags], text=True)
        pid = int(launched.strip().rsplit(':', 1)[1])
        def alive():
            processes = subprocess.check_output(['xcrun', 'simctl', 'spawn', args.device, 'launchctl', 'list'], text=True)
            return any(line.split() and line.split()[0] == str(pid) for line in processes.splitlines())
        (args.output / f'{size}x{size}-{scene}-launch.json').write_text(json.dumps(
            {'pid': pid, 'launchArguments': flags, 'installedInputs': original_inputs}, indent=2) + '\n')
        ready = documents / ('capture-ready-' + token + '.json')
        for attempt in range(150):
            if ready.exists(): break
            if attempt % 10 == 0 and not alive():
                raise SystemExit(f'App exited before board readiness: {size}/{scene}; launch evidence retained')
            time.sleep(.2)
        else: raise SystemExit(f'Requested native board did not become active/mounted: {size}/{scene}')
        receipt = json.loads(ready.read_text())
        if not receipt.get('foreground'):
            raise SystemExit('Native board receipt is not foreground')
        (args.output / f'{size}x{size}-{scene}-readiness.json').write_text(json.dumps(receipt, indent=2) + '\n')
        # Readiness is structural, not proof of pixels. Allow rendering time,
        # retain the original screenshot, and manually inspect each scene.
        time.sleep(2)
        if not alive(): raise SystemExit(f'App exited after readiness: {size}/{scene}; no successful capture manifest')
        subprocess.run(['xcrun', 'simctl', 'io', args.device, 'screenshot', str(path)], check=True)
        captures.append({'size': size, 'scene': scene, 'pid': pid, 'launchArguments': flags, 'path': path.name,
                         'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'nativeReady': receipt})
if inputs(installed) != original_inputs or inputs(args.app) != original_inputs:
    raise SystemExit('Build inputs changed during capture; evidence retained, no successful manifest')
manifest = {'device': args.device, 'capturedAtUnix': time.time(),
            'appExecutableSHA256': hashlib.sha256((args.app / 'TacticalGo').read_bytes()).hexdigest(),
            'installedInputs': original_inputs,
            'source': 'native simulator screenshots; no compositing', 'captures': captures}
(args.output / 'capture-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(f'Captured {len(captures)} native review screens in {args.output}')
