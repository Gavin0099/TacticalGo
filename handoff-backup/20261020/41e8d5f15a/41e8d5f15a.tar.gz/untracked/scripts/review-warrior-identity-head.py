"""Owner requested source/render/50% overlay/matte QA; no image repainting.
No automatic identity approval. Source alpha is restricted by manual head ROI.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np,json,hashlib,sys
REV=sys.argv[1] if len(sys.argv)>1 else 'v01';assert REV in ['v01','v02']
R=Path(__file__).resolve().parents[1];A=R/('assets/candidates/warrior-identity-head-'+REV);Q=R/('artifacts/ios/warrior-identity-head-'+REV)
ref=Image.open(R/'assets/candidates/vis-feel-01/tokens/B-warrior-v02.png').convert('RGBA');render=Image.open(A/'source-view-512.png').convert('RGBA');side=Image.open(A/'side-depth-512.png').convert('RGBA')
assert ref.size==render.size==(512,512)
# Manual ROI only separates head from adjacent scarf/armor. Alpha inside ROI is
# sampled from source pixels, NOT a copied render shape. Boundary near jaw is
# a human estimate and the metric therefore is a diagnostic, not an exact label.
roi=Image.new('L',(512,512));d=ImageDraw.Draw(roi)
outline=[(110,28),(381,28),(381,178),(350,192),(351,213),(333,220),(327,232),(307,231),(297,220),(279,237),(260,251),(241,257),(221,256),(200,244),(187,232),(177,235),(165,225),(148,216),(128,202),(110,185)]
d.polygon(outline,fill=255);roi.save(Q/'source-head-roi-mask.png')
sourcealpha=np.array(ref.getchannel('A'));sourcealpha=np.where(np.array(roi)>0,sourcealpha,0).astype('uint8');ref.putalpha(Image.fromarray(sourcealpha))
ref.save(Q/'source-head-fullcanvas.png')
crop=(105,28,385,260)
for name,im in [('reference-head',ref),('aligned-head',render)]:im.crop(crop).save(Q/f'{name}.png')
bg=Image.new('RGBA',(512,512),'#37434b');rb=Image.alpha_composite(bg,ref);mb=Image.alpha_composite(bg,render)
Image.blend(rb,mb,.5).crop(crop).save(Q/'overlay-50.png')
sm=sourcealpha>127;rm=np.array(render.getchannel('A'))>127
def bbox(m):
 y,x=np.where(m);return [int(x.min()),int(y.min()),int(x.max()+1),int(y.max()+1)]
def centroid(m):
 y,x=np.where(m);return [float(x.mean()),float(y.mean())]
intersection=int((sm&rm).sum());union=int((sm|rm).sum());iou=intersection/union
delta=Image.new('RGB',(512,512),'#242b31');pix=np.array(delta);pix[sm&rm]=[180,180,180];pix[sm&~rm]=[255,255,255];pix[rm&~sm]=[70,70,70];delta=Image.fromarray(pix);delta.crop(crop).save(Q/'silhouette-difference.png')
gray=Image.new('RGB',(560,232),'#242b31')
for i,m in enumerate([sm,rm]):
 a=Image.fromarray((m*255).astype('uint8')).crop(crop);gray.paste(a,(i*280,0))
gray.save(Q/'grayscale-silhouette-comparison.png')
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18)
sheet=Image.new('RGB',(1200,650),'#37434b');dr=ImageDraw.Draw(sheet)
panels=[('B-v02 source head (actual 512 derivative)',Q/'reference-head.png'),('3D source-view candidate (actual render)',Q/'aligned-head.png'),('50% overlay - no free recrop or warp',Q/'overlay-50.png'),('Silhouette: white source / dark extra render',Q/'silhouette-difference.png')]
for i,(label,p) in enumerate(panels):
 x=25+(i%2)*600;y=50+(i//2)*315
 # Half-height source crop displayed at uniform 1.1x scale, same in every panel.
 im=Image.open(p).convert('RGBA').resize((308,253),Image.Resampling.LANCZOS);sheet.paste(im,(x+125,y),im);dr.text((x,y-30),label,font=font,fill='white')
sheet.save(Q/'comparison.png')
small=Image.new('RGB',(500,260),'#37434b');dr=ImageDraw.Draw(small)
for row,n in enumerate([128,64]):
 for col,p in enumerate([Q/'reference-head.png',Q/'aligned-head.png']):
  im=Image.open(p).convert('RGBA');im.thumbnail((n,n),Image.Resampling.LANCZOS);small.paste(im,(80+col*230,30+row*140),im)
 dr.text((8,30+row*140),f'{n}px',font=font,fill='white')
small.save(Q/'small-readability-only.png')
metrics={'reference_mask':'actual B-v02 alpha intersect manually annotated head ROI','reference_crop_px':list(crop),'render_transform_for_comparison':'none, same fixed512 camera canvas; identical crop for all panels','mask_threshold':127,'iou':iou,'target':.82,'silhouette_diagnostic':'meets diagnostic target' if iou>=.82 else 'below diagnostic target','reference_bbox':bbox(sm),'render_bbox':bbox(rm),'reference_centroid':centroid(sm),'render_centroid':centroid(rm),'identity_gate':'PENDING_OWNER, no automatic pass','landmarks':'camera control coordinates are NOT independent rendered-feature measurements','source_ROI_uncertainty':'jaw/hair overlap/manual scarf exclusion; no multi-view reference','side_depth':'all unseen depth inferred, no authoritative side reference','bitmap_projection_on_mesh':False}
(Q/'silhouette-diagnostic.json').write_text(json.dumps(metrics,indent=2)+'\n')
files=[*A.glob('*'),*Q.glob('*.png'),Q/'reference_manifest.json',Q/'camera-registration.json',Q/'silhouette-diagnostic.json'];manifest=[]
for p in files:
 if p.is_file():manifest.append({'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(Q/'artifact-manifest.json').write_text(json.dumps({'files':manifest,'approval':'pending_owner','production':'unavailable'},indent=2)+'\n')
print(json.dumps(metrics,indent=2))
