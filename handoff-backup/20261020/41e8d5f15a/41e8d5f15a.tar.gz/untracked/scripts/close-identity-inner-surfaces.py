"""Observed native rear-face culling: closed head core and clothed arm underlays.
Preserve source identity and all 43 class-keyed frames; do not treat strict USD as art QA.
"""
import bpy,json,hashlib,math,sys
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];hero=sys.argv[sys.argv.index('--')+1];out=root/'assets/candidates/ios-identity-motion-v05'/hero;out.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(root/'assets/candidates/ios-identity-motion-v04'/hero/(hero+'.blend')));scene=bpy.context.scene;rig=next(o for o in scene.objects if o.type=='ARMATURE');scene.frame_set(0)
def closed_sphere(name,p,s,material,bone):
 bpy.ops.object.select_all(action='DESELECT');bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=20,location=p);o=bpy.context.object;o.name=name;o.scale=s;bpy.ops.object.transform_apply(location=True,rotation=True,scale=True);o.data.materials.append(bpy.data.materials[material]);o.parent=rig;o.vertex_groups.new(name=bone).add(list(range(len(o.data.vertices))),1,'REPLACE');o.modifiers.new('Closed surface binding','ARMATURE').object=rig
 for f in o.data.polygons:f.use_smooth=True
 return o
closed_sphere('Closed anatomical head core',(0,.075,1.58),(.340,.265,.315),'Warm youthful complexion','head')
upperMaterial={'warrior':'Cream woven tunic','mage':'Plum cloak and hat','rogue':'Cream woven tunic'}[hero];lowerMaterial='Plum cloak and hat' if hero=='mage' else 'Chestnut leather'
for side,sign in [('l',1),('r',-1)]:
 closed_sphere('Inner sleeve upper '+side,(sign*.37,0,1.1068),(.185,.108,.108),upperMaterial,'upperarm.'+side)
 closed_sphere('Inner sleeve lower '+side,(sign*.60,0,1.1068),(.165,.082,.082),lowerMaterial,'lowerarm.'+side)
parts=[o for o in scene.objects if o.type=='MESH'];source=out/(hero+'.blend');bpy.ops.wm.save_as_mainfile(filepath=str(source));samples=[];rest=None
for frame in [0,9,21,33,42]:
 scene.frame_set(frame);bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();points=[]
 for o in parts:points.extend(tuple(o.matrix_world@v.co) for v in o.evaluated_get(dg).data.vertices)
 assert all(math.isfinite(c) for p in points for c in p)
 if rest is None:rest=points
 samples.append({'frame':frame,'vertices':len(points),'maxDisplacementMeters':max(math.dist(a,b) for a,b in zip(rest,points))})
assert samples[-1]['maxDisplacementMeters']<1e-5
scene.frame_set(0);bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=rig
usd=out/(hero+'-rig.usda');bpy.ops.wm.usd_export(filepath=str(usd),selected_objects_only=True,export_animation=True,export_armatures=True,only_deform_bones=True,export_shapekeys=False,export_lights=False,export_cameras=False,export_normals=True,export_uvmaps=True,export_textures_mode='NEW',export_subdivision='IGNORE',generate_preview_surface=True,convert_orientation=True,export_global_up_selection='Y',root_prim_path='/'+hero.title()+'Identity',convert_world_material=False)
report={'class':hero,'change':'Closed head back/inner arms from actual native back-face QA; genuine meshes not transparency overrides','sourceBlendSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'usdSHA256':hashlib.sha256(usd.read_bytes()).hexdigest(),'frames':43,'durationSeconds':1.4,'joints':list(rig.data.bones.keys()),'samples':samples,'notClaimed':['Owner quality acceptance','production topology','native timing parity','physical device','23-joint gameplay adapter']};(out/'motion-report.json').write_text(json.dumps(report,indent=2)+'\n')
scene.cycles.samples=20;cam=scene.camera;cam.location=(2.1,5,1.8);cam.rotation_euler=(Vector((0,0,.65))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/'rest-back.png');bpy.ops.render.render(write_still=True);print('CLOSED_NATIVE_SURFACES_COMPLETE',hero)
