#!/usr/bin/env python3
"""Blender: preserve exact native infantry/commander geometry in editable projects."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import bpy
from mathutils import Vector


def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()


def aim(obj, target): obj.rotation_euler = (Vector(target) - obj.location).to_track_quat('-Z', 'Y').to_euler()


def build(source, output, name, expected):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    path = source / expected['file']
    bpy.ops.wm.usd_import(filepath=str(path), import_cameras=False, import_lights=False)
    scene = bpy.context.scene
    meshes = [obj for obj in scene.objects if obj.type == 'MESH']
    triangles = sum(sum(len(face.vertices) - 2 for face in obj.data.polygons) for obj in meshes)
    if triangles != expected['triangles'] or len(meshes) != expected['meshParts']:
        raise ValueError(f'Native unit counts differ: {name}')
    scene['source_sha256'] = sha(path)
    scene['claim'] = 'original static miniature, whole-unit presentation transforms; no skeletal rig claim'
    review = bpy.data.collections.new('Review_Studio'); scene.collection.children.link(review)
    camera = bpy.data.objects.new('Review_Camera', bpy.data.cameras.new('Review_Camera')); review.objects.link(camera)
    scene.camera = camera; camera.location = (.8, -2.8, 1.7)
    camera.data.type = 'ORTHO'; camera.data.ortho_scale = .90
    aim(camera, (0, 0, .36))
    for label, loc, energy, tint in [('Warm_Key',(-2,-3,4),160,(1,.91,.78)),('Cool_Fill',(2,1,3),75,(.65,.80,1))]:
        light = bpy.data.objects.new(label,bpy.data.lights.new(label,'AREA')); review.objects.link(light)
        light.location=loc;light.data.energy=energy;light.data.color=tint;light.data.size=3;aim(light,(0,0,.36))
    world = bpy.data.worlds.new('Review_World'); world.use_nodes=True
    world.node_tree.nodes['Background'].inputs[0].default_value=(.055,.095,.12,1)
    world.node_tree.nodes['Background'].inputs[1].default_value=.5;scene.world=world
    scene.render.engine='CYCLES';scene.cycles.samples=32
    scene.render.resolution_x=700;scene.render.resolution_y=800;scene.render.resolution_percentage=100
    scene.view_settings.view_transform='AgX';output.mkdir(parents=True,exist_ok=True)
    blend=output/(name.lower()+'.blend');bpy.ops.wm.save_as_mainfile(filepath=str(blend))
    for side in ['front','back']:
        if side=='back':camera.location=(-.8,2.8,1.7);aim(camera,(0,0,.36))
        scene.render.filepath=str(output/(name.lower()+'-'+side+'.png'));bpy.ops.render.render(write_still=True)
    return {'name':name,'triangles':triangles,'meshObjects':len(meshes),'sourceSHA256':sha(path),'blendSHA256':sha(blend),'nativeCountsMatched':True}


parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source',required=True,type=Path);parser.add_argument('--output',required=True,type=Path)
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:])
manifest=json.loads((args.source/'manifest.json').read_text())
rows=[build(args.source.resolve(),args.output.resolve(),name,asset) for name,asset in manifest['assets'].items()]
(args.output/'build-report.json').write_text(json.dumps({'blender':bpy.app.version_string,'builderSHA256':sha(Path(__file__)),'assets':rows},indent=2)+'\n')
