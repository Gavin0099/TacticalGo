"""Reopen the saved editable source; inspect actual evaluated geometry, scope and materials."""
import bpy,bmesh,json,math,hashlib,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];version=sys.argv[sys.argv.index('--')+1] if '--' in sys.argv else 'warrior-bust-bv02-v01';out=root/'assets/candidates'/version;evidence=root/'artifacts/ios/warrior-bust-bv02-v01'
bpy.ops.wm.open_mainfile(filepath=str(out/'warrior-bust.blend'));dg=bpy.context.evaluated_depsgraph_get();meshes=[]
assert not any(o.type=='ARMATURE' for o in bpy.context.scene.objects),'Static bust must not add a rig'
assert len(bpy.data.actions)==0,'No animation authorized'
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 assert not any(t in o.name.lower() for t in ['leg','boot','foot','hips','skirt']),(o.name,'Lower body outside authorized scope')
 evaluated=o.evaluated_get(dg);me=evaluated.to_mesh();v=[tuple(o.matrix_world@p.co) for p in me.vertices];assert all(math.isfinite(c) for p in v for c in p),o.name
 bm=bmesh.new();bm.from_mesh(me);boundary=sum(e.is_boundary for e in bm.edges);nonmanifold=sum(not e.is_manifold for e in bm.edges);degenerate=sum(f.calc_area()<1e-12 for f in bm.faces);bm.free()
 meshes.append({'name':o.name,'vertices':len(v),'faces':len(me.polygons),'boundaryEdges':boundary,'nonManifoldEdges':nonmanifold,'degenerateFaces':degenerate,'bounds':[[min(p[i] for p in v) for i in range(3)],[max(p[i] for p in v) for i in range(3)]]});evaluated.to_mesh_clear()
assert meshes
assert any(m['name']=='B-v02 traced gold branching relief' for m in meshes)
assert not any('castle' in m['name'].lower() for m in meshes)
mats=[]
for m in bpy.data.materials:
 if not m.use_nodes:continue
 s=m.node_tree.nodes.get('Principled BSDF')
 if s:mats.append({'name':m.name,'metallic':s.inputs['Metallic'].default_value,'roughness':s.inputs['Roughness'].default_value})
assert next(m for m in mats if m['name']=='Brushed silver pauldron')['metallic']>.7
assert next(m for m in mats if m['name']=='Woven deep teal')['metallic']==0
ref=root/'assets/candidates/vis-feel-01/tokens/B-warrior-v02.png';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(ref)=='50885855dc9faee8966558ea854f99d24bd0ffd0ed93c03bb6b87c8643d42298'
report={'editableSourceSHA256':sha(out/'warrior-bust.blend'),'referenceSHA256':sha(ref),'meshObjects':len(meshes),'vertices':sum(m['vertices'] for m in meshes),'rigCount':0,'actionCount':0,'lowerBodyCount':0,'meshes':meshes,'materials':mats,'camera':{'type':bpy.context.scene.camera.data.type,'scale':bpy.context.scene.camera.data.ortho_scale,'target':'(.12,0,1.55)','views':'front/three-quarter/side, same orthographic scale and unchanged key/fill/rim'},'nonManifoldMeshCount':sum(m['nonManifoldEdges']>0 for m in meshes),'notClaimed':['same-person visual acceptance','1254 original used','retopology for game','material parity in RealityKit','new iOS integration','no intersections at every hidden surface']}
(evidence/('geometry-audit-v02.json' if version.endswith('v02') else 'geometry-audit.json')).write_text(json.dumps(report,indent=2)+'\n');print('STATIC_EDITABLE_BUST_AUDIT',report['meshObjects'],report['vertices'],'nonmanifoldMeshes',report['nonManifoldMeshCount'])
