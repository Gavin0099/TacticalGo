"""Reopen actual candidate, verify scope/depth/projection, not character acceptance."""
import bpy,json,math,hashlib
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
R=Path(__file__).resolve().parents[1];A=R/'assets/candidates/warrior-identity-head-v02';Q=R/'artifacts/ios/warrior-identity-head-v02'
bpy.ops.wm.open_mainfile(filepath=str(A/'warrior-head.blend'));s=bpy.context.scene
meshes=[o for o in s.objects if o.type=='MESH'];coords=[o.matrix_world@v.co for o in meshes for v in o.data.vertices]
rigs=[o.name for o in s.objects if o.type=='ARMATURE'];images=[n.name for m in bpy.data.materials if m.use_nodes for n in m.node_tree.nodes if n.type=='TEX_IMAGE']
depth=max(v.y for v in coords)-min(v.y for v in coords)
registration=json.loads((Q/'camera-registration.json').read_text());drift={k:math.dist(x['reference_px'],x['projected_control_px']) for k,x in registration['landmarks'].items()}
# Project actual smile triangles, not merely the requested input polygon.
smile=next(o for o in meshes if o.name=='SMILE asymmetric line');triangles=[]
for p in smile.data.polygons:
 triangle=[]
 for i in p.vertices:
  v=world_to_camera_view(s,s.camera,smile.matrix_world@smile.data.vertices[i].co);triangle.append([v.x*512,(1-v.y)*512])
 triangles.append(triangle)
audit={'blend_sha256':hashlib.sha256((A/'warrior-head.blend').read_bytes()).hexdigest(),'mesh_objects':len(meshes),'mesh_names':[o.name for o in meshes],'finite_vertices':all(all(math.isfinite(c) for c in v) for v in coords),'mesh_world_depth':depth,'armatures':rigs,'actions':len(bpy.data.actions),'image_texture_material_nodes':images,'visible_source_control_projection_max_px':max(drift.values()),'projection_limit':'by construction; not independent face detector','smile_method':smile.get('contour_method'),'smile_actual_projected_triangles':triangles,'identity':'PENDING_OWNER','quality_claim':'no topology/performance or identity acceptance claim'}
assert audit['finite_vertices'] and depth>1 and not rigs and len(bpy.data.actions)==0 and not images
assert all(o.name.startswith(('HEAD ','EAR ','HAIR ','EYE ','IRIS ','PUPIL ','GLINT ','BROW ','SMILE ','NOSTRIL ','FRECKLE ')) for o in meshes)
assert max(drift.values())<.001
(Q/'actual-mesh-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print('HEAD_ONLY_ACTUAL_BLEND_REOPENED',len(meshes),'meshes, world depth',depth,'control projection max',max(drift.values()))
