#!/usr/bin/env python3
"""Inside Blender: preserve native USD arena hierarchy in editable review projects."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import bpy
from mathutils import Vector


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def aim(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat('-Z', 'Y').to_euler()


def build(source, output, size, expected):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    usd = source / f'arena{size}.usda'
    bpy.ops.wm.usd_import(filepath=str(usd), import_cameras=False, import_lights=False)
    meshes = [obj for obj in scene.objects if obj.type == 'MESH']
    triangles = sum(sum(len(face.vertices) - 2 for face in obj.data.polygons) for obj in meshes)
    if triangles != expected['triangles'] or len(meshes) != expected['meshParts']:
        raise ValueError(f'Native USD geometry count mismatch: {size}, {triangles}, {len(meshes)}')
    scene['source_sha256'] = sha(usd)
    scene['status'] = 'original candidate; native USD hierarchy, Owner approval pending'
    review = bpy.data.collections.new('Review_Studio'); scene.collection.children.link(review)
    camera = bpy.data.objects.new('Review_Camera', bpy.data.cameras.new('Review_Camera'))
    review.objects.link(camera); scene.camera = camera
    camera.location = (size * .20, -size * .60, size * 1.10)
    camera.data.type = 'ORTHO'; camera.data.ortho_scale = size * 1.4 + 1.5
    aim(camera, (0, 0, 0))
    for name, location, energy, tint in (
        ('Warm_Key',(-size, -size, size * 1.8), 90 * size ** 2, (1, .91, .78)),
        ('Cool_Fill',(size, 0, size), 35 * size ** 2, (.65, .80, 1)),
    ):
        light = bpy.data.objects.new(name, bpy.data.lights.new(name, 'AREA')); review.objects.link(light)
        light.location = location; light.data.energy = energy; light.data.size = size
        light.data.color = tint; aim(light, (0, 0, 0))
    world = bpy.data.worlds.new('Review_World'); world.use_nodes = True
    world.node_tree.nodes['Background'].inputs[0].default_value = (.055, .095, .12, 1)
    world.node_tree.nodes['Background'].inputs[1].default_value = .5; scene.world = world
    scene.render.engine = 'CYCLES'; scene.cycles.samples = 32
    scene.render.resolution_x = 1000; scene.render.resolution_y = 1100
    scene.render.resolution_percentage = 100; scene.view_settings.view_transform = 'AgX'
    output.mkdir(parents=True, exist_ok=True)
    blend = output / f'arena{size}.blend'
    bpy.ops.wm.save_as_mainfile(filepath=str(blend))
    scene.render.filepath = str(output / f'arena{size}-review.png'); bpy.ops.render.render(write_still=True)
    return {'size':size,'source':str(usd),'sourceSHA256':sha(usd),'blend':str(blend),'blendSHA256':sha(blend),
            'triangles':triangles,'meshObjects':len(meshes),'nativeCountsMatched':True,
            'claim':'editable static scenery imported from actual native mesh streams; not game physics or Owner approval'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    opt = parser.parse_args(sys.argv[sys.argv.index('--') + 1:])
    manifest = json.loads((opt.source / 'manifest.json').read_text())
    rows = [build(opt.source.resolve(), opt.output.resolve(), n, manifest['assets'][f'Arena{n}']) for n in (7, 9)]
    (opt.output / 'build-report.json').write_text(json.dumps({'blender':bpy.app.version_string,'assets':rows},indent=2)+'\n')


if __name__ == '__main__':
    main()
