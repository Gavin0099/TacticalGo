"""Targeted pose, material-slot and youthful nose repair; candidate remains unapproved."""
import bpy,bmesh,json,math,hashlib
from collections import defaultdict,Counter
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];out=root/'assets/candidates/ios-identity-v01/warrior-likeness';out.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(root/'assets/candidates/ios-identity-v01/warrior-refined/warrior.blend'))
scene=bpy.context.scene;rig=bpy.data.objects['Warrior_Identity_Rig'];scene.frame_set(1);bpy.context.view_layer.update()
materialRepairs=[]
for o in scene.objects:
 if o.type=='MESH' and len(o.data.materials)==1:
  counts=Counter(p.material_index for p in o.data.polygons)
  if set(counts)!={0}:materialRepairs.append({'name':o.name,'before':dict(counts)})
  for p in o.data.polygons:p.material_index=0
head=bpy.data.objects['Knight_Head'];m=head.data;adj=defaultdict(set)
for e in m.edges:a,b=e.vertices;adj[a].add(b);adj[b].add(a)
remaining=set(range(len(m.vertices)));remove=[]
while remaining:
 todo=[next(iter(remaining))];ids=set()
 while todo:
  i=todo.pop()
  if i in ids:continue
  ids.add(i);remaining.discard(i);todo.extend(adj[i]-ids)
 if len(ids) in [6,35]:remove.extend(ids)
bm=bmesh.new();bm.from_mesh(m);bm.verts.ensure_lookup_table();bmesh.ops.delete(bm,geom=[bm.verts[i] for i in remove],context='VERTS');bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(m);bm.free()
# Rounded small nose with close face contact, skinned to head.
bpy.ops.object.select_all(action='DESELECT');bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=16,location=(0,-.40,1.555));nose=bpy.context.object;nose.name='Youthful round nose';nose.scale=(.048,.046,.041);bpy.ops.object.transform_apply(location=True,rotation=True,scale=True);nose.data.materials.append(bpy.data.materials['Warm youthful complexion'])
for p in nose.data.polygons:p.use_smooth=True
nose.parent=rig;nose.vertex_groups.new(name='head').add(list(range(len(nose.data.vertices))),1,'REPLACE');nose.modifiers.new('Nose head binding','ARMATURE').object=rig
# Bring eye whites into the face to avoid floating eyeballs.
for o in scene.objects:
 if o.type=='MESH' and any(t in o.name for t in ['Almond eye','Brown iris','Dark pupil','Eye catchlight','Upper eyelid']):
  for v in o.data.vertices:v.co.y+=.012
# Head proportion nearer the full body original (about 2.7 heads instead of 2).
headObjects=[]
for o in scene.objects:
 if o.type=='MESH' and 'head' in o.vertex_groups and all(all(g.group==o.vertex_groups['head'].index for g in v.groups) for v in o.data.vertices):
  for v in o.data.vertices:v.co=Vector((v.co.x*.85,v.co.y*.85,1.241+(v.co.z-1.241)*.85))
  headObjects.append(o.name)
# Place shield upright at left hand and sword down at right, then bind inverse pose.
for o in scene.objects:
 if o.type!='MESH':continue
 bone='handslot.l' if any(t in o.name for t in ['shield','heraldry']) else ('handslot.r' if any(t in o.name for t in ['sword','Sword']) else None)
 if bone:
  inverse=(rig.pose.bones[bone].matrix@rig.data.bones[bone].matrix_local.inverted()).inverted()
  for v in o.data.vertices:
   x,y,z=v.co
   if bone.endswith('.l'):desired=Vector(((x-.80)*1.2+.53,y-.115,(z-.62)*1.12+.27))
   else:
    # Main blade and hilt run down and slightly outward in the right grip.
    dz=z-.91;desired=Vector((-.53+dz*.30,y-.16,.67+dz*.92))
   v.co=inverse@desired
# Explicit wardrobe assignment by T-pose anatomy rather than atlas brightness.
for o in scene.objects:
 if o.type!='MESH':continue
 if 'Arm' in o.name:
  for p in o.data.polygons:
   x=sum(abs(o.data.vertices[i].co.x) for i in p.vertices)/len(p.vertices)
   p.material_index=0 if x>.72 else (2 if .38<x<.53 else 1)
 if 'Leg' in o.name:
  for p in o.data.polygons:
   z=sum(o.data.vertices[i].co.z for i in p.vertices)/len(p.vertices);p.material_index=0 if z<.29 else (1 if z<.39 else 0)
# Reduce shiny toy impression: retain metal response only on armor and blade.
for n in ['Soft brushed steel','Steel dark rim']:
 s=bpy.data.materials[n].node_tree.nodes.get('Principled BSDF');s.inputs['Roughness'].default_value=.48
scene.cycles.samples=32;scene.render.resolution_x=800;scene.render.resolution_y=1000;scene.camera.data.ortho_scale=2.45
parts=[o for o in scene.objects if o.type=='MESH'];bpy.ops.wm.save_as_mainfile(filepath=str(out/'warrior.blend'))
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=rig
usd=out/'warrior-rig.usda';bpy.ops.wm.usd_export(filepath=str(usd),selected_objects_only=True,export_animation=True,export_armatures=True,only_deform_bones=True,export_shapekeys=False,export_lights=False,export_cameras=False,export_normals=True,export_uvmaps=True,export_textures_mode='NEW',export_subdivision='IGNORE',generate_preview_surface=True,convert_orientation=True,export_global_up_selection='Y',root_prim_path='/WarriorIdentity',convert_world_material=False)
for frame,label in [(1,'rest'),(26,'idle-mid')]:
 scene.frame_set(frame)
 for side,loc in [('front',(0,-6,2.1)),('three-quarter',(3.1,-6.4,2.5)),('back',(3.1,6.4,2.5))]:
  cam=scene.camera;cam.location=loc;cam.rotation_euler=(Vector((0,0,1.0))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(label+'-'+side+'.png'));bpy.ops.render.render(write_still=True)
report={'materialSlotRepairs':materialRepairs,'removedSourceFaceVertices':len(remove),'headProportionObjects':headObjects,'meshObjects':len(parts),'sourceBlendSHA256':hashlib.sha256((out/'warrior.blend').read_bytes()).hexdigest(),'usdSHA256':hashlib.sha256(usd.read_bytes()).hexdigest(),'notClaimed':['original illustration exact likeness','Owner quality acceptance','production art','native performance']};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('WARRIOR_LIKENESS_STUDY_COMPLETE',report)
