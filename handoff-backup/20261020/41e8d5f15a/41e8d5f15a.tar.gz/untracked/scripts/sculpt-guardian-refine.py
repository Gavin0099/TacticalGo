"""Blender-only original form study after Owner rejected the procedural miniature style.

Uses a controlled quad-loft/subdivision base and voxel fusion for coherent skin
and glove masses. This is a form-study master, not claimed manual retopology.
Keeps the existing eleven-joint bind transforms and tested actions for comparison.
"""
import bpy,bmesh,json,math,sys,hashlib
from pathlib import Path
from mathutils import Matrix,Vector
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
import importlib.util
spec=importlib.util.spec_from_file_location('projects',root/'scripts/build-model-projects.py');projects=importlib.util.module_from_spec(spec);spec.loader.exec_module(projects)
output=root/'assets/candidates/ios-sculpt-v10/guardian-refined';output.mkdir(parents=True,exist_ok=True)
source=root/'assets/candidates/ios-3d-v09/resources/final/blender/warrior.blend'
bpy.ops.wm.open_mainfile(filepath=str(source));scene=bpy.context.scene;scene.frame_set(0)
rig=bpy.data.objects['Warrior_Rig'];skin=bpy.data.objects['Warrior_Skin']
parts=json.loads(skin['editable_part_map']);original_joints={b.name:[list(row) for row in b.matrix_local] for b in rig.data.bones}
# Restore authored colors before rebaking. Existing atlas is not painted onto new forms.
for mat in skin.data.materials:
 shader=mat.node_tree.nodes.get('Principled BSDF')
 for link in list(mat.node_tree.links):
  if link.to_socket==shader.inputs['Base Color']:mat.node_tree.links.remove(link)
 c=mat.diffuse_color
 shader.inputs['Base Color'].default_value=tuple(projects.usd.linear(v) for v in c[:3])+(1,)
 if abs(c[0]-.57)<.01:
  shader.inputs['Metallic'].default_value=.5;shader.inputs['Roughness'].default_value=.57
# Remove rejected head, spherical pauldrons, inflated bare fists and curved cuirass.
remove=set();removed=[]
for part in parts:
 indices=range(part['offset'],part['offset']+part['vertices'])
 drop=part['bone']=='head' or part['name']=='fitted-cuirass'
 if part['bone'] in ['left_arm','right_arm']:
  verts=set(indices);pol=next((p for p in skin.data.polygons if p.vertices[0] in verts),None)
  if pol:
   color=skin.data.materials[pol.material_index].diffuse_color
   drop=drop or abs(color[0]-.96)<.01 or (part['name']=='sphere-440-triangles' and abs(color[0]-.57)<.01)
 if drop:remove.update(indices);removed.append(part)
bm=bmesh.new();bm.from_mesh(skin.data);bm.verts.ensure_lookup_table();bmesh.ops.delete(bm,geom=[v for v in bm.verts if v.index in remove],context='VERTS');bm.to_mesh(skin.data);bm.free();skin.data.update()
created=[];records=[]
conv=projects.CONVERSION

def mat(name,color,metal=0,rough=.6):
 m=bpy.data.materials.new(name);m.use_nodes=True;m.diffuse_color=(*color,1)
 sh=m.node_tree.nodes.get('Principled BSDF');sh.inputs['Base Color'].default_value=tuple(projects.usd.linear(v) for v in color)+(1,);sh.inputs['Metallic'].default_value=metal;sh.inputs['Roughness'].default_value=rough
 return m
flesh=mat('Guardian warm skin',(.88,.62,.43),0,.72)
steel=mat('Guardian satin steel',(.59,.70,.77),.15,.49)
darksteel=mat('Guardian blue helmet',(.36,.48,.57),.18,.48)
leather=mat('Guardian glove leather',(.20,.10,.055),0,.76)
ivory=mat('Guardian ivory sclera',(.84,.81,.70),0,.5)
iris=mat('Guardian hazel iris',(.21,.15,.085),0,.57)
pupil=mat('Guardian pupil',(.032,.036,.04),0,.52)
lip=mat('Guardian mouth recess',(.23,.105,.065),0,.77)
hair=mat('Guardian eyebrow',(.18,.09,.055),0,.85)

def select(o):
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o

def mesh(name,points,faces,material,bone='body',subdiv=0):
 m=bpy.data.meshes.new(name);m.from_pydata([(conv@Vector((*p,1))).xyz for p in points],[],faces);m.update()
 o=bpy.data.objects.new(name,m);scene.collection.objects.link(o);o.data.materials.append(material)
 if subdiv:
  select(o);mod=o.modifiers.new('Controlled quad surface','SUBSURF');mod.levels=subdiv;mod.render_levels=subdiv;bpy.ops.object.modifier_apply(modifier=mod.name)
 for p in o.data.polygons:p.use_smooth=True
 o.vertex_groups.new(name=bone).add(list(range(len(o.data.vertices))),1,'REPLACE')
 created.append(o);records.append(dict(name=name,bone=bone,vertices=len(o.data.vertices),faces=len(o.data.polygons)))
 return o

def loft(name,sections,material,bone='body',sides=32,exp=.8,subdiv=1):
 # Sections are y/radius-x/radius-z/center-z. Shared quad rings allow controlled planes.
 points=[];faces=[]
 for y,rx,rz,cz in sections:
  for j in range(sides):
   a=2*math.pi*j/sides;c,s=math.cos(a),math.sin(a)
   x=math.copysign(abs(c)**exp,c)*rx;z=math.copysign(abs(s)**exp,s)*rz+cz
   if name=='Guardian facial mass' and s>0:
    # Shallow orbital planes rather than separate large eyeballs on a sphere.
    dent=sum(.016*math.exp(-((x-eye)/.041)**2-((y-.963)/.041)**2) for eye in [-.083,.083])
    z-=dent*(s**3)
   points.append((x,y,z))
 for i in range(len(sections)-1):
  for j in range(sides):
   a=i*sides+j;b=i*sides+(j+1)%sides;c=a+sides;d=b+sides
   faces.append((a,c,d,b))
 faces.append(tuple(reversed(range(sides))));faces.append(tuple((len(sections)-1)*sides+j for j in range(sides)))
 return mesh(name,points,faces,material,bone,subdiv)

def volume(name,center,scale,material,bone='head',exp=.8):
 sections=[]
 for i in range(13):
  a=math.pi*i/12;y=center[1]+math.cos(a)*scale[1];r=math.sin(a)
  sections.append((y,scale[0]*max(.015,r),scale[2]*max(.015,r),center[2]))
 # Loft expects upward profiles, not descending rings.
 o=loft(name,list(reversed(sections)),material,bone,24,exp,1)
 for v in o.data.vertices:v.co.x+=center[0]
 return o

def tube(name,centers,radius,material,bone='head',sides=10):
 points=[];faces=[]
 for i,p in enumerate(centers):
  tangent=Vector(centers[min(i+1,len(centers)-1)])-Vector(centers[max(0,i-1)])
  tangent.normalize();up=Vector((0,0,1));u=tangent.cross(up)
  if u.length<.01:u=tangent.cross(Vector((0,1,0)))
  u.normalize();v=tangent.cross(u).normalized()
  for j in range(sides):
   q=Vector(p)+radius*(u*math.cos(j*2*math.pi/sides)+v*math.sin(j*2*math.pi/sides));points.append(q)
 for i in range(len(centers)-1):
  for j in range(sides):
   a=i*sides+j;b=i*sides+(j+1)%sides;faces.append((a,b,b+sides,a+sides))
 faces.extend([tuple(reversed(range(sides))),tuple((len(centers)-1)*sides+j for j in range(sides))])
 return mesh(name,points,faces,material,bone,1)

def fuse(objects,name,material,bone,voxel=.007):
 bpy.ops.object.select_all(action='DESELECT')
 for o in objects:o.select_set(True)
 bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.join();o=bpy.context.object;o.name=name
 select(o);rem=o.modifiers.new('Sculpt mass fusion','REMESH');rem.mode='VOXEL';rem.voxel_size=voxel;rem.use_smooth_shade=True;bpy.ops.object.modifier_apply(modifier=rem.name)
 smooth=o.modifiers.new('Broad form polish','SMOOTH');smooth.factor=.3;smooth.iterations=3;bpy.ops.object.modifier_apply(modifier=smooth.name)
 dec=o.modifiers.new('Study surface reduction','DECIMATE');dec.ratio=.62;bpy.ops.object.modifier_apply(modifier=dec.name)
 o.data.materials.clear();o.data.materials.append(material)
 for p in o.data.polygons:p.material_index=0;p.use_smooth=True
 o.vertex_groups.clear();o.vertex_groups.new(name=bone).add(list(range(len(o.data.vertices))),1,'REPLACE')
 return o

head=loft('Guardian facial mass',[(.735,.11,.11,.045),(.755,.15,.14,.05),(.795,.205,.185,.05),(.86,.220,.190,.048),(.935,.211,.195,.047),(.995,.203,.188,.045),(1.07,.18,.165,.036),(1.125,.12,.105,.03),(1.15,.02,.02,.03)],flesh,'head',40,.43,2)
nose=loft('Guardian bridge and nose',[(.862,.03,.025,.245),(.880,.055,.047,.267),(.909,.047,.054,.266),(.952,.025,.025,.248),(.995,.012,.018,.221)],flesh,'head',24,.68,2)
ears=[volume('Guardian ear '+str(side),(side*.219,.919,.025),(.037,.061,.037),flesh,exp=.75) for side in [-1,1]]
head=fuse([head,nose,*ears],'Guardian fused head',flesh,'head',.006)
for side in [-1,1]:
 x=side*.083
 volume('Guardian recessed sclera '+str(side),(x,.963,.237),(.041,.023,.010),ivory,exp=.72)
 volume('Guardian hazel iris '+str(side),(x+side*.002,.962,.247),(.014,.017,.0025),iris,exp=1)
 volume('Guardian pupil '+str(side),(x+side*.002,.962,.250),(.008,.013,.0015),pupil,exp=1)
 upper=[];lower=[];brow=[]
 for i in range(13):
  u=-1+2*i/12
  upper.append((x+u*.041,.969+.021*math.sqrt(max(0,1-u*u)) - side*u*.008,.247-.012*abs(u)))
  lower.append((x+u*.039,.956-.019*math.sqrt(max(0,1-u*u)),.242-.010*abs(u)))
  brow.append((x+u*.045,.995+side*u*.015,.239-.016*abs(u)))
 tube('Guardian upper eyelid '+str(side),upper,.0062,flesh)
 tube('Guardian lower eyelid '+str(side),lower,.0040,flesh)
 tube('Guardian shaped brow '+str(side),brow,.012,hair)
# Thin neutral asymmetrical mouth replaces the cartoon black oval.
mouth=[(-.047+i*.094/12,.817+.012*(i/12-.5)+.003*math.sin(math.pi*i/12),.246-.008*abs(-1+2*i/12)) for i in range(13)]
tube('Guardian mouth line',mouth,.0035,lip)
tube('Guardian lower lip',[(x,y-.010,z-.004) for x,y,z in mouth],.0045,flesh)
# Open helmet shell: low back, cheek-side coverage, high face opening.
points=[];faces=[];sides=48;rings=12
for i in range(rings+1):
 theta=i/rings*math.pi/2
 for j in range(sides):
  phi=j*2*math.pi/sides;front=max(0,math.sin(phi))
  base=.925+.140*(front**2)
  points.append((.23*math.cos(phi)*math.sin(theta),1.205*math.cos(theta)+base*(1-math.cos(theta)),.032+.217*math.sin(phi)*math.sin(theta)))
for i in range(rings):
 for j in range(sides):
  a=i*sides+j;b=i*sides+(j+1)%sides;faces.append((a,b,b+sides,a+sides))
helmet=mesh('Guardian designed helmet shell',points,faces,darksteel,'head',1)
select(helmet);solid=helmet.modifiers.new('Helmet shell thickness','SOLIDIFY');solid.thickness=.017;solid.offset=-1;bpy.ops.object.modifier_apply(modifier=solid.name)
# Brim follows the shaped opening; no copied crown or game insignia.
rim=[]
for j in range(sides+1):
 phi=j*2*math.pi/sides;front=max(0,math.sin(phi));rim.append((.231*math.cos(phi),.925+.140*front**2,.032+.218*math.sin(phi)))
tube('Guardian helmet rim',rim,.0085,steel)
# Controlled chest planes and shoulder shells, keeping original bind positions.
loft('Guardian planar cuirass',[(.441,.190,.15,.028),(.452,.210,.16,.026),(.475,.233,.17,.022),(.550,.248,.181,.018),(.680,.246,.180,.012),(.726,.230,.156,.008),(.736,.216,.143,.008)],steel,'body',32,.25,2)
for side in [-1,1]:
 bone='left_arm' if side<0 else 'right_arm'
 shoulder=loft('Guardian layered pauldron '+str(side),[(.545,.119,.128,.012),(.553,.140,.145,.007),(.580,.153,.151,.003),(.679,.156,.150,-.005),(.704,.146,.145,-.005),(.715,.130,.128,-.005)],steel,bone,32,.24,1)
 for v in shoulder.data.vertices:v.co.x+=side*.277
 # Palm and four curved finger volumes fuse into one glove with a coherent grip.
 palm=volume('Guardian glove palm '+str(side),(side*.320,.365,.132),(.076,.085,.078),leather,bone,exp=.65)
 finger_objects=[]
 for i in range(4):
  y=.316+i*.032
  path=[(side*.286,y,.185),(side*.322,y-.002,.214),(side*.358,y-.001,.214),(side*.380,y+.002,.190),(side*.370,y+.003,.169)]
  finger_objects.append(tube('Guardian curled glove digit '+str(side)+'-'+str(i),path,.011,leather,bone))
 thumb=tube('Guardian opposed glove thumb '+str(side),[(side*.282,.407,.139),(side*.278,.414,.181),(side*.300,.395,.203)],.026,leather,bone)
 glove=fuse([palm,*finger_objects,thumb],'Guardian coherent gripped glove '+str(side),leather,bone,.0045)
# Join with original rigged legs/clothing/shield/sword; keep all joint bind transforms.
new_objects=[o for o in scene.objects if o.type=='MESH' and o!=skin and o.name.startswith('Guardian')]
bpy.ops.object.select_all(action='DESELECT');skin.select_set(True)
for o in new_objects:o.select_set(True)
bpy.context.view_layer.objects.active=skin;bpy.ops.object.join();skin=bpy.context.object
skin['candidate_status']='Owner rejected prior style; original sculpt form study. Voxel fusion and reduced topology, not manual production retopo.'
skin['style_sources']='Supercell author Royal Ghost proportions/material separation; Blender Studio planar body and sculpt workflow. No copied source mesh.'
skin['editable_part_map']=json.dumps([]) # prior offsets invalid after true geometry replacement
# Clean node atlas and rebake actual changed mesh.
bpy.ops.wm.save_as_mainfile(filepath=str(output/'guardian-sculpt-master.blend'))
select(skin);tri=skin.modifiers.new('Mobile triangles','TRIANGULATE');bpy.ops.object.modifier_apply(modifier=tri.name)
materials={m.name:m for m in skin.data.materials};surface=projects.bake_surfaces(skin,materials,'Warrior',output,pad_atlas=True)
scene.frame_set(0);bpy.context.view_layer.update()
assert original_joints=={b.name:[list(row) for row in b.matrix_local] for b in rig.data.bones}
blend=output/'warrior.blend';bpy.ops.wm.save_as_mainfile(filepath=str(blend))
for o in scene.objects:o.select_set(False)
skin.select_set(True);rig.select_set(True);bpy.context.view_layer.objects.active=rig
usd=output/'warrior-rig.usda'
bpy.ops.wm.usd_export(filepath=str(usd),selected_objects_only=True,export_animation=True,export_armatures=True,only_deform_bones=True,export_shapekeys=False,export_lights=False, export_cameras=False, export_normals=True, export_uvmaps=True, export_textures_mode='NEW', export_subdivision='IGNORE', generate_preview_surface=True, convert_orientation=True, export_global_up_selection='Y', root_prim_path='/Warrior', export_custom_properties=True, convert_world_material=False)
images=[]
for frame,label in [(0,'rest'),(35,'gesture')]:
 scene.frame_set(frame)
 for side,location in [('front',(0,-4.5,2.0)),('three-quarter',(2.3,-4.5,2.7)),('profile',(4.5,0,2.0)),('back',(2.3,4.5,2.5))]:
  scene.camera.location=location;scene.camera.rotation_euler=(Vector((0,0,.72))-scene.camera.location).to_track_quat('-Z','Y').to_euler();scene.camera.data.ortho_scale=1.72
  p=output/(label+'-'+side+'.png');scene.render.filepath=str(p);bpy.ops.render.render(write_still=True);images.append(p.name)
report=dict(sourceBlendSHA256=hashlib.sha256(source.read_bytes()).hexdigest(),blendSHA256=hashlib.sha256(blend.read_bytes()).hexdigest(),vertices=len(skin.data.vertices),triangles=len(skin.data.polygons),joints=list(original_joints),bindTransformsUnchanged=True,removedParts=removed,newFormParts=records,surfaceAtlas=surface,renders=images,
 claim='Actual editable original sculpt-form and imported-action study; voxel fusion/decimation is not manual topology, complete organic skin, approved art or physical-device evidence.')
(output/'sculpt-report.json').write_text(json.dumps(report,indent=2)+'\n');print('SCULPT_STUDY',report['vertices'],report['triangles'])
