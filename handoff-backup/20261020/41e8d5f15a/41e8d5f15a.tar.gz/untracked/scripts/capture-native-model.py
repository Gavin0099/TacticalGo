#!/usr/bin/env python3
"""Capture a mounted native model; retain failed launches instead of counting home-screen pixels."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time
import uuid

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--device', required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--hero', choices=['Warrior', 'Mage', 'Rogue'], default='Warrior')
parser.add_argument('--shadow-bias', type=float, default=1)
parser.add_argument('--shadow-disabled', action='store_true', help='DEBUG key-light shadow isolation; leaves models/materials/intensity unchanged')
parser.add_argument('--shadow-cull', choices=['front', 'back', 'none'], help='DEBUG shadow-map face-culling comparison; omit for existing default')
parser.add_argument('--resource-kind', choices=['bundled', 'rig', 'source', 'identity'], default='bundled')
parser.add_argument('--back', action='store_true', help='DEBUG same camera yaw plus pi for actual rear review')
parser.add_argument('--app', type=Path, default=Path('ios/Build/Products/Debug-iphonesimulator/TacticalGo.app'))
args = parser.parse_args()
if not .5 <= args.shadow_bias <= 4: parser.error('Shadow bias must be finite and within .5...4')
args.output.mkdir(parents=True, exist_ok=True)
if any(args.output.iterdir()): raise SystemExit('Use a new evidence directory; existing attempts are preserved')

def run(*parts):
    return subprocess.check_output(['xcrun', 'simctl', *parts], text=True).strip()

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def inputs(app):
    return {'debugLibrarySHA256': sha(app / 'TacticalGo.debug.dylib'),
            'models': {p.name: sha(p) for p in (app / 'Models').glob('*.usdz')}}

original = inputs(args.app)
run('install', args.device, str(args.app))
installed = Path(run('get_app_container', args.device, 'com.tacticalgo.prototype', 'app'))
documents = Path(run('get_app_container', args.device, 'com.tacticalgo.prototype', 'data')) / 'Documents'
if inputs(installed) != original or inputs(args.app) != original: raise SystemExit('Build changed during install')
resource = documents / (args.hero.lower() + '-rig.usdz')
rig_sha = sha(resource) if args.resource_kind == 'rig' else None
subprocess.run(['xcrun', 'simctl', 'terminate', args.device, 'com.tacticalgo.prototype'], capture_output=True)
token = str(uuid.uuid4())
flags = ['--identity-models' if args.resource_kind == 'identity' else ('--rig-models' if rig_sha else '--models'), '--model-class', args.hero,
         '--capture-model', '--capture-ready-token', token, '--shadow-bias', str(args.shadow_bias)]
if args.resource_kind == 'source': flags += ['--source-models']
if args.shadow_disabled: flags += ['--shadow-disabled']
if args.shadow_cull: flags += ['--shadow-cull', args.shadow_cull]
if args.back: flags += ['--model-back']
launch = run('launch', args.device, 'com.tacticalgo.prototype', *flags)
pid = int(launch.rsplit(':', 1)[1])
attempt = {'device': args.device, 'pid': pid, 'launchArguments': flags, 'installedInputs': original,
           'documentsResourceSHA256': rig_sha, 'launchedAtUnix': time.time()}
(args.output / 'launch-inputs.json').write_text(json.dumps(attempt, indent=2) + '\n')

def alive():
    return any(line.split() and line.split()[0] == str(pid)
               for line in run('spawn', args.device, 'launchctl', 'list').splitlines())

ready = documents / ('capture-ready-' + token + '.json')
for i in range(100):
    if ready.exists(): break
    if i % 10 == 0 and not alive(): raise SystemExit('Native app exited before model became mounted; launch attempt preserved')
    time.sleep(.2)
else: raise SystemExit('Native model did not become mounted/foreground; launch attempt preserved')
receipt = json.loads(ready.read_text())
(args.output / 'readiness-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
if receipt.get('keyShadowEnabled') != (not args.shadow_disabled): raise SystemExit('Wrong key shadow state')
if receipt.get('modelHero') != args.hero or not receipt.get('foreground'): raise SystemExit('Wrong native readiness receipt')
(args.output / 'readiness-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
time.sleep(2)
if not alive(): raise SystemExit('Native app exited after readiness; no successful screenshot manifest')
image_path = args.output / (args.hero.lower() + '.png')
run('io', args.device, 'screenshot', str(image_path))
if inputs(installed) != original or inputs(args.app) != original or (rig_sha and sha(resource) != rig_sha):
    raise SystemExit('Inputs changed during capture; pixels retained, no successful manifest')
attempt.update({'nativeReady': receipt, 'screenshot': image_path.name, 'screenshotSHA256': sha(image_path),
                'claim': 'native model screenshot and mounted-state receipt; visual review still required'})
(args.output / 'capture-manifest.json').write_text(json.dumps(attempt, indent=2) + '\n')
print(image_path)
