#!/usr/bin/env python3
"""Blender-only shoulder stress review, explicitly separate from gameplay clips."""
import argparse
from pathlib import Path
import sys
import json
import bpy
from mathutils import Quaternion

parser=argparse.ArgumentParser()
parser.add_argument("source",type=Path)
parser.add_argument("--output",type=Path,required=True)
args=parser.parse_args(sys.argv[sys.argv.index("--")+1:])
args.output.mkdir(parents=True,exist_ok=True)
results=[]
for hero in ["mage","rogue"]:
    bpy.ops.wm.open_mainfile(filepath=str((args.source/(hero+".blend")).resolve()))
    rig=bpy.data.objects[hero.title()+"_Rig"]
    bpy.context.scene.frame_set(0)
    # Render reevaluates animation channels at the scene frame. Clear them only
    # in this transient review session so the requested stress pose is retained.
    rig.animation_data_clear()
    rig.pose.bones["right_arm"].rotation_quaternion=Quaternion((1,0,0),-.65)
    rig.pose.bones["left_arm"].rotation_quaternion=Quaternion((1,0,0),.25)
    rig.pose.bones["head"].rotation_quaternion=Quaternion((1,0,0),-.12)
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath=str((args.output/(hero+"-shoulder-stress.png")).resolve())
    bpy.ops.render.render(write_still=True)
    angle=rig.pose.bones["right_arm"].rotation_quaternion.angle
    if abs(angle-.65)>.00001:raise RuntimeError("Render overwrote the requested stress angle")
    results.append({"hero":hero,"rightArmRadians":angle,"passed":True,"blendFileModified":False})
(args.output/"stress-pose-verification.json").write_text(json.dumps(results,indent=2)+"\n")
