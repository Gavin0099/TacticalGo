"""Candidate adaptation of a CC0 skinned construction base to fixed TacticalGo warrior art.
Not a stock replacement or production-quality/Owner-accepted asset. Genuine editable meshes.
"""
import bpy,bmesh,json,math,hashlib
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];out=root/'assets/candidates/ios-identity-v01/warrior';out.mkdir(parents=True,exist_ok=True)
base=root/'assets/third-party/kaykit-adventurers-2/source/KayKit_Adventurers_2.0_FREE'
bpy.ops.wm.open_mainfile(filepath=str(root/'artifacts/ios/identity-model-v01/knight-import-inspection.blend'))
scene=bpy.context.scene;rig=next(o for o in scene.objects if o.type=='ARMATURE');rig.name='Warrior_Identity_Rig'
for o in list(scene.objects):
 if o.name in ['Icosphere','Knight_Helmet','Knight_Visor']:bpy.data.objects.remove(o,do_unlink=True)
# Check imported names explicitly instead of silently leaving the rejected helmet.
for o in list(scene.objects):
 if 'Helmet' in o.name or 'Visor' in o.name:bpy.data.objects.remove(o,do_unlink=True)
parts=[o for o in scene.objects if o.type=='MESH'];mats={}
def mat(name,c,metal=0,rough=.6):
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True;s=m.node_tree.nodes.get('Principled BSDF');s.inputs['Base Color'].default_value=(*c,1);s.inputs['Metallic'].default_value=metal;s.inputs['Roughness'].default_value=rough;mats[name]=m;return m
skin=mat('Warm youthful complexion',(.64,.32,.16));cream=mat('Cream woven tunic',(.78,.66,.43));teal=mat('Deep teal cape',(.025,.20,.22));tealHi=mat('Teal fold light',(.055,.30,.31));steel=mat('Soft brushed steel',(.39,.45,.48),.68,.34);edge=mat('Steel dark rim',(.15,.19,.21),.55,.42);leather=mat('Chestnut leather',(.13,.054,.023));gold=mat('Aged warm gold',(.64,.34,.068),.6,.32);hair=mat('Chestnut hair',(.115,.039,.013));hairLight=mat('Chestnut swept locks',(.19,.066,.022));white=mat('Warm eye whites',(.90,.87,.71),0,.34);iris=mat('Warm brown irises',(.17,.064,.015),0,.27);pupil=mat('Dark pupils',(.016,.007,.004),0,.25);smile=mat('Smile and brows',(.066,.016,.006));cheek=mat('Soft freckles',(.27,.085,.032))
def assign(o,m):o.data.materials.clear();o.data.materials.append(m)
def bind(o,bone):
 o.parent=rig;g=o.vertex_groups.new(name=bone);g.add(list(range(len(o.data.vertices))),1,'REPLACE');mod=o.modifiers.new('Identity skin binding','ARMATURE');mod.object=rig;parts.append(o);return o
def sphere(name,p,s,m,bone='head'):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=16,location=p);o=bpy.context.object;o.name=name;o.scale=s;bpy.ops.object.transform_apply(location=True,rotation=True,scale=True);assign(o,m)
 for f in o.data.polygons:f.use_smooth=True
 return bind(o,bone)
def curve(name,points,radius,m,bone='head'):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=12;c.bevel_depth=radius;c.bevel_resolution=3;s=c.splines.new('BEZIER');s.bezier_points.add(len(points)-1)
 for b,p in zip(s.bezier_points,points):b.co=p;b.handle_left_type='AUTO';b.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,c);scene.collection.objects.link(o);bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o=bpy.context.object;assign(o,m);o.select_set(False);return bind(o,bone)
def loft(name,rows,m,bone='chest',n=32):
 verts=[];faces=[]
 for z,rx,ry,cy in rows:
  for i in range(n):a=2*math.pi*i/n;verts.append((math.cos(a)*rx,math.sin(a)*ry+cy,z))
 for k in range(len(rows)-1):
  for i in range(n):j=(i+1)%n;faces.append((k*n+i,k*n+j,(k+1)*n+j,(k+1)*n+i))
 faces.append(tuple(reversed(range(n))));faces.append(tuple((len(rows)-1)*n+i for i in range(n)))
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new(name,mesh);scene.collection.objects.link(o);assign(o,m)
 bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free()
 for f in mesh.polygons:f.use_smooth=True
 return bind(o,bone)
def slab(name,coords,depth,m,bone):
 # Designed extruded silhouette; front is negative Y.
 verts=[(x,y,z) for x,y,z in coords]+[(x,y+depth,z) for x,y,z in coords];n=len(coords);faces=[tuple(reversed(range(n))),tuple(n+i for i in range(n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new(name,mesh);scene.collection.objects.link(o);assign(o,m)
 bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free();bev=o.modifiers.new('Silhouette edge softness','BEVEL');bev.width=.017;bev.segments=3;bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.modifier_apply(modifier=bev.name);o.select_set(False)
 for f in mesh.polygons:f.use_smooth=True
 o.modifiers.new('Weighted edge normals','WEIGHTED_NORMAL');return bind(o,bone)
# Head skin and ears come from the reusable CC0 low-poly base. Remove stock hair/brows/black button eyes.
head=bpy.data.objects['Knight_Head'];partsinfo=json.loads((root/'artifacts/ios/identity-model-v01/face-loose-parts.json').read_text());remove=set(i for p in partsinfo[11:] for i in p['ids'])
bm=bmesh.new();bm.from_mesh(head.data);bm.verts.ensure_lookup_table();bmesh.ops.delete(bm,geom=[bm.verts[i] for i in sorted(remove)],context='VERTS');bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(head.data);bm.free()
for v in head.data.vertices:v.co.x*=.90;v.co.y*=.90;v.co.z=1.241+(v.co.z-1.241)*.90+.06
assign(head,skin)
for p in head.data.polygons:p.use_smooth=True
# All other original meshes recolored by independently inspected gradient UV classes.
for o in list(parts):
 if o==head:continue
 if 'Cape' in o.name:assign(o,teal);continue
 if 'Body' in o.name:bpy.data.objects.remove(o,do_unlink=True);parts.remove(o);continue
 old=o.data.materials[0];img=next(n.image for n in old.node_tree.nodes if n.type=='TEX_IMAGE');pixels=list(img.pixels);w,h=img.size;colors=[]
 for p in o.data.polygons:
  uv=o.data.uv_layers.active.data[p.loop_start].uv;x=max(0,min(w-1,int(uv.x*w)));y=max(0,min(h-1,int(uv.y*h)));c=pixels[(y*w+x)*4:(y*w+x)*4+3];colors.append(c)
 o.data.materials.clear()
 for m in [leather,steel,cream,edge]:o.data.materials.append(m)
 for p,c in zip(o.data.polygons,colors):
  p.material_index=0 if max(c)-min(c)>.10 else (1 if max(c)>.33 else 3);p.use_smooth=True
# New cream torso and hanging split tunic, designed to match v01 outfit.
loft('Cream tunic torso',[(.40,.245,.19,0),(.55,.28,.21,0),(.78,.29,.21,0),(.98,.33,.21,0),(1.13,.31,.18,0),(1.21,.16,.13,0)],cream)
loft('Cream tunic skirt',[(.28,.36,.225,0),(.38,.34,.22,0),(.53,.285,.21,0)],cream,'hips')
loft('Leather waist belt',[(.49,.296,.225,-.003),(.56,.297,.224,-.003)],leather,'hips')
curve('Diagonal chest leather strap',[(.22,-.169,1.20),(.14,-.211,1.06),(-.05,-.230,.88),(-.25,-.172,.60)],.045,leather,'chest')
slab('Gold belt buckle',[(-.11,-.239,.56),(.07,-.239,.56),(.07,-.239,.47),(-.11,-.239,.47)],.025,gold,'hips')
# Folded teal collar (not a thick toy ring).
loft('Teal folded scarf',[(1.11,.25,.19,-.015),(1.18,.29,.20,-.012),(1.27,.19,.14,0)],tealHi)
sphere('Cape clasp',(.18,-.197,1.18),(.048,.018,.048),gold,'chest')
# Expressive warm eyes seated close to the face, with real irises/upper lids/catchlights.
for s in [-1,1]:
 x=s*.166
 sphere('Almond eye white '+str(s),(x,-.386,1.633),(.099,.032,.109),white)
 sphere('Brown iris '+str(s),(x+s*.005,-.416,1.629),(.053,.015,.072),iris)
 sphere('Dark pupil '+str(s),(x+s*.003,-.430,1.631),(.029,.008,.051),pupil)
 sphere('Eye catchlight '+str(s),(x-.016,-.438,1.662),(.014,.005,.020),white)
 curve('Upper eyelid '+str(s),[(x-.094,-.374,1.645),(x-.051,-.414,1.716),(x+.035,-.414,1.726),(x+.092,-.375,1.67)],.010,smile)
 curve('Friendly brow '+str(s),[(x-.09,-.363,1.775),(x-.025,-.383,1.800),(x+.063,-.351,1.776)],.017,hair)
 for j in range(3):sphere('Freckle '+str(s)+'-'+str(j),(s*(.19+j*.036),-.365+j*.018,1.538+(j%2)*.019),(.006,.004,.005),cheek)
curve('Friendly curved smile',[(-.10,-.375,1.455),(-.04,-.409,1.438),(.04,-.409,1.447),(.105,-.377,1.48)],.008,smile)
# Chestnut swept hair: continuous tapered crescent locks rather than a pile of spheres.
sphere('Hair back crown',(0,.07,1.885),(.432,.367,.315),hair)
def lock(name,points,width,m):
 vs=[];fs=[];n=10
 for i,p in enumerate(points):
  p=Vector(p);t=Vector(points[min(i+1,len(points)-1)])-Vector(points[max(0,i-1)]);t.normalize();a=t.cross(Vector((0,-1,0))).normalized();b=t.cross(a).normalized();r=width*([.65,1,.87,.60,.18,.025][min(i,5)])
  for j in range(n):ang=2*math.pi*j/n;v=p+a*(math.cos(ang)*r)+b*(math.sin(ang)*r*.48);vs.append(tuple(v))
 for i in range(len(points)-1):
  for j in range(n):fs.append((i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j))
 fs.extend([tuple(reversed(range(n))),tuple((len(points)-1)*n+j for j in range(n))]);me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);assign(o,m);bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free()
 for p in me.polygons:p.use_smooth=True
 return bind(o,'head')
lock('Signature left sweeping fringe',[(.13,-.20,2.16),(.01,-.34,2.18),(-.16,-.41,2.12),(-.28,-.43,1.98),(-.33,-.42,1.83),(-.30,-.41,1.75)],.15,hairLight)
lock('Center chestnut wave',[(.29,-.17,2.12),(.24,-.29,2.15),(.12,-.40,2.07),(.065,-.44,1.97),(.02,-.43,1.85),(-.05,-.42,1.82)],.126,hair)
lock('Right temple wave',[(.30,-.11,2.10),(.38,-.24,2.04),(.43,-.27,1.94),(.38,-.25,1.82),(.34,-.21,1.74),(.33,-.19,1.71)],.125,hairLight)
lock('Crown curl',[(.05,.04,2.13),(-.08,-.08,2.22),(-.16,-.16,2.27),(-.24,-.18,2.23),(-.28,-.19,2.24),(-.29,-.19,2.29)],.083,hairLight)
for s in [-1,1]:
 lock('Temple curl '+str(s),[(s*.35,.02,1.99),(s*.43,-.06,1.93),(s*.44,-.11,1.82),(s*.39,-.12,1.73),(s*.39,-.12,1.68)],.11,hair)
 lock('Back nape curl '+str(s),[(s*.28,.31,1.92),(s*.38,.31,1.82),(s*.40,.26,1.68),(s*.36,.18,1.56),(s*.33,.14,1.54)],.11,hairLight)
# Equipment meshes are rigidly skinned to the original hand sockets, true anatomical sides.
# T-pose hands at +/- .88; local axes are baked into vertices, no bone-parent double transform.
shield=slab('Teal shield gold silhouette',[(.56,-.22,1.35),(1.02,-.22,1.35),(1.05,-.22,.93),(.80,-.22,.62),(.53,-.22,.93)],.11,gold,'handslot.l')
slab('Teal inset shield',[(.60,-.244,1.30),(.98,-.244,1.30),(1.00,-.244,.95),(.80,-.244,.68),(.58,-.244,.95)],.025,teal,'handslot.l')
# Latest B-v02 castle motif: battlement, never the superseded bow-tie diamond.
slab('Gold castle heraldry',[(.68,-.276,1.16),(.73,-.276,1.16),(.73,-.276,1.10),(.78,-.276,1.10),(.78,-.276,1.16),(.83,-.276,1.16),(.83,-.276,1.10),(.88,-.276,1.10),(.88,-.276,1.16),(.93,-.276,1.16),(.93,-.276,.96),(.68,-.276,.96)],.012,gold,'handslot.l')
curve('Right sword hilt',[(-.88,-.06,1.10),(-.88,-.06,.91)],.033,leather,'handslot.r')
slab('Sword guard',[(-1.00,-.09,.93),(-.76,-.09,.93),(-.76,-.09,.88),(-1.00,-.09,.88)],.055,gold,'handslot.r')
slab('Broad steel sword',[(-.93,-.06,.89),(-.83,-.06,.89),(-.83,-.06,.34),(-.88,-.06,.23),(-.93,-.06,.34)],.035,steel,'handslot.r')
# Import matching CC0 animation rig only to obtain professionally keyed bones. Assert bind identity.
original=set(scene.objects);bpy.ops.import_scene.gltf(filepath=str(base/'Animations/gltf/Rig_Medium/Rig_Medium_General.glb'));added=set(scene.objects)-original;motionRig=next(o for o in added if o.type=='ARMATURE')
assert set(rig.data.bones.keys())==set(motionRig.data.bones.keys()),'Rig joint identity mismatch'
maxerr=max(max(abs(rig.data.bones[n].matrix_local[i][j]-motionRig.data.bones[n].matrix_local[i][j]) for i in range(4) for j in range(4)) for n in rig.data.bones.keys());assert maxerr<1e-5,maxerr
action=next(a for a in bpy.data.actions if a.name.endswith('Idle_B') or a.name=='Idle_B');rig.animation_data_create();rig.animation_data.action=action
if action.slots:rig.animation_data.action_slot=action.slots[0]
for o in added:bpy.data.objects.remove(o,do_unlink=True)
scene.frame_start=int(action.frame_range[0]);scene.frame_end=int(action.frame_range[1]);scene.frame_set(scene.frame_start)
# Camera/studio are not exported. Blender master saves matching rig, materials and editable action.
scene.render.engine='CYCLES';scene.cycles.samples=32;scene.render.resolution_x=800;scene.render.resolution_y=1000;scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX'
world=bpy.data.worlds.new('Warm studio sky');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.32,.37,.42,1);world.node_tree.nodes['Background'].inputs[1].default_value=.45;scene.world=world
bpy.ops.object.camera_add(location=(3.1,-6.4,3.0));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=2.75;cam.rotation_euler=(Vector((0,0,1.10))-cam.location).to_track_quat('-Z','Y').to_euler();scene.camera=cam
for name,p,power,size,c in [('Warm soft key',(-3,-4,5),500,4,(1,.86,.71)),('Sky fill',(4,-2,3),220,4,(.64,.80,1)),('Cape rim',(1,3,4),450,3,(.62,.91,1))]:
 bpy.ops.object.light_add(type='AREA',location=p);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.size=size;o.data.color=c;o.rotation_euler=(Vector((0,0,1.1))-o.location).to_track_quat('-Z','Y').to_euler()
scene.render.film_transparent=True
bpy.ops.wm.save_as_mainfile(filepath=str(out/'warrior.blend'))
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=rig
usd=out/'warrior-rig.usda';bpy.ops.wm.usd_export(filepath=str(usd),selected_objects_only=True,export_animation=True,export_armatures=True,only_deform_bones=True,export_shapekeys=False,export_lights=False,export_cameras=False,export_normals=True,export_uvmaps=True,export_textures_mode='NEW',export_subdivision='IGNORE',generate_preview_surface=True,convert_orientation=True,export_global_up_selection='Y',root_prim_path='/WarriorIdentity',convert_world_material=False)
for frame,label in [(scene.frame_start,'rest'),(int((scene.frame_start+scene.frame_end)/2),'idle-mid')]:
 scene.frame_set(frame)
 for side,loc in [('front',(0,-6,2.4)),('three-quarter',(3.1,-6.4,3.0)),('back',(3.1,6.4,3.0))]:
  cam.location=loc;cam.rotation_euler=(Vector((0,0,1.10))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(label+'-'+side+'.png'));bpy.ops.render.render(write_still=True)
report={'source':'KayKit CC0 head/limbs/23-joint rig and Idle_B with new identity costume/hair/eyes/equipment','originalArt':'warrior-v01 and B-warrior-v02','animation':action.name,'frames':[scene.frame_start,scene.frame_end],'bindMaxError':maxerr,'joints':list(rig.data.bones.keys()),'meshObjects':len(parts),'vertices':sum(len(o.data.vertices) for o in parts),'blendSHA256':hashlib.sha256((out/'warrior.blend').read_bytes()).hexdigest(),'usdSHA256':hashlib.sha256(usd.read_bytes()).hexdigest(),'notClaimed':['Owner likeness acceptance','final art','23-joint gameplay adapter','physical device','performance budget']};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('IDENTITY_WARRIOR_COMPLETE',report)
