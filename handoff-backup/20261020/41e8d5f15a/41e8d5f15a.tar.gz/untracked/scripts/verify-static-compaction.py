#!/usr/bin/env python3
"""Blender independently imports original and baked static geometry for comparison."""
import argparse
import json
from pathlib import Path
import sys
import bpy
from mathutils.kdtree import KDTree


def geometry(path):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.wm.usd_import(filepath=str(path),import_cameras=False,import_lights=False)
    meshes=[o for o in bpy.context.scene.objects if o.type=='MESH']
    points=[o.matrix_world @ v.co for o in meshes for v in o.data.vertices]
    triangles=sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in meshes)
    return points,triangles,len(meshes)


def directed_error(source,target):
    tree=KDTree(len(target))
    for i,p in enumerate(target):tree.insert(p,i)
    tree.balance()
    return max(tree.find(p)[2] for p in source)


parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--original',required=True,type=Path);parser.add_argument('--compact',required=True,type=Path)
parser.add_argument('--evidence',required=True,type=Path)
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:]);rows=[]
for name in ['bluesoldier','bluecommander','redsoldier','redcommander']:
    original,ot,om=geometry(args.original/(name+'.usda'))
    baked,bt,bm=geometry(args.compact/(name+'.usda'))
    forward=directed_error(original,baked);reverse=directed_error(baked,original)
    passed=len(original)==len(baked) and ot==bt and bm<om and max(forward,reverse)<1e-6
    rows.append({'name':name,'sourceVertices':len(original),'bakedVertices':len(baked),'sourceTriangles':ot,'bakedTriangles':bt,
                 'sourceMeshObjects':om,'bakedMeshObjects':bm,'sourceToBakedMaxMeters':forward,'bakedToSourceMaxMeters':reverse,'passed':passed})
args.evidence.parent.mkdir(parents=True,exist_ok=True)
args.evidence.write_text(json.dumps({'kind':'independent actual Blender USD imports and both-direction nearest positions, unchanged vertex/triangle counts; not proof of pixel/material equivalence or all topology','results':rows},indent=2)+'\n')
if not all(r['passed'] for r in rows):raise RuntimeError('Independent geometry comparison failed')
