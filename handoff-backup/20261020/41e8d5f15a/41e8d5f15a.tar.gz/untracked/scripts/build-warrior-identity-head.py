"""B-v02 head identity experiment: reference-space control cage, real perspective depth.
No old model imported, no bitmap projected onto mesh, no gear/rig/export/animation.
Visible shape is manually registered to B-v02; hidden depth remains an assumption.
"""
import bpy,bmesh,math,json,hashlib,sys
from pathlib import Path
from mathutils import Vector
from mathutils.geometry import tessellate_polygon
from bpy_extras.object_utils import world_to_camera_view
ROOT=Path(__file__).resolve().parents[1]
REV=sys.argv[sys.argv.index('--')+1] if '--' in sys.argv else 'v01'
assert REV in ['v01','v02']
OUT=ROOT/('assets/candidates/warrior-identity-head-'+REV)
QA=ROOT/('artifacts/ios/warrior-identity-head-'+REV)
OUT.mkdir(parents=True,exist_ok=True);QA.mkdir(parents=True,exist_ok=True)
REF=ROOT/'assets/candidates/vis-feel-01/tokens/B-warrior-v02.png'
assert hashlib.sha256(REF.read_bytes()).hexdigest()=='50885855dc9faee8966558ea854f99d24bd0ffd0ed93c03bb6b87c8643d42298'
landmarks={'left_iris':[205,191],'right_iris':[268,169],'nose_tip':[232,202],'smile_left':[216,224],'smile_right':[270,205],'chin':[241,254],'hair_top':[235,42],'hair_left':[119,158],'hair_right':[370,160]}
manifest={'source':str(REF.relative_to(ROOT)),'source_sha256':hashlib.sha256(REF.read_bytes()).hexdigest(),'source_dimensions':[512,512],'source_role':'single perspective three-quarter illustrated identity, NOT orthographic','master_status':'1254 original absent; surviving 512 adequate for coarse shape test','scope':'head only independent editable study; no arms/gear/rig/animation/export','observed':['hair outer contour','visible ear silhouette','eye shapes and centers','brow angles','jaw silhouette','nose and smile locations'],'assumptions':['all concealed skull/back hair shape','nose protrusion','ear thickness','head depth','camera focal length: single illustration cannot uniquely solve camera'],'landmarks_px_manual_estimates':landmarks,'camera_method':'perspective inverse projection control cage in source pixel coordinates; stylized view-aligned fit, not recovered physical camera','validation':{'visible_head_silhouette_iou_target':.82,'landmark_drift_target_px':6,'identity_acceptance':'Owner only; metrics do not prove character identity'},'references':[{'url':'https://github.com/RobLe3/cc-blender-skill/blob/main/plugin/skills/reference-to-3d/SKILL.md','use':'source manifest and visible-contour-first reconstruction; not orthographic assumptions'},{'url':'https://github.com/RobLe3/cc-blender-skill/blob/main/plugin/skills/reference-analysis-validator/SKILL.md','use':'matching modality, overlay and silhouette diagnostics'},{'url':'https://studio.blender.org/training/stylized-character-workflow/','use':'public head-blockout/stylization workflow overview; paid lessons not accessed'},{'url':'https://github.com/ahujasid/mcp-for-blender','use':'documentation reviewed; not installed or executed'}]}
(QA/'reference_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
bpy.ops.wm.read_factory_settings(use_empty=True);S=bpy.context.scene
S.render.engine='CYCLES';S.cycles.samples=24;S.cycles.use_denoising=True
S.render.resolution_x=512;S.render.resolution_y=512;S.render.resolution_percentage=100;S.render.film_transparent=True
S.view_settings.view_transform='Standard';S.view_settings.look='None'
world=bpy.data.worlds.new('Locked neutral studio');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.7,.72,.75,1);world.node_tree.nodes['Background'].inputs[1].default_value=.5;S.world=world
bpy.ops.object.camera_add(location=(0,-8,0));CAM=bpy.context.object;CAM.name='B-v02 source-view perspective registration';CAM.rotation_euler=(math.pi/2,0,0);CAM.data.type='PERSP';CAM.data.lens=50;CAM.data.sensor_width=36;S.camera=CAM
# A world unit projects to 88.889px at y=0. Depth correction keeps each authored
# visible contour point on its measured source pixel, without changing focal length.
def xyz(u,v,y):
 q=(8+y)*36/(50*512)
 return ((u-256)*q,y,(256-v)*q)
def mat(name,c,rough=.7):
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=rough;p.inputs['Specular IOR Level'].default_value=.22
 return m
skin=mat('Warm peach planar sculpt',(.80,.47,.27));earshade=mat('Ear warm inner plane',(.48,.22,.115));hair=mat('Chestnut primary mass',(.19,.066,.025));hairlight=mat('Chestnut broad wave',(.27,.11,.047));hairdark=mat('Chestnut overlap shadow',(.115,.036,.016));ink=mat('Soft brown facial contour',(.055,.018,.009));white=mat('Warm eye white',(.95,.92,.82),.5);iris=mat('Amber brown iris',(.24,.087,.025),.5);black=mat('Warm pupil',(.015,.008,.005),.45);freckle=mat('Sparse warm freckles',(.40,.17,.08))
def mesh(name,V,F,M):
 me=bpy.data.meshes.new(name);me.from_pydata(V,[],F);me.update();o=bpy.data.objects.new(name,me);S.collection.objects.link(o);me.materials.append(M)
 bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free()
 for f in me.polygons:f.use_smooth=True
 return o
def spline(poly,steps=5):
 out=[];n=len(poly)
 for i in range(n):
  p0=Vector(poly[(i-1)%n]);p1=Vector(poly[i]);p2=Vector(poly[(i+1)%n]);p3=Vector(poly[(i+2)%n])
  for j in range(steps):
   t=j/steps;out.append(tuple(.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t)))
 return out
facepoly=[(186,137),(212,121),(248,113),(278,123),(295,148),(311,164),(311,195),(298,215),(279,233),(259,248),(241,254),(221,253),(200,241),(185,222),(177,198),(176,171)]
def face_y(u,v):
 # One continuous low-frequency sculpt field, includes bridge, nose, cheeks,
 # recessed eye planes and mouth pad. Nothing is a separate nose sphere.
 e=((u-246)/78)**2+((v-180)/92)**2
 y=-.09-.47*max(0,1-e)**.65
 def bump(cx,cy,sx,sy,k):return k*math.exp(-.5*(((u-cx)/sx)**2+((v-cy)/sy)**2))
 y-=bump(233,198,9,8,.15)+bump(240,182,6,17,.075)+bump(218,208,18,13,.045)+bump(279,194,18,17,.04)
 y+=bump(205,190,15,12,.08)+bump(266,169,19,15,.08)
 return y
def dome(name,poly,center,M,depth,base,back=.10,rings=22,facial=False):
 boundary=spline(poly);n=len(boundary);V=[];F=[]
 for k in range(rings+1):
  r=max(.0001,k/rings)
  for a,b in boundary:
   u=center[0]+(a-center[0])*r;v=center[1]+(b-center[1])*r
   y=face_y(u,v) if facial else base-depth*(1-r*r)**.7
   V.append(xyz(u,v,y))
 for k in range(rings):
  for i in range(n):F.append((k*n+i,k*n+(i+1)%n,(k+1)*n+(i+1)%n,(k+1)*n+i))
 F.append(tuple(reversed(range(n))))
 # Rounded back fills substantial skull volume, not a textured flat card.
 start=len(V)
 for k in range(rings+1):
  r=max(.0001,1-k/rings)
  for a,b in boundary:
   u=center[0]+(a-center[0])*r;v=center[1]+(b-center[1])*r
   y=(face_y(a,b) if facial else base)+back*(1-r*r)**.7
   V.append(xyz(u,v,y))
 for i in range(n):F.append((rings*n+i,rings*n+(i+1)%n,start+(i+1)%n,start+i))
 for k in range(rings):
  for i in range(n):F.append((start+k*n+i,start+k*n+(i+1)%n,start+(k+1)*n+(i+1)%n,start+(k+1)*n+i))
 F.append(tuple(start+rings*n+i for i in range(n)))
 return mesh(name,V,F,M)
face=dome('HEAD continuous face jaw cheeks nose sculpt field',facepoly,(244,181),skin,.48,-.09,back=(1.03 if REV=='v02' else .57),rings=42,facial=True)
face['method']='reference-space sculpt control cage, continuous nose volume, no stock head';face['hidden_depth']='unreviewed hypothesis'
dome('EAR visible right volume',[(311,158),(323,150),(334,155),(340,168),(336,181),(325,191),(309,195),(305,179)],(322,171),skin,.11,-.05,.09)
if REV=='v02':dome('EAR source visible inner bowl',[(316,164),(324,158),(332,162),(334,172),(328,183),(316,188),(321,177),(326,171),(322,167)],(325,171),earshade,.009,-.167,.012,rings=10)
dome('EAR visible left partially occluded',[(175,197),(182,203),(194,226),(186,232),(176,222),(169,208)],(181,215),skin,.06,-.08,.06)
def decal(name,poly,M,offset=-.012,bulge=.01):
 pts=spline(poly,5);cx=sum(p[0] for p in pts)/len(pts);cy=sum(p[1] for p in pts)/len(pts);V=[];F=[];n=len(pts);nr=10
 if REV=='v02' and name.startswith('SMILE'):
  # A narrow concave smile cannot use a central radial fan: its centroid is
  # outside the curved ribbon and those triangles fill the mouth interior.
  vv=[Vector((u,v,0)) for u,v in pts];tri=tessellate_polygon([vv])
  V=[xyz(u,v,face_y(u,v)+offset) for u,v in pts]
  F=[tuple(p if isinstance(p,int) else min(range(n),key=lambda i:(vv[i]-p).length_squared) for p in t) for t in tri]
  o=mesh(name,V,F,M);o['contour_method']='concave polygon tessellation; no centroid fan'
  mod=o.modifiers.new('Surface detail thickness','SOLIDIFY');mod.thickness=.005
  return o
 for k in range(nr+1):
  r=max(.0001,k/nr)
  for a,b in pts:
   u=cx+(a-cx)*r;v=cy+(b-cy)*r;y=face_y(u,v)+offset-bulge*(1-r*r);V.append(xyz(u,v,y))
 for k in range(nr):
  for i in range(n):F.append((k*n+i,k*n+(i+1)%n,(k+1)*n+(i+1)%n,(k+1)*n+i))
 F.append(tuple(reversed(range(n))))
 o=mesh(name,V,F,M);mod=o.modifiers.new('Surface detail thickness','SOLIDIFY');mod.thickness=.005;return o
def ellipse(cx,cy,rx,ry):return [(cx+rx*math.cos(i*math.tau/32),cy+ry*math.sin(i*math.tau/32)) for i in range(32)]
# Eye contours are source-specific asymmetric lids, hugging recessed face planes.
for label,poly,c,r in [('left',[(186,184),(192,178),(202,177),(212,182),(217,192),(213,202),(205,207),(195,204),(188,197)],(205,191),(8.5,10.5)),('right',[(246,162),(253,155),(265,151),(277,155),(283,163),(282,173),(275,182),(264,185),(252,182),(246,174)],(268,169),(11,13))]:
 decal('EYE '+label+' dark lid silhouette',poly,ink,-.018)
 cpoly=[(c[0]+(u-c[0])*.88,c[1]+(v-c[1])*.88) for u,v in poly]
 decal('EYE '+label+' ivory surface',cpoly,white,-.029,.015)
 decal('IRIS '+label,ellipse(*c,*r),iris,-.047,.012)
 decal('PUPIL '+label,ellipse(c[0]+1,c[1],r[0]*.49,r[1]*.69),black,-.065,.004)
 decal('GLINT '+label,ellipse(c[0]-3,c[1]-5,2.6,3.1),white,-.077,.001)
decal('BROW confident near arch',[(234,152),(245,143),(258,136),(269,136),(277,144),(267,142),(256,146),(243,155),(237,159)],ink,-.02)
decal('BROW angled far arch',[(179,172),(184,164),(195,164),(208,169),(212,175),(201,173),(190,172),(182,177)],ink,-.02)
smilepoly=([(216,224),(229,225),(244,222),(258,215),(268,206),(270,205),(271,206),(259,216.6),(245,223.8),(229,226.6),(216,225.5)] if REV=='v02' else [(215,224),(228,225),(244,222),(257,216),(269,206),(271,205),(272,207),(260,219),(245,225),(228,228),(216,227)])
decal('SMILE asymmetric line',smilepoly,ink,-.012,0)
decal('SMILE corner',[(267,205),(270,203),(273,204),(275,207),(273,209),(272,206)],ink,-.015,0)
decal('NOSTRIL understated near',[(225,205),(229,206),(232,206),(230,208),(226,208)],earshade,-.01,0)
for u,v,r in [(203,212,1.1),(212,213,.8),(215,207,.85),(250,203,.8),(256,202,1),(258,196,.7)]:decal('FRECKLE '+str(u),ellipse(u,v,r,r),freckle,-.014,0)
# Broad sculpted clumps define source silhouette, not round bevel tubes.
# Only major visible locks; fine strand detailing intentionally excluded.
hairmass=[(187,54),(194,69),(220,65),(241,60),(252,64),(249,48),(233,43),(248,40),(271,48),(282,66),(277,79),(295,71),(298,63),(311,68),(313,80),(337,94),(345,108),(353,117),(353,126),(360,130),(357,117),(365,131),(359,147),(368,152),(374,151),(364,165),(345,180),(345,191),(335,202),(344,201),(353,210),(337,217),(332,228),(321,227),(322,218),(302,211),(302,177),(290,148),(275,122),(256,113),(242,123),(218,148),(202,161),(192,191),(183,203),(176,211),(169,206),(158,213),(153,205),(154,194),(137,193),(126,182),(127,173),(121,167),(118,155),(123,141),(134,130),(127,127),(121,119),(122,105),(130,112),(147,107),(153,93),(166,81),(184,76),(179,65)]
dome('HAIR primary silhouette and concealed scalp',hairmass,(246,105),hair,.35,.05,(1.10 if REV=='v02' else .48),rings=30)
locks=[
 ('Left flowing wave',[(127,113),(145,117),(174,105),(201,85),(224,80),(243,89),(237,105),(219,110),(197,112),(182,125),(156,131),(135,127)],(189,106),.13,-.18,hairlight),
 ('Left lower wave',[(178,124),(202,105),(222,102),(239,110),(230,123),(215,148),(198,156),(184,179),(176,194),(165,188),(170,164),(161,157)],(203,135),.14,-.30,hairlight),
 ('Temple left sweep',[(155,131),(167,123),(178,128),(168,148),(157,160),(145,176),(136,184),(126,178),(125,165),(138,151)],(150,152),.10,-.10,hair),
 ('Top broad swept crown',[(183,56),(192,68),(216,65),(237,62),(257,72),(267,89),(258,106),(245,102),(240,85),(216,77),(195,78),(182,73)],(224,76),.13,-.04,hairlight),
 ('Top hook silhouette',[(224,47),(235,42),(253,42),(272,49),(282,65),(278,80),(268,89),(264,76),(259,60),(247,52),(234,51)],(260,60),.09,.03,hairlight),
 ('Near part broad swept wing',[(256,111),(264,97),(281,91),(300,95),(319,105),(335,116),(341,129),(335,137),(312,133),(292,125),(279,113),(271,113),(281,132),(294,144),(315,147),(329,144),(319,157),(303,158),(285,148),(271,131)],(292,124),.15,-.24,hairlight),
 ('Right high sweep',[(279,89),(297,82),(306,71),(305,64),(313,71),(313,84),(331,94),(346,111),(349,120),(337,112),(318,101),(302,98)],(316,94),.095,.01,hair),
 ('Right temple sweep',[(315,140),(335,141),(349,133),(357,129),(354,142),(345,153),(341,166),(338,171),(335,158),(327,153),(318,154)],(337,149),.10,-.08,hair),
 ('Near sideburn',[(297,152),(310,157),(316,167),(313,183),(306,189),(304,178),(302,163)],(307,166),.04,-.16,hairdark),
 ('Rear lower flyaway',[(336,186),(340,199),(349,208),(340,214),(323,216),(333,224),(321,227),(311,216),(308,203)],(329,207),.055,.09,hairdark),
]
for name,poly,c,dep,base,m in locks:dome('HAIR '+name,poly,c,m,dep,base,.035,26)
# Pack reference as viewport-only empty, never material or rendered image plane.
bpy.ops.object.empty_add(type='IMAGE',location=(-3,1,1));R=bpy.context.object;R.name='REF B-v02 ONLY viewport not render';R.data=bpy.data.images.load(str(REF));R.hide_render=True;R.empty_display_size=2.9
target=Vector(xyz(246,150,0))
for name,pos,power,size in [('Locked upper left key',(-3,-5,5),320,4),('Locked broad frontal fill',(3,-5,1),90,5),('Locked rear edge',(2,3,3),100,4)]:
 bpy.ops.object.light_add(type='AREA',location=pos);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.size=size;o.rotation_euler=(target-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'warrior-head.blend'))
# Source view frozen before all renders. Side view is diagnostic only.
S.render.filepath=str(OUT/'source-view-512.png');bpy.ops.render.render(write_still=True)
projection={}
for k,(u,v) in landmarks.items():
 p=world_to_camera_view(S,CAM,Vector(xyz(u,v,face_y(u,v))))
 projection[k]={'reference_px':[u,v],'projected_control_px':[p.x*512,(1-p.y)*512],'note':'authored control point, NOT independent render detector'}
(QA/'camera-registration.json').write_text(json.dumps({'lens_mm':50,'sensor_width_mm':36,'camera_world':list(CAM.location),'rotation_rad':list(CAM.rotation_euler),'landmarks':projection,'unique_camera_recovery':False,'prior_model_imported':False,'reference_used_as_texture':False},indent=2)+'\n')
CAM.location=(5,0,target.z);CAM.rotation_euler=(target-CAM.location).to_track_quat('-Z','Y').to_euler();CAM.data.type='ORTHO';CAM.data.ortho_scale=3.2
S.render.filepath=str(OUT/'side-depth-512.png');bpy.ops.render.render(write_still=True)
print('HEAD_ONLY_REFERENCE_EXPERIMENT_COMPLETE')
