"""Regression fixture: editing a staff must preserve unrelated original face/limb vertices."""
import bpy,json,math
from pathlib import Path
root=Path(__file__).resolve().parents[1];names=['Knight_Head','Knight_ArmLeft','Knight_ArmRight','Knight_LegLeft','Knight_LegRight']
def snapshot(path):
 bpy.ops.wm.open_mainfile(filepath=str(path));return {n:[tuple(v.co) for v in bpy.data.objects[n].data.vertices] for n in names}
base=snapshot(root/'assets/candidates/ios-identity-v02/mage/mage.blend');rows=[]
for version,expected in [('ios-identity-v04',False),('ios-identity-v05',True)]:
 candidate=snapshot(root/'assets/candidates'/version/'mage/mage.blend');deltas={}
 for n in names:
  assert len(candidate[n])==len(base[n]);deltas[n]=max(math.dist(a,b) for a,b in zip(base[n],candidate[n]))
 passed=max(deltas.values())<1e-7;assert passed==expected,(version,deltas,expected)
 rows.append({'fixture':version,'unrelatedGeometryPreserved':passed,'expected':expected,'maxDeltaLocalMeters':deltas})
(root/'artifacts/ios/identity-model-v01/mage-staff-regression.json').write_text(json.dumps({'fixtures':rows,'claim':'Actual .blend pass/fail fixtures; no claim of visual art acceptance or native deformation parity'},indent=2)+'\n');print('STAFF_SCOPE_REGRESSION_PASS',rows)
