#!/usr/bin/env python3
"""Audit the authored mobile skin bindings, not the editor-only selection groups."""
import argparse
import json
import math
from pathlib import Path
import re


def validate_weights(weights, indices, slots, vertices, bones):
    reasons=[]
    if slots not in (1,2): reasons.append("influence slots outside mobile candidate contract")
    if len(weights)!=len(indices) or len(weights)!=vertices*slots: reasons.append("vertex binding stream length mismatch")
    if any(type(i) is not int or not 0<=i<bones for i in indices): reasons.append("joint index outside skeleton")
    if any(not math.isfinite(w) or not 0<=w<=1 for w in weights): reasons.append("invalid weight")
    if reasons:return {"passed":False,"reasons":reasons}
    sums=[sum(weights[i:i+slots]) for i in range(0,len(weights),slots)]
    max_error=max(abs(x-1) for x in sums)
    if max_error>1e-6:reasons.append("weights do not sum to one")
    duplicate=0
    for i in range(0,len(weights),slots):
        active=[indices[i+j] for j in range(slots) if weights[i+j]>0]
        duplicate+=len(active)!=len(set(active))
    if duplicate:reasons.append("duplicate active joint binding")
    return {"passed":not reasons,"reasons":reasons,"vertices":vertices,"influenceSlots":slots,
            "maxSumError":max_error,"duplicateActiveBindings":duplicate,
            "mixedVertices":sum(sum(w>0 for w in weights[i:i+slots])==2 for i in range(0,len(weights),slots))}


def validate_joint_names(names, expected_bones=None):
    base = {"body", "body/left_arm", "body/right_arm", "body/head"}
    legs = {f"body/{side}_thigh" + suffix for side in ("left", "right")
            for suffix in ("", f"/{side}_calf", f"/{side}_calf/{side}_foot")}
    reasons = []
    if len(names) != len(set(names)): reasons.append("duplicate joint names")
    if set(names) not in (base, base | legs, base | legs | {"body/cape"}): reasons.append("unexpected authored skeleton topology")
    if expected_bones is not None and len(names) != expected_bones: reasons.append("joint count differs from requested candidate")
    for i, name in enumerate(names):
        if "/" in name and name.rsplit("/", 1)[0] not in names[:i]:
            reasons.append("joint parent missing or ordered after child")
    return {"passed": not reasons, "reasons": reasons, "bones": len(names)}


def audit(path, expected_bones=None):
    text=path.read_text()
    w=re.search(r"float\[\] primvars:skel:jointWeights = \[(.*?)\] \(\s*elementSize = (\d+)",text,re.S)
    j=re.search(r"int\[\] primvars:skel:jointIndices = \[(.*?)\] \(\s*elementSize = (\d+)",text,re.S)
    p=re.search(r"point3f\[\] points = \[(.*?)\]",text,re.S)
    bones=re.search(r"uniform token\[\] joints = \[(.*?)\]",text,re.S)
    if not all((w,j,p,bones)):raise ValueError(f"Missing authored skin stream: {path}")
    if w[2]!=j[2]:raise ValueError("Influence elementSize mismatch")
    names=re.findall(r'"([^"]+)"',bones[1])
    topology = validate_joint_names(names, expected_bones)
    if not topology["passed"]: raise ValueError(f"Invalid skeleton: {topology}")
    points=re.findall(r"\([^)]*\)",p[1])
    weights=[float(x) for x in w[1].split(",")]
    indices=[int(x) for x in j[1].split(",")]
    result=validate_weights(weights,indices,int(w[2]),len(points),len(names))
    result.update({"file":str(path),"joints":names,"topology":topology})
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory",type=Path)
    parser.add_argument("--output",required=True,type=Path)
    parser.add_argument("--expected-bones", type=int, choices=(4, 10, 11), help="Require the exact candidate version, not just a supported topology")
    args=parser.parse_args()
    results=[audit(args.directory/(hero+"-rig.usda"), args.expected_bones) for hero in ["warrior","mage","rogue"]]
    report={"results":results,"claim":"normalized, bounded shader bindings with actual authored joints; production skin quality separately reviewed"}
    args.output.write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))
    if not all(x["passed"] for x in results):raise SystemExit(1)


if __name__=="__main__":main()
