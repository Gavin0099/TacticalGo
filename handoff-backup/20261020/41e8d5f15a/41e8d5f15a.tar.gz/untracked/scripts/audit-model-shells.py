#!/usr/bin/env python3
"""Verify actual modeled cloth/hair shells form closed, coherently oriented volumes."""
import argparse
from collections import Counter
import json
import math
from pathlib import Path

NAMES = {
    "tailored-hood", "rogue-tailored-mask", "warrior-folded-cape",
    "mage-folded-cape", "rogue-folded-cape", "sculpted-warrior-hair",
    "tailored-left-sleeve", "tailored-right-sleeve",
    "tailored-boot-sole",
}
OPTIONAL_NAMES = {"sculpted-warrior-head", "sculpted-mage-head", "sculpted-rogue-head", "tapered-expression-brow"}


def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def subtract(a, b):
    return tuple(x-y for x,y in zip(a,b))


def dot(a, b):
    return sum(x*y for x,y in zip(a,b))


def audit(part):
    points, normals, triangles = part["points"], part["normals"], part["triangles"]
    welded = {}
    ids = []
    for p in points:
        key = tuple(round(x*1000000) for x in p)
        ids.append(welded.setdefault(key, len(welded)))
    edges, directions = Counter(), Counter()
    volume, degenerate = 0, 0
    for i in range(0, len(triangles), 3):
        original = triangles[i:i+3]
        a,b,c = [points[j] for j in original]
        area = math.sqrt(dot(cross(subtract(b,a),subtract(c,a)),cross(subtract(b,a),subtract(c,a))))
        indices = [ids[j] for j in original]
        if area < 1e-10 or len(set(indices)) != 3:
            degenerate += 1
            continue
        volume += dot(a,cross(b,c))/6
        for j in range(3):
            u,v = indices[j], indices[(j+1)%3]
            key = tuple(sorted((u,v)))
            edges[key] += 1
            directions[key] += 1 if u<v else -1
    bad_edges = sum(count != 2 for count in edges.values())
    bad_directions = sum(value != 0 for value in directions.values())
    bad_normals = sum(not .99 <= math.sqrt(dot(n,n)) <= 1.01 for n in normals)
    result = {"mesh": part["id"], "triangles": len(triangles)//3,
              "weldedVertices": len(welded), "degenerateTriangles": degenerate,
              "boundaryOrNonmanifoldEdges": bad_edges, "inconsistentEdgeDirections": bad_directions,
              "signedVolumeLocalUnits": volume, "nonunitNormals": bad_normals}
    result["passed"] = not (degenerate or bad_edges or bad_directions or bad_normals) and volume > 0
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source",type=Path)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    data=json.loads(args.source.read_text())
    results=[]
    for resource in data["meshes"].values():
        for model in resource["models"]:
            for part in model["parts"]:
                if part["id"] in NAMES | OPTIONAL_NAMES: results.append(audit(part))
    missing=sorted(NAMES-{p["mesh"] for p in results})
    report={"source":str(args.source),"results":results,"missing":missing,
            "claim":"closed oriented surface topology at 1e-6 weld tolerance; not production skin/UV QA"}
    args.output.write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))
    if missing or not all(p["passed"] for p in results):raise SystemExit(1)


if __name__=="__main__":main()
