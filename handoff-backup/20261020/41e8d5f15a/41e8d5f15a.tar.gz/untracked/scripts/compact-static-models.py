#!/usr/bin/env python3
"""Bake static native mesh streams by authored surface; preserve editable masters."""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path

spec=importlib.util.spec_from_file_location('model_usd',Path(__file__).with_name('export-models-usd.py'))
usd=importlib.util.module_from_spec(spec);spec.loader.exec_module(usd)
IDENTITY=[[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]


def multiply(a,b):
    # Source matrices are four columns, matching simd_float4x4.
    return [[sum(a[k][r]*b[c][k] for k in range(4)) for r in range(4)] for c in range(4)]


def transform(matrix,point):
    usd.matrix(matrix);usd.vector(point,3)
    return [sum(matrix[c][r]*point[c] for c in range(3))+matrix[3][r] for r in range(3)]


def determinant(matrix):
    a,b,c=matrix[0][:3],matrix[1][:3],matrix[2][:3]
    return a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-a[2]*b[1])


def normal(matrix,value):
    usd.vector(value,3)
    det=determinant(matrix)
    if not math.isfinite(det) or abs(det)<1e-12:raise ValueError('Singular static normal transform')
    a,b,c=matrix[0][:3],matrix[1][:3],matrix[2][:3]
    def cross(u,v):return [u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
    columns=[cross(b,c),cross(c,a),cross(a,b)]
    n=[sum(columns[k][r]*value[k] for k in range(3))/det for r in range(3)]
    length=math.sqrt(sum(x*x for x in n))
    if not math.isfinite(length) or length<1e-12:raise ValueError('Invalid transformed normal')
    return [x/length for x in n]


def compact(data):
    usd.validate(data)
    if 'animation' in data:raise ValueError('Only static units may be compacted')
    meshes={};models={};reports=[]
    for name,root in data['models'].items():
        groups={};source_parts=0;source_triangles=0
        def walk(node,parent):
            nonlocal source_parts,source_triangles
            if 'matrixSamples' in node:raise ValueError('Animated unit node rejected')
            world=multiply(parent,node['matrixColumns'])
            if 'mesh' in node:
                surface=node['surface'];key=json.dumps(surface,sort_keys=True)
                group=groups.setdefault(key,{'surface':surface,'points':[],'normals':[],'triangles':[]})
                resource=data['meshes'][node['mesh']]
                for instance in resource['instances']:
                    matrix=multiply(world,instance['matrixColumns'])
                    det=determinant(matrix)
                    if not math.isfinite(det) or abs(det)<1e-12:raise ValueError('Singular unit mesh')
                    model=next(m for m in resource['models'] if m['id']==instance['model'])
                    for part in model['parts']:
                        if not part['normals']:raise ValueError('Static surface requires authored normals')
                        offset=len(group['points']);group['points'] += [transform(matrix,p) for p in part['points']]
                        group['normals'] += [normal(matrix,n) for n in part['normals']]
                        indices=part['triangles']
                        for i in range(0,len(indices),3):
                            face=indices[i:i+3]
                            if det<0:face=[face[0],face[2],face[1]]
                            group['triangles'] += [offset+x for x in face]
                        source_parts+=1;source_triangles+=len(indices)//3
            for child in node['children']:walk(child,world)
        walk(root,IDENTITY)
        children=[]
        for i,group in enumerate(groups.values()):
            mesh_id=f'{name}_surface_{i}';part={k:group[k] for k in ['points','normals','triangles']};part['id']=mesh_id
            meshes[mesh_id]={'models':[{'id':mesh_id,'parts':[part]}],'instances':[{'model':mesh_id,'matrixColumns':IDENTITY}]}
            children.append({'name':mesh_id,'matrixColumns':IDENTITY,'mesh':mesh_id,'surface':group['surface'],'children':[]})
        models[name]={'name':name,'matrixColumns':IDENTITY,'children':children}
        baked_triangles=sum(len(g['triangles'])//3 for g in groups.values())
        if baked_triangles!=source_triangles:raise ValueError('Triangle count changed')
        reports.append({'name':name,'sourceMeshParts':source_parts,'bakedMeshParts':len(groups),'triangles':source_triangles,
                        'vertices':sum(len(g['points']) for g in groups.values()),'kind':'exact static material grouping; no FPS claim'})
    result={'schema':data['schema'],'upAxis':'Y','metersPerUnit':1,'source':'exact original static streams grouped by surface','models':models,'meshes':meshes}
    usd.validate(result)
    return result,reports


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('source',type=Path);parser.add_argument('output',type=Path)
    args=parser.parse_args()
    if args.output.exists():raise SystemExit('Preserve previous candidates; use a new output')
    data,rows=compact(json.loads(args.source.read_text()));args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(data,sort_keys=True)+'\n')
    args.output.with_suffix('.report.json').write_text(json.dumps({'sourceSHA256':hashlib.sha256(args.source.read_bytes()).hexdigest(),'builderSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'assets':rows},indent=2)+'\n')
