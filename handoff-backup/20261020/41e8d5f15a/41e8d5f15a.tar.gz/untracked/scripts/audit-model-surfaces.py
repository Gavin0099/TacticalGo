#!/usr/bin/env python3
"""Check candidate UV bindings and that USDZ contains the exact baked PNG atlas."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import zipfile


def validate_uv(values, indices, corners):
    reasons = []
    if not values: reasons.append('missing UV values')
    if len(indices) != corners: reasons.append('UV corner binding length mismatch')
    if any(len(p) != 2 or any(not math.isfinite(x) or not -1e-5 <= x <= 1.00001 for x in p) for p in values):
        reasons.append('UV outside finite atlas bounds')
    if any(type(i) is not int or not 0 <= i < len(values) for i in indices):
        reasons.append('UV index outside atlas stream')
    return {'passed': not reasons, 'reasons': reasons, 'uvValues': len(values), 'cornerBindings': len(indices)}


def png_size(data):
    if len(data) < 33 or data[:8] != b'\x89PNG\r\n\x1a\n' or data[12:16] != b'IHDR':
        raise ValueError('Invalid atlas PNG header')
    return list(struct.unpack('>II', data[16:24]))


def audit(path):
    text = path.read_text()
    coords = re.search(r'texCoord2f\[\] primvars:st = \[(.*?)\]', text, re.S)
    indices = re.search(r'int\[\] primvars:st:indices(?:\.timeSamples = \{\s*0:| =) \[(.*?)\]', text, re.S)
    faces = re.search(r'int\[\] faceVertexIndices(?:\.timeSamples = \{\s*0:| =) \[(.*?)\]', text, re.S)
    if not all((coords, indices, faces)): raise ValueError(f'Missing indexed face-varying UV streams: {path}')
    values = [tuple(float(x) for x in p.split(',')) for p in re.findall(r'\(([^()]*)\)', coords[1])]
    index_values = [int(x) for x in indices[1].split(',')]
    face_values = [int(x) for x in faces[1].split(',')]
    result = validate_uv(values, index_values, len(face_values))
    references = set(re.findall(r'asset inputs:file = @([^@]+)@', text))
    if len(references) != 1: raise ValueError(f'Expected one shared color atlas, got {references}')
    reference = next(iter(references))
    if Path(reference).is_absolute(): raise ValueError('Atlas reference must be relative')
    texture = path.parent / reference
    png = texture.read_bytes(); dimensions = png_size(png)
    if dimensions != [1024, 1024]: raise ValueError(f'Unexpected candidate atlas resolution: {dimensions}')
    digest = hashlib.sha256(png).hexdigest()
    with zipfile.ZipFile(path.with_suffix('.usdz')) as package:
        packaged = [name for name in package.namelist() if name.endswith('.png')]
        if len(packaged) != 1: raise ValueError(f'Expected one packed atlas, got {packaged}')
        packed_png = package.read(packaged[0])
        packed_digest = hashlib.sha256(packed_png).hexdigest()
    if packed_digest != digest: raise ValueError('Packaged atlas differs from referenced baked image')
    if not re.search(r'color3f inputs:diffuseColor.connect = <[^>]+outputs:rgb>', text):
        raise ValueError('Missing native preview-surface color texture connection')
    result.update({'file': str(path), 'atlas': reference, 'dimensions': dimensions,
                   'atlasSHA256': digest, 'packagedAtlasSHA256': packed_digest,
                   'packagedAtlas': packaged[0], 'pngBytes': len(png)})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    results = [audit(args.directory / (hero + '-rig.usda')) for hero in ('warrior', 'mage', 'rogue')]
    report = {'results': results, 'claim': 'finite indexed UV atlas bindings and exact packed PNG; seam/visual quality requires native review'}
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    if not all(item['passed'] for item in results): raise SystemExit(1)


if __name__ == '__main__': main()
