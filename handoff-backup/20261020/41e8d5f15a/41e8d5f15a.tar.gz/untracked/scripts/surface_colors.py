"""Explicit transfer functions for authored linear colors and byte sRGB atlases."""


def linear_to_srgb(value):
    return 12.92 * value if value <= .0031308 else 1.055 * value ** (1 / 2.4) - .055


def srgb_to_linear(value):
    return value / 12.92 if value <= .04045 else ((value + .055) / 1.055) ** 2.4


def atlas_limits(linear_rgb):
    """Byte-buffer bounds and fallback: AO applies before sRGB encoding."""
    return tuple(tuple(linear_to_srgb(max(0, c * amount)) for c in linear_rgb)
                 for amount in (.65, 1.03, .90))
