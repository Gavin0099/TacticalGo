"""Blender audit of a redesigned guardian head: closed topology and paired edge direction.

Independent signed-edge invariant catches reversed caps which Cycles can hide.
The retained body's prior topology is deliberately outside this focused audit.
"""
import bpy,json,sys,math
from pathlib import Path
from collections import defaultdict

def audit(faces):
 edges=defaultdict(list)
 for face in faces:
  for a,b in zip(face,face[1:]+face[:1]):edges[tuple(sorted((a,b)))].append((a,b))
 boundary=sum(len(v)==1 for v in edges.values());nonmanifold=sum(len(v)>2 for v in edges.values())
 incoherent=sum(len(v)==2 and v[0]==v[1] for v in edges.values())
 return {'edges':len(edges),'boundaryEdges':boundary,'nonmanifoldEdges':nonmanifold,'inconsistentPairedEdges':incoherent,'passed':not(boundary or nonmanifold or incoherent)}
# Hand-reviewed oriented tetrahedron; reversal retains closed positions but breaks signed-edge pairing.
fixture=[(0,2,1),(0,1,3),(1,2,3),(2,0,3)]
assert audit(fixture)['passed']
bad=list(fixture);bad[0]=tuple(reversed(bad[0]));assert not audit(bad)['passed']
args=sys.argv[sys.argv.index('--')+1:];source=Path(args[0]);output=Path(args[1]);bpy.ops.wm.open_mainfile(filepath=str(source));skin=bpy.data.objects['Warrior_Skin'];head=skin.vertex_groups['head'].index
indices={v.index for v in skin.data.vertices if any(g.group==head and g.weight>.999 for g in v.groups)}
faces=[tuple(p.vertices) for p in skin.data.polygons if all(i in indices for i in p.vertices)]
result=audit(faces);result.update({'source':str(source),'headVertices':len(indices),'headFaces':len(faces),'regressionFixtures':{'orientedTetrahedron':'PASS','reversedSingleCap':'REJECTED'},'claim':'Signed edge topology for new guardian head only; no art acceptance, full retained-body topology or organic joint guarantee.'})
output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if not result['passed']:raise SystemExit(1)
