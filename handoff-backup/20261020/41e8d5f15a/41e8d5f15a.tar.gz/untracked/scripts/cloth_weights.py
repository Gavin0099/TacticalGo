"""Authored cape contract: upper shoulder stays on body, lower hem follows cape."""
import math


def cape_weight(height):
    if not math.isfinite(height):
        raise ValueError('Cape height must be finite')
    fraction = max(0, min(1, (.665 - height) / (.665 - .40)))
    return fraction * fraction * (3 - 2 * fraction)
