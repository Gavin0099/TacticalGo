#!/usr/bin/env python3
"""Collect fresh native pan receipts and assert axis/state/boundary invariants."""
import argparse, hashlib, json, pathlib, subprocess


def audit_records(records):
    assert sorted((r[0]['size'],len(r)) for r in records)==[(7,2),(9,2),(9,4)], 'Expected 3 fresh per-process runs'
    assert len({r[0]['pid'] for r in records})==3
    for r in records:
        n = r[0]['size']; half = (n-1)/2
        assert len({x['diagram'] for x in r})==1
        assert all(x['selected']==[] and x['ap']==2 and x['mana']==4 for x in r)
        for x in r:
            for i,j in enumerate([0,2]):
                assert abs(x['focus'][j])<=half+1e-5
                assert x['panMinimum'][i]-1e-5 <= x['focus'][j] <= x['panMaximum'][i]+1e-5
        if len(r)==2:
            assert r[0]['focus'][0] > .1 and abs(r[0]['focus'][2]) < .02, 'Horizontal must move x, not z'
            assert abs(r[1]['focus'][0]-r[0]['focus'][0]) < .02 and r[1]['focus'][2] > .1, 'Vertical must move z, preserve x'
        else:
            assert all(abs(r[-1]['focus'][j]-r[-1]['panMaximum'][i]) < .02 for i,j in enumerate([0,2])), 'Repeated diagonal drags must reach both bounds'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--device', required=True); p.add_argument('--inputs', type=pathlib.Path, required=True)
    p.add_argument('--output', type=pathlib.Path, required=True); a = p.parse_args()
    inputs = json.loads(a.inputs.read_text()); assert inputs['device'] == a.device
    folder = pathlib.Path(subprocess.check_output(['xcrun','simctl','get_app_container',a.device,'com.tacticalgo.prototype','data'],text=True).strip()) / 'Documents'
    app = pathlib.Path(subprocess.check_output(['xcrun','simctl','get_app_container',a.device,'com.tacticalgo.prototype','app'],text=True).strip())
    assert hashlib.sha256((app/'TacticalGo.debug.dylib').read_bytes()).hexdigest() == inputs['debugSHA256']
    a.output.mkdir(parents=True, exist_ok=True)
    assert not any(a.output.iterdir()), 'Preserve earlier audits; use a new output'
    records = []
    for f in folder.glob('board-pan-*.json'):
        r = json.loads(f.read_text())
        if not r or r[0].get('endedAtUnix',0) < inputs['sinceUnix']: continue
        (a.output/f.name).write_bytes(f.read_bytes()); records.append(r)
    audit_records(records)
    report = {'pass':True,'device':a.device,'sourceInputs':inputs,'nativeRuns':3,'panEnds':8,
              'checks':['real x/z axis movement','no orthogonal snapping','AP/mana/selection/diagram preserved','focus inside native limits','repeated drags reach bounds'],
              'claim':'native state/projection invariants; screenshots still require manual visual review; no physical/performance claim'}
    (a.output/'audit.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report))


if __name__ == '__main__': main()
