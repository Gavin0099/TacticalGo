"""Original-art costume studies on the inspected CC0 23-joint construction base.
Owner quality/likeness Gate stays pending; not arbitrary stock Mage/Rogue replacement.
"""
import bpy,bmesh,math,json,hashlib,sys
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
hero=sys.argv[sys.argv.index('--')+1];assert hero in ['mage','rogue'];out=root/'assets/candidates/ios-identity-v01'/hero;out.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(root/'assets/candidates/ios-identity-v01/warrior-native/warrior.blend'));scene=bpy.context.scene;rig=bpy.data.objects['Warrior_Identity_Rig'];rig.name=hero.title()+'_Identity_Rig';scene.frame_set(1);bpy.context.view_layer.update()
def mat(name,c,metal=0,rough=.75):
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True;s=m.node_tree.nodes['Principled BSDF'];s.inputs['Base Color'].default_value=(*c,1);s.inputs['Metallic'].default_value=metal;s.inputs['Roughness'].default_value=rough;s.inputs['Specular IOR Level'].default_value=.2;return m
cream=bpy.data.materials['Cream woven tunic'];leather=bpy.data.materials['Chestnut leather'];gold=bpy.data.materials['Aged warm gold'];steel=bpy.data.materials['Soft brushed steel'];skin=bpy.data.materials['Warm youthful complexion'];plum=mat('Plum cloak and hat',(.17,.044,.103));purple=mat('Wavy purple hair',(.105,.029,.098));indigo=mat('Indigo cloth hood',(.047,.053,.15));moss=mat('Moss green vest',(.17,.19,.063));ochre=mat('Ochre folded scarf',(.52,.27,.036));copper=mat('Copper swept fringe',(.30,.067,.018));cyan=mat('Cyan staff crystal',(.038,.63,.68),.1,.3)
def assign(o,m):o.data.materials.clear();o.data.materials.append(m);[setattr(p,'material_index',0) for p in o.data.polygons]
def bind(o,bone,posed=False):
 if posed:
  inv=(rig.pose.bones[bone].matrix@rig.data.bones[bone].matrix_local.inverted()).inverted()
  for v in o.data.vertices:v.co=inv@v.co
 o.parent=rig;o.vertex_groups.new(name=bone).add(list(range(len(o.data.vertices))),1,'REPLACE');o.modifiers.new('Identity skin','ARMATURE').object=rig
 for p in o.data.polygons:p.use_smooth=True
 return o
def mesh(name,vs,fs,m,bone='head',posed=False):
 d=bpy.data.meshes.new(name);d.from_pydata(vs,[],fs);d.update();o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);assign(o,m);bm=bmesh.new();bm.from_mesh(d);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(d);bm.free();return bind(o,bone,posed)
def tube(name,points,r,m,bone='head',posed=False):
 bpy.ops.object.select_all(action='DESELECT');c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=16;c.bevel_depth=r;c.bevel_resolution=3;s=c.splines.new('BEZIER');s.bezier_points.add(len(points)-1)
 for b,p in zip(s.bezier_points,points):b.co=p;b.handle_left_type='AUTO';b.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,c);scene.collection.objects.link(o);o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH');o=bpy.context.object;assign(o,m);return bind(o,bone,posed)
def sphere(name,p,s,m,bone='head',posed=False):
 bpy.ops.object.select_all(action='DESELECT');bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=16,location=p);o=bpy.context.object;o.name=name;o.scale=s;bpy.ops.object.transform_apply(location=True,rotation=True,scale=True);assign(o,m);return bind(o,bone,posed)
def cone_rows(name,rows,m,bone='head',n=48):
 vs=[];fs=[]
 for z,x,y,rx,ry in rows:
  for i in range(n):a=2*math.pi*i/n;vs.append((x+math.cos(a)*rx,y+math.sin(a)*ry,z))
 for k in range(len(rows)-1):
  for i in range(n):j=(i+1)%n;fs.append((k*n+i,k*n+j,(k+1)*n+j,(k+1)*n+i))
 fs.append(tuple(reversed(range(n))));fs.append(tuple((len(rows)-1)*n+i for i in range(n)));return mesh(name,vs,fs,m,bone)
for o in list(scene.objects):
 if o.type=='MESH' and any(t in o.name.lower() for t in ['shield','heraldry','sword']):bpy.data.objects.remove(o,do_unlink=True)
# Preserve face and class-color invariant. Every material edit is local to this saved candidate.
for o in scene.objects:
 if o.type!='MESH':continue
 if any(t in o.name.lower() for t in ['hair','fringe','wave','curl']):assign(o,purple if hero=='mage' else copper)
 if 'Cape' in o.name or 'Teal folded' in o.name:assign(o,plum if hero=='mage' else (ochre if 'folded' in o.name else indigo))
 if 'Arm' in o.name:
  o.data.materials.clear()
  for m in [skin if hero=='mage' else leather,plum if hero=='mage' else cream]:o.data.materials.append(m)
  for p in o.data.polygons:
   x=sum(abs(o.data.vertices[i].co.x) for i in p.vertices)/len(p.vertices);p.material_index=0 if x>.72 else 1
 if 'Leg' in o.name:assign(o,leather)
 if 'Cream tunic torso'==o.name:assign(o,cream if hero=='mage' else moss)
if hero=='mage':
 # Broad cream edged, bent pointed hat; young face and purple bob remain visible.
 cone_rows('Plum swept pointed hat',[(1.86,0,.03,.41,.37),(1.91,0,.03,.42,.37),(2.03,.015,.04,.32,.30),(2.24,.08,.06,.22,.20),(2.44,.19,.075,.105,.105),(2.47,.31,.055,.050,.05),(2.37,.37,.015,.008,.008)],plum)
 cone_rows('Cream brim bound edge',[(1.858,0,.03,.443,.391),(1.900,0,.03,.443,.391)],cream)
 for s in [-1,1]:
  tube('Purple bob side curl '+str(s),[(s*.28,.02,1.83),(s*.34,-.025,1.66),(s*.31,-.055,1.48),(s*.37,-.03,1.35),(s*.39,.01,1.40)],.055,purple)
  tube('Cream cloak edge '+str(s),[(s*.12,-.13,1.19),(s*.30,-.11,1.12),(s*.38,.04,.97),(s*.36,.27,.59),(s*.32,.30,.22)],.025,cream,'chest')
 # Extend robe hem rather than wearing the warrior's short tunic.
 cone_rows('Cream flowing robe',[(.21,0,.02,.36,.24),(.37,0,.01,.34,.24),(.53,0,0,.285,.21)],cream,'hips')
 for j in [-1,0,1]:tube('Robe seam '+str(j),[(j*.14,-.21,.49),(j*.17,-.235,.35),(j*.20,-.20,.22)],.008,cream,'hips')
 # Gold ring and cyan diamond clasp match B-v02 portrait detail.
 sphere('Gold collar setting',(.15,-.20,1.17),(.058,.023,.065),gold,'chest')
 mesh('Cyan diamond brooch',[(.15,-.235,1.225),(.19,-.235,1.17),(.15,-.245,1.115),(.11,-.235,1.17),(.15,-.218,1.17)],[(0,1,2,3),(0,4,1),(1,4,2),(2,4,3),(3,4,0)],cyan,'chest')
 tube('Twisted right-hand wooden staff',[(-.62,-.25,.03),(-.60,-.25,.55),(-.58,-.25,1.07),(-.61,-.25,1.41),(-.57,-.25,1.62)],.035,leather,'handslot.r',True)
 for j in [0,1]:
  tube('Crystal twisted cradle '+str(j),[(-.59+(.08 if j else -.08),-.25,1.64),(-.68 if j else -.52,-.26,1.48),(-.56 if j else -.62,-.26,1.37)],.029,leather,'handslot.r',True)
 mesh('Large cyan staff crystal',[(-.58,-.25,1.88),(-.71,-.25,1.63),(-.58,-.33,1.63),(-.45,-.25,1.63),(-.58,-.17,1.63),(-.58,-.25,1.42)],[(0,1,2),(0,2,3),(0,3,4),(0,4,1),(5,2,1),(5,3,2),(5,4,3),(5,1,4)],cyan,'handslot.r',True)
 rig.scale=(.56,.56,.56)
else:
 # Open-faced rounded indigo hood: a real thick shell, no facial mask.
 vs=[];fs=[];rows=20;cols=28
 for j in range(rows+1):
  theta=.045+(math.pi-.09)*j/rows
  for i in range(cols+1):
   phi=-.35+(math.pi+.70)*i/cols;vs.append((.39*math.sin(theta)*math.cos(phi),.045+.34*math.sin(theta)*math.sin(phi),1.69+.39*math.cos(theta)))
 for j in range(rows):
  for i in range(cols):a=j*(cols+1)+i;fs.append((a,a+1,a+cols+2,a+cols+1))
 hood=mesh('Open face indigo hood shell',vs,fs,indigo);hood.modifiers.new('Cloth shell thickness','SOLIDIFY').thickness=.025
 tube('Hood face opening rolled edge',[(-.30,-.10,1.41),(-.37,-.12,1.67),(-.29,-.19,1.91),(0,-.20,2.04),(.29,-.19,1.91),(.37,-.12,1.67),(.30,-.10,1.41)],.026,indigo)
 for o in scene.objects:
  if o.type=='MESH' and any(t in o.name.lower() for t in ['hair','fringe','wave','curl']):
   for v in o.data.vertices:v.co.z=1.65+(v.co.z-1.65)*.80;v.co.x*=.92
 # Ochre scarf tail, moss vest, two leather hip pouches; single right short blade.
 mesh('Ochre scarf hanging fold',[(-.01,-.223,1.14),(.13,-.24,1.15),(.19,-.235,.84),(.09,-.235,.76),(-.01,-.21,.98),(-.01,-.20,1.14),(.13,-.21,1.15),(.19,-.20,.84),(.09,-.20,.76),(-.01,-.19,.98)],[(4,3,2,1,0),(5,6,7,8,9)]+[(i,(i+1)%5,(i+1)%5+5,i+5) for i in range(5)],ochre,'chest')
 for s in [-1,1]:
  sphere('Leather hip pouch '+str(s),(s*.26,-.20,.46),(.10,.055,.13),leather,'hips');sphere('Gold pouch stud '+str(s),(s*.26,-.259,.51),(.019,.008,.019),gold,'hips')
 tube('Right blade leather grip',[(-.52,-.25,.72),(-.56,-.25,.60)],.026,leather,'handslot.r',True)
 mesh('Right short blade',[(-.57,-.27,.60),(-.65,-.27,.60),(-.75,-.27,.34),(-.73,-.27,.25),(-.69,-.27,.32),(-.57,-.235,.60),(-.65,-.235,.60),(-.75,-.235,.34),(-.73,-.235,.25),(-.69,-.235,.32)],[(4,3,2,1,0),(5,6,7,8,9)]+[(i,(i+1)%5,(i+1)%5+5,i+5) for i in range(5)],steel,'handslot.r',True)
 tube('Short blade gold guard',[(-.64,-.25,.62),(-.52,-.25,.59)],.022,gold,'handslot.r',True)
 rig.scale=(.65,.65,.65)
parts=[o for o in scene.objects if o.type=='MESH']
for o in parts:
 assert any(m.type=='ARMATURE' for m in o.modifiers),(o.name,'missing binding')
 for v in o.data.vertices:assert abs(sum(g.weight for g in v.groups)-1)<1e-4,(o.name,v.index,'invalid weights')
 o.data.normals_split_custom_set([(0,0,0)]*len(o.data.loops))
scene.frame_set(1);scene.cycles.samples=24;scene.render.resolution_x=720;scene.render.resolution_y=900;scene.camera.data.ortho_scale=1.64
bpy.ops.wm.save_as_mainfile(filepath=str(out/(hero+'.blend')))
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=rig
usd=out/(hero+'-rig.usda');bpy.ops.wm.usd_export(filepath=str(usd),selected_objects_only=True,export_animation=True,export_armatures=True,only_deform_bones=True,export_shapekeys=False,export_lights=False,export_cameras=False,export_normals=True,export_uvmaps=True,export_textures_mode='NEW',export_subdivision='IGNORE',generate_preview_surface=True,convert_orientation=True,export_global_up_selection='Y',root_prim_path='/'+hero.title()+'Identity',convert_world_material=False)
for frame,label in [(1,'rest'),(26,'idle-mid')]:
 scene.frame_set(frame)
 for side,loc in [('front',(0,-5,1.45)),('three-quarter',(2.1,-5,1.8)),('back',(2.1,5,1.8))]:
  cam=scene.camera;cam.location=loc;cam.rotation_euler=(Vector((0,0,.65))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(label+'-'+side+'.png'));bpy.ops.render.render(write_still=True)
report={'class':hero,'originalArt':hero+'-v01 and B-'+hero+'-v02','source':'CC0 KayKit head/limbs/rig/Idle_B, new identity wardrobe/hair/face/equipment','joints':list(rig.data.bones.keys()),'sourceBlendSHA256':hashlib.sha256((out/(hero+'.blend')).read_bytes()).hexdigest(),'usdSHA256':hashlib.sha256(usd.read_bytes()).hexdigest(),'meshObjects':len(parts),'notClaimed':['exact likeness','Owner acceptance','production art','main gameplay 23-joint adapter','physical device']};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('CLASS_IDENTITY_STUDY_COMPLETE',report)
