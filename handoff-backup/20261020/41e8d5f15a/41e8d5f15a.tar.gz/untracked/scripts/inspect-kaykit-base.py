import bpy,json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];base=root/'assets/third-party/kaykit-adventurers-2/source/KayKit_Adventurers_2.0_FREE';out=root/'artifacts/ios/identity-model-v01'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(base/'Characters/gltf/Knight.glb'))
rows=[]
for o in bpy.context.scene.objects:
 if o.type=='MESH':
  rows.append({'name':o.name,'vertices':len(o.data.vertices),'bounds':[list(v) for v in o.bound_box],'materials':[m.name for m in o.data.materials]})
 elif o.type=='ARMATURE':rows.append({'name':o.name,'bones':[{'name':b.name,'head':list(b.head_local),'tail':list(b.tail_local)} for b in o.data.bones]})
(out/'knight-inspection.json').write_text(json.dumps(rows,indent=2)+'\n');bpy.ops.wm.save_as_mainfile(filepath=str(out/'knight-import-inspection.blend'))
print(json.dumps(rows,indent=2))
