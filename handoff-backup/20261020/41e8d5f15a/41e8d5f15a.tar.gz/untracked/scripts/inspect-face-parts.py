import bpy,json
from pathlib import Path
from collections import defaultdict
root=Path(__file__).resolve().parents[1];out=root/'artifacts/ios/identity-model-v01'
bpy.ops.wm.open_mainfile(filepath=str(out/'knight-import-inspection.blend'));o=bpy.data.objects['Knight_Head'];m=o.data
adj=defaultdict(set)
for e in m.edges:a,b=e.vertices;adj[a].add(b);adj[b].add(a)
remaining=set(range(len(m.vertices)));parts=[]
image=next(n.image for mat in m.materials for n in mat.node_tree.nodes if n.type=='TEX_IMAGE');pixels=list(image.pixels);w,h=image.size
while remaining:
 todo=[next(iter(remaining))];ids=set()
 while todo:
  i=todo.pop()
  if i in ids:continue
  ids.add(i);remaining.discard(i);todo.extend(adj[i]-ids)
 bounds=[[min(m.vertices[i].co[j] for i in ids),max(m.vertices[i].co[j] for i in ids)] for j in range(3)]
 faces=[p for p in m.polygons if p.vertices[0] in ids];p=faces[len(faces)//2];uv=m.uv_layers.active.data[p.loop_start].uv
 x=min(w-1,max(0,int(uv.x*w)));y=min(h-1,max(0,int(uv.y*h)));color=pixels[(y*w+x)*4:(y*w+x)*4+4]
 parts.append({'vertices':len(ids),'ids':sorted(ids),'bounds':bounds,'uv':list(uv),'color':color})
(out/'face-loose-parts.json').write_text(json.dumps(parts,indent=2)+'\n');print('PARTS',len(parts))
for i,p in enumerate(parts):print(i,p['vertices'],p['bounds'],p['color'])
