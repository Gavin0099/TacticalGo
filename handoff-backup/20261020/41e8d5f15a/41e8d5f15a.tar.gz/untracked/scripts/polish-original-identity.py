"""Restore the source lip surface, original cloak yokes and a closed scout hood canopy."""
import bpy,bmesh,json,math,sys,hashlib
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];hero=sys.argv[sys.argv.index('--')+1]
inputs={'warrior':'final/warrior','mage':'final/mage-brim','rogue':'rogue'};out=root/'assets/candidates/ios-identity-v02'/hero;out.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(root/'assets/candidates/ios-identity-v01'/inputs[hero]/(hero+'.blend')));scene=bpy.context.scene;rig=next(o for o in scene.objects if o.type=='ARMATURE');scene.frame_set(1)
def bindmesh(name,vs,fs,m,bone):
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);me.materials.append(m);bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free();o.parent=rig;o.vertex_groups.new(name=bone).add(list(range(len(me.vertices))),1,'REPLACE');o.modifiers.new('Original identity skin','ARMATURE').object=rig
 for p in me.polygons:p.use_smooth=True
 return o
def loft(name,rows,m):
 n=48;vs=[];fs=[]
 for z,rx,ry in rows:
  for i in range(n):a=math.pi*2*i/n;vs.append((rx*math.cos(a),ry*math.sin(a),z))
 for j in range(len(rows)-1):
  for i in range(n):k=(i+1)%n;fs.append((j*n+i,j*n+k,(j+1)*n+k,(j+1)*n+i))
 fs.extend([tuple(reversed(range(n))),tuple((len(rows)-1)*n+i for i in range(n))]);return bindmesh(name,vs,fs,m,'chest')
# Do not patch a friendly smile with a protruding oval lip. Restore actual source lip surfaces.
underlay=bpy.data.objects.get('Closed smile skin underlay')
if underlay:bpy.data.objects.remove(underlay,do_unlink=True)
with bpy.data.libraries.load(str(root/'artifacts/ios/identity-model-v01/knight-import-inspection.blend'),link=False) as (a,b):b.objects=['Knight_Head']
original=b.objects[0];data=original.data;partinfo=json.loads((root/'artifacts/ios/identity-model-v01/face-loose-parts.json').read_text());ids=sorted(set(partinfo[2]['ids']+partinfo[3]['ids']));index={old:i for i,old in enumerate(ids)};vs=[]
for i in ids:
 v=data.vertices[i].co.copy();v.x*=.90;v.y*=.90;v.z=1.241+(v.z-1.241)*.90+.06;v=Vector((v.x*.85,v.y*.85,1.241+(v.z-1.241)*.85));vs.append(tuple(v))
fs=[tuple(index[i] for i in p.vertices) for p in data.polygons if all(i in index for i in p.vertices)];bindmesh('Restored lip skin surfaces',vs,fs,bpy.data.materials['Warm youthful complexion'],'head');bpy.data.objects.remove(original,do_unlink=True)
clasp=bpy.data.objects.get('Cape clasp')
if clasp:
 clasp.data.materials.clear();clasp.data.materials.append(bpy.data.materials['Aged warm gold'])
 for p in clasp.data.polygons:p.material_index=0
if hero in ['mage','rogue']:
 cloth=bpy.data.materials['Plum cloak and hat' if hero=='mage' else 'Indigo cloth hood'];cream=bpy.data.materials['Cream woven tunic']
 loft('Folded original cloak shoulder yoke',[(1.00,.41,.245),(1.08,.36,.23),(1.21,.18,.14)],cloth)
 if hero=='mage':
  loft('Cream bound cloak hem',[(.985,.413,.247),(1.015,.410,.246)],cream)
  for o in list(scene.objects):
   if o.type=='MESH' and 'Cream cloak edge' in o.name:bpy.data.objects.remove(o,do_unlink=True)
if hero=='rogue':
 old=bpy.data.objects.get('Open face indigo hood shell')
 if old:bpy.data.objects.remove(old,do_unlink=True)
 # Complete top-front canopy; front opening starts below the crown.
 rows=24;n=48;vs=[];fs=[]
 for j in range(rows+1):
  theta=.04+(math.pi-.08)*j/rows
  for i in range(n):phi=2*math.pi*i/n;vs.append((.455*math.sin(theta)*math.cos(phi),.045+.390*math.sin(theta)*math.sin(phi),1.69+.425*math.cos(theta)))
 for j in range(rows):
  for i in range(n):
   phi=2*math.pi*(i+.5)/n
   if j>=5 and math.sin(phi)<-.33:continue
   k=(i+1)%n;fs.append((j*n+i,j*n+k,(j+1)*n+k,(j+1)*n+i))
 hood=bindmesh('Indigo hood with continuous canopy',vs,fs,bpy.data.materials['Indigo cloth hood'],'head');hood.modifiers.new('Cloth inner lining','SOLIDIFY').thickness=.024
 old=bpy.data.objects.get('Hood face opening rolled edge')
 if old:bpy.data.objects.remove(old,do_unlink=True)
# Face/wardrobe remain genuine mesh surfaces, no card-plane substitution.
parts=[o for o in scene.objects if o.type=='MESH'];scene.cycles.samples=24;scene.render.resolution_x=720;scene.render.resolution_y=900;scene.frame_set(1)
for o in parts:
 assert any(m.type=='ARMATURE' for m in o.modifiers),o.name
 for v in o.data.vertices:assert abs(sum(g.weight for g in v.groups)-1)<1e-4,(o.name,v.index)
bpy.ops.wm.save_as_mainfile(filepath=str(out/(hero+'.blend')));bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=rig
usd=out/(hero+'-rig.usda');bpy.ops.wm.usd_export(filepath=str(usd),selected_objects_only=True,export_animation=True,export_armatures=True,only_deform_bones=True,export_shapekeys=False,export_lights=False,export_cameras=False,export_normals=True,export_uvmaps=True,export_textures_mode='NEW',export_subdivision='IGNORE',generate_preview_surface=True,convert_orientation=True,export_global_up_selection='Y',root_prim_path='/'+hero.title()+'Identity',convert_world_material=False)
for frame,label,side,loc in [(1,'rest','front',(0,-5,1.45)),(1,'rest','three-quarter',(2.1,-5,1.8)),(1,'rest','back',(2.1,5,1.8)),(26,'idle-mid','front',(0,-5,1.45))]:
 scene.frame_set(frame);cam=scene.camera;cam.location=loc;cam.rotation_euler=(Vector((0,0,.65))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(label+'-'+side+'.png'));bpy.ops.render.render(write_still=True)
report={'class':hero,'sourceBlendSHA256':hashlib.sha256((out/(hero+'.blend')).read_bytes()).hexdigest(),'usdSHA256':hashlib.sha256(usd.read_bytes()).hexdigest(),'sourceArt':hero+'-v01 / B-'+hero+'-v02','vertices':sum(len(o.data.vertices) for o in parts),'joints':list(rig.data.bones.keys()),'animation':rig.animation_data.action.name,'notClaimed':['exact likeness','Owner quality Gate','production art','main gameplay 23-joint adapter','physical device']};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('POLISHED_IDENTITY_STUDY_COMPLETE',report)
