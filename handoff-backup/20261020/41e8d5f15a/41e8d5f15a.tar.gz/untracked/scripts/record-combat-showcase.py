#!/usr/bin/env python3
"""Record real simulator interaction, then reconstruct candidate soundtrack from its native cue journal.

The final MP4 is a native screen recording plus event-aligned soundtrack, not a
system audio capture. Requires the installed Xcode and ffmpeg; no downloads.
"""
import argparse
import json
from pathlib import Path
import signal
import subprocess
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("device")
    parser.add_argument("--remux-only", action="store_true", help="Reuse the saved native recording and journal without driving the app again")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    output = root / "artifacts/ios/audio-combat-magic-hand"
    raw = output / "native-showcase-raw.mp4"
    if args.remux_only:
        start = json.loads((output / "showcase-provenance.json").read_text())["recording_command_epoch"]
        trace = json.loads((output / "showcase-native-trace.json").read_text())
        mux(root, output, raw, start, trace)
        return
    start = time.time()
    with (output / "recording.log").open("w") as record_log:
        recorder = subprocess.Popen(["xcrun", "simctl", "io", args.device, "recordVideo", "--codec=h264", str(raw)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        try:
            for line in recorder.stdout:
                record_log.write(line); record_log.flush()
                if "Recording started" in line:
                    start = time.time()
                    break
            if recorder.poll() is not None:
                raise RuntimeError("Simulator recording failed before start")
            time.sleep(1)
            command = ["xcodebuild", "-project", "ios/TacticalGo.xcodeproj", "-scheme", "TacticalGo",
                       "-destination", "platform=iOS Simulator,id=" + args.device,
                       "-derivedDataPath", "/tmp/tacticalgo-combat-build", "CODE_SIGNING_ALLOWED=NO",
                       "-parallel-testing-enabled", "NO", "-resultBundlePath", str(output / "showcase.xcresult"),
                       "-only-testing:TacticalGoUITests/CombatFeelTests/testRecordedMagicHandShowcase", "test-without-building"]
            with (output / "showcase-test.log").open("w") as log:
                result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
            if result.returncode:
                raise RuntimeError("Native showcase UI test failed; inspect showcase-test.log")
        finally:
            recorder.send_signal(signal.SIGINT)
            recorder.wait(timeout=30)
    container = Path(subprocess.check_output(["xcrun", "simctl", "get_app_container", args.device, "com.tacticalgo.prototype", "data"], text=True).strip())
    trace_data = (container / "Documents/combat-trace.json").read_bytes()
    (output / "showcase-native-trace.json").write_bytes(trace_data)
    trace = json.loads(trace_data)
    mux(root, output, raw, start, trace)


def mux(root, output, raw, start, trace):
    confirmed = next(e["timestamp"] for e in trace if e["kind"] == "confirmed")
    # Keep 9 seconds of preparation and 16 seconds of result/undo/replay.
    cut_start = max(start, confirmed - 9)
    seek = cut_start - start
    duration = 25
    audio = root / "ios/TacticalGo/Audio"
    command = ["ffmpeg", "-y", "-i", str(raw)]
    command += ["-stream_loop", "-1", "-i", str(audio / "tabletop-loop.wav")]
    # Use a quiet fixed BGM bed. Cue levels are native settings at each request.
    filters = ["[1:a]volume=0.30,atrim=duration=25,asetpts=PTS-STARTPTS[bed]"]
    labels = ["[bed]"]
    used = []
    for event in trace:
        if event["kind"] not in ("selection", "sound") or event.get("muted"):
            continue
        relative = event["timestamp"] - cut_start
        if not 0 <= relative < duration:
            continue
        index = len(used) + 2
        command += ["-i", str(audio / (event["key"] + ".wav"))]
        label = "cue" + str(index)
        filters.append(f"[{index}:a]volume={event['sfxVolume']},adelay={round(relative * 1000)}:all=1[{label}]")
        labels.append("[" + label + "]")
        used.append({**event, "video_time": relative})
    filters.append("".join(labels) + f"amix=inputs={len(labels)}:normalize=0,alimiter=limit=0.92:level=0[mix]")
    # simctl records frames only when the display changes. Fill that native
    # timeline before trimming so a quiet preview retains its preceding frame,
    # rather than losing the first seconds or starting video after the audio.
    video_filter = f"fps=30:start_time=0,trim=start={seek}:duration={duration},setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop_duration={duration}"
    command += ["-filter_complex", ";".join(filters), "-vf", video_filter, "-map", "0:v", "-map", "[mix]", "-t", str(duration),
                "-c:v", "libx264", "-preset", "fast", "-crf", "22", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
                "-movflags", "+faststart", str(output / "magic-hand-25s.mp4")]
    with (output / "showcase-mux.log").open("w") as log:
        subprocess.run(command, check=True, stdout=log, stderr=subprocess.STDOUT)
    provenance = {"screen_source": "native simctl screen recording of successful XCUI playable demo",
                  "audio_source": "candidate WAV soundtrack reconstructed from native scheduled cue requests; not system audio capture",
                  "recording_command_epoch": start, "trim_start_epoch": cut_start, "duration_seconds": duration,
                  "alignment_limit": "Recording launch timestamp estimates first frame; not frame-exact AVAudioPlayer latency evidence",
                  "video_timing": "30fps native display timeline filled before trim; stationary gaps retain the preceding captured frame",
                  "cues": used}
    (output / "showcase-provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print("Native playable showcase + event-aligned candidate soundtrack: " + str(output / "magic-hand-25s.mp4"))


if __name__ == "__main__":
    main()
