"""Clear construction normals after vertex edits and normalize candidate review height."""
import bpy,bmesh,json,hashlib
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];out=root/'assets/candidates/ios-identity-v01/warrior-native';out.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(root/'assets/candidates/ios-identity-v01/warrior-likeness/warrior.blend'));scene=bpy.context.scene;rig=bpy.data.objects['Warrior_Identity_Rig'];scene.frame_set(1)
parts=[o for o in scene.objects if o.type=='MESH']
for o in parts:
 o.data.normals_split_custom_set([(0,0,0)]*len(o.data.loops))
 bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free()
 for modifier in list(o.modifiers):
  if modifier.type=='WEIGHTED_NORMAL':o.modifiers.remove(modifier)
for n in ['Chestnut hair','Chestnut swept locks','Warm youthful complexion','Smile and brows']:
 s=bpy.data.materials[n].node_tree.nodes['Principled BSDF'];s.inputs['Roughness'].default_value=.82;s.inputs['Specular IOR Level'].default_value=.12
rig.scale=(.65,.65,.65);scene.camera.data.ortho_scale=1.63;scene.cycles.samples=24;scene.render.resolution_x=720;scene.render.resolution_y=900
bpy.ops.wm.save_as_mainfile(filepath=str(out/'warrior.blend'))
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=rig
usd=out/'warrior-rig.usda';bpy.ops.wm.usd_export(filepath=str(usd),selected_objects_only=True,export_animation=True,export_armatures=True,only_deform_bones=True,export_shapekeys=False,export_lights=False,export_cameras=False,export_normals=True,export_uvmaps=True,export_textures_mode='NEW',export_subdivision='IGNORE',generate_preview_surface=True,convert_orientation=True,export_global_up_selection='Y',root_prim_path='/WarriorIdentity',convert_world_material=False)
for frame,label in [(1,'rest'),(26,'idle-mid')]:
 scene.frame_set(frame)
 for side,loc in [('front',(0,-5,1.4)),('three-quarter',(2.1,-5,1.8)),('back',(2.1,5,1.8))]:
  cam=scene.camera;cam.location=loc;cam.rotation_euler=(Vector((0,0,.65))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(label+'-'+side+'.png'));bpy.ops.render.render(write_still=True)
report={'sourceBlendSHA256':hashlib.sha256((out/'warrior.blend').read_bytes()).hexdigest(),'usdSHA256':hashlib.sha256(usd.read_bytes()).hexdigest(),'scale':.65,'joints':list(rig.data.bones.keys()),'notClaimed':['Owner approval','production art','main gameplay 23-joint adapter','physical device']};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('NATIVE_CANDIDATE_COMPLETE',report)
