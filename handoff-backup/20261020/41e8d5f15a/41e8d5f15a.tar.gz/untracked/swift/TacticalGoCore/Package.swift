// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "TacticalGoCore",
    products: [
        .library(name: "TacticalGoCore", targets: ["TacticalGoCore"]),
        .library(name: "TacticalGoMotion", targets: ["TacticalGoMotion"]),
        .library(name: "TacticalGoVisuals", targets: ["TacticalGoVisuals"]),
        .executable(name: "tacticalgo-golden", targets: ["GoldenRunner"]),
        .executable(name: "tacticalgo-r2", targets: ["R2Runner"])
    ],
    targets: [
        .target(name: "TacticalGoCore"),
        .target(name: "TacticalGoMotion", dependencies: ["TacticalGoCore"]),
        .target(name: "TacticalGoVisuals"),
        .target(name: "TacticalGoGolden", dependencies: ["TacticalGoCore"]),
        .executableTarget(name: "GoldenRunner", dependencies: ["TacticalGoGolden"]),
        .executableTarget(name: "R2Runner", dependencies: ["TacticalGoCore"]),
        .testTarget(name: "TacticalGoCoreTests", dependencies: ["TacticalGoCore", "TacticalGoGolden"]),
        .testTarget(name: "TacticalGoMotionTests", dependencies: ["TacticalGoMotion", "TacticalGoCore"]),
        .testTarget(name: "TacticalGoVisualsTests", dependencies: ["TacticalGoVisuals"])
    ]
)
